# ENV-T04 严格 regression（自动生成）

- 产物版本：`env-t04-test@1`
- suite：`normal-reward-prefix`（`normal-reward-prefix@1`），目标范围 `base-spire-singleplayer-dev-map-v1`，期望 case 2 个
- run_id：`normal-reward-prefix@normal-reward-prefix@1+20261013T110120Z`
- 复现命令：`dotnet run --project tools/differential -- test --suite normal-reward-prefix --output .artifacts/parallel/dsh-normal-initialization-audit-20261013/final/normal-reward-prefix`
- 完整 suite：True（全量运行）；参考适配器：已接入；退出码：**1**

## 逐 case 判定（只有 passed / self_checked 计成功，且都过了必需维度与预期终点门槛）

| case | 判定 | 内容/机制 | 必需维度 | 终点 | base status | 边界 | 首差/原因 |
| --- | --- | --- | --- | --- | --- | ---: | --- |
| normal-first-reward-take | **diverged** | normal-victory, gold, card-reward, potion-reward, permanent-writeback, map-travel | actions, decisions, facts, pile-order, power, streams, rewards, permanent-inventory, reward-closure | running (ok) | ok | 14/15 | `boundary[0].actions[base-spire:ChooseMapPoint]`：[map:1,1,map:2,1,map:5,1] ≠ [map:2,1,map:3,1,map:5,1]（最后一致边界 （无：第 0 个边界之前就不同，或两侧边界数不同）） |
| normal-first-reward-skip | **diverged** | normal-victory, gold, card-reward, potion-reward, permanent-writeback, map-travel | actions, decisions, facts, pile-order, power, streams, rewards, permanent-inventory, reward-closure | running (ok) | ok | 16/18 | `boundary[0].actions[base-spire:ChooseMapPoint]`：[map:0,1,map:2,1,map:5,1] ≠ [map:1,1,map:2,1,map:3,1,map:4,1,map:5,1]（最后一致边界 （无：第 0 个边界之前就不同，或两侧边界数不同）） |

## 比较器自检（受控错误记录必须被抓到）

| 自检 | 期望差种类 | 是否抓到 | 说明 |
| --- | --- | --- | --- |
| identical/normal-first-reward-skip | no_divergence | 是 | verdict=passed |
| mutant/field/normal-first-reward-skip | field | 是 | boundary[12].player.hp: 66 ≠ 65 |
| mutant/action/normal-first-reward-skip | action | 是 | boundary[15].actions[base-spire:ChooseMapPoint]: [] ≠ [map:0,2] |
| mutant/collection/normal-first-reward-skip | collection | 是 | boundary[12].pile.hand.order: base-spire:bash,base-spire:strike-ironclad,base-spire:strike-ironclad,base-spire:defend-ironclad ≠ base-spire:bash,base-spire:strike-ironclad,base-spire:strike-ironclad,base-spire:defend-ironclad,base-spire:defend-ironclad |
| mutant/decision/normal-first-reward-skip | decision | 是 | boundary[13].decisions[0].candidates: [] ≠ [enemy:0] |
| mutant/stream/normal-first-reward-skip | stream | 是 | boundary[15].streams[base-spire:combat-draw].draws: 19 ≠ 18 |
