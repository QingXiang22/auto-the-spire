# ENV-T04 严格 regression（自动生成）

- 产物版本：`env-t04-test@1`
- suite：`regression`（`env-t04-regression@1`），目标范围 `base-spire-singleplayer-dev-v1`，期望 case 17 个
- run_id：`regression@env-t04-regression@1+20261013T110105Z`
- 复现命令：`dotnet run --project tools/differential -- test --suite regression --output .artifacts/parallel/dsh-normal-initialization-audit-20261013/final/regression`
- 完整 suite：True（全量运行）；参考适配器：已接入；退出码：**0**

## 逐 case 判定（只有 passed / self_checked 计成功，且都过了必需维度与预期终点门槛）

| case | 判定 | 内容/机制 | 必需维度 | 终点 | base status | 边界 | 首差/原因 |
| --- | --- | --- | --- | --- | --- | ---: | --- |
| strike-normal | passed | base-spire:strike-ironclad | actions, decisions, facts, pile-order | running (ok) | ok | 2/2 |  |
| strike-upgraded | passed | base-spire:strike-ironclad | actions, decisions, facts, pile-order | running (ok) | ok | 2/2 |  |
| defend-normal | passed | base-spire:defend-ironclad | actions, facts, pile-order | running (ok) | ok | 2/2 |  |
| defend-upgraded | passed | base-spire:defend-ironclad | actions, facts, pile-order | running (ok) | ok | 2/2 |  |
| bash-then-strike-vulnerable | passed | base-spire:bash, base-spire:strike-ironclad, base-spire:vulnerable | actions, decisions, facts, power, pile-order | running (ok) | ok | 3/3 |  |
| bash-upgraded | passed | base-spire:bash, base-spire:vulnerable | actions, decisions, facts, power, pile-order | running (ok) | ok | 2/2 |  |
| candidate-scope-partly-playable | passed | base-spire:strike-ironclad, base-spire:bash | actions, decisions, facts | running (ok) | ok | 2/2 |  |
| headbutt-mid-choice | passed | base-spire:headbutt, base-spire:defend-ironclad, base-spire:strike-ironclad | actions, decisions, facts | running (ok) | ok | 2/2 |  |
| enemy-death-aftermath | passed | base-spire:strike-ironclad, base-spire:calcified-cultist, base-spire:damp-cultist | actions, decisions, facts, pile-order | running (ok) | ok | 3/3 |  |
| power-turn-end-decay | passed | base-spire:strike-ironclad, base-spire:vulnerable | actions, decisions, facts, power | running (ok) | ok | 3/3 |  |
| vulnerable-decay-via-bash | passed | base-spire:bash, base-spire:vulnerable | actions, decisions, facts, power | running (ok) | ok | 3/3 |  |
| random-reshuffle-unsupported | passed | base-spire:strike-ironclad, base-spire:defend-ironclad, base-spire:bash | actions, facts, pile-order, streams | running (ok) | ok | 4/4 |  |
| last-kill-before-terminal | passed | base-spire:strike-ironclad, base-spire:bash, base-spire:vulnerable | actions, decisions, facts, pile-order | victory (ok) | terminal | 3/3 |  |
| rng-initial-shuffle | passed | base-spire:strike-ironclad, base-spire:defend-ironclad, base-spire:bash | actions, facts, pile-order, streams | running (ok) | ok | 1/1 |  |
| factory-wiring-dev-scope | self_checked | base-spire-singleplayer-dev-v1 | actions, facts | running (ok) | ok | 1/0 |  |
| map-generated-alpha | passed | act-1-map | facts, streams | running (ok) | ok | 1/1 |  |
| map-generated-beta | passed | act-1-map | facts, streams | running (ok) | ok | 1/1 |  |

## 比较器自检（受控错误记录必须被抓到）

| 自检 | 期望差种类 | 是否抓到 | 说明 |
| --- | --- | --- | --- |
| identical/random-reshuffle-unsupported | no_divergence | 是 | verdict=passed |
| mutant/field/random-reshuffle-unsupported | field | 是 | boundary[3].player.hp: 54 ≠ 53 |
| mutant/action/random-reshuffle-unsupported | action | 是 | boundary[3].actions[base-spire:PlayCard]: [card:hand:0,card:hand:1,card:hand:2,card:hand:3] ≠ [card:hand:0,card:hand:1,card:hand:2,card:hand:3,card:hand:4] |
| mutant/collection/random-reshuffle-unsupported | collection | 是 | boundary[3].pile.hand.order: base-spire:strike-ironclad,base-spire:defend-ironclad,base-spire:defend-ironclad,base-spire:defend-ironclad ≠ base-spire:strike-ironclad,base-spire:defend-ironclad,base-spire:defend-ironclad,base-spire:defend-ironclad,base-spire:strike-ironclad |
| mutant/decision/bash-then-strike-vulnerable | decision | 是 | boundary[2].decisions[0].candidates: [enemy:0] ≠ [enemy:0,enemy:1] |
| mutant/stream/random-reshuffle-unsupported | stream | 是 | boundary[3].streams[base-spire:combat-draw].draws: 10 ≠ 9 |
| mutant/vulnerable-duration/vulnerable-decay-via-bash | field | 是 | boundary[2].power.enemy.base-spire:calcified-cultist.0.stacks: 2 ≠ 1 |
| init/duplicate-slot | invalid_fixture | 是 | 初始实例槽位缺失或重复 |
| init/missing-card | invalid_fixture | 是 | 初始牌总集合与预登记源起始牌组不一致（缺失或多余牌） |
| init/incomplete | invalid_fixture | 是 | 完整声明必须包含 hand/draw/discard/exhaust（空区显式 []） |
| gate/random-consumption | unsupported_rng_profile | 是 | unsupported_rng_profile |
| gate/unknown | unsupported_rng_profile | 是 | unsupported_rng_profile |
| gate/missing-declaration | unsupported_rng_profile | 是 | unsupported_rng_profile |
| mutant/ordered-initial-slots/enemy-death-aftermath | collection | 是 | boundary[0].pile.draw.initial-slots: start:09,start:08,start:07,start:06,start:05,start:04,start:03,start:02,start:01 ≠ start:01,start:02,start:03,start:04,start:05,start:06,start:07,start:08,start:09 |
| execution/power-Ticks | field | 是 | boundary[2].power.enemy.base-spire:calcified-cultist.0.stacks: 2 ≠ 1 |
| execution/power-SkipNextTick | field | 是 | boundary[2].power.enemy.base-spire:calcified-cultist.0.stacks: 2 ≠ 1 |
| execution/held-player-base-spire:strength | held-power-trajectory | 是 | base=2→2; reference=2→2; verdict=passed |
| execution/held-player-base-spire:vulnerable | held-power-trajectory | 是 | base=2→1; reference=2→1; verdict=passed |
| execution/held-player-base-spire:weak | held-power-trajectory | 是 | base=2→1; reference=2→1; verdict=passed |
| execution/held-enemy:0-base-spire:strength | held-power-trajectory | 是 | base=2→2; reference=2→2; verdict=passed |
| execution/held-enemy:0-base-spire:vulnerable | held-power-trajectory | 是 | base=2→1; reference=2→1; verdict=passed |
| execution/held-enemy:0-base-spire:weak | held-power-trajectory | 是 | base=2→1; reference=2→1; verdict=passed |
