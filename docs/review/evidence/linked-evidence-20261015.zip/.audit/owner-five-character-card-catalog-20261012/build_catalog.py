"""Dated, source-led catalog; no writes to production/source/localization."""
import collections
import hashlib
import json
import os
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[2]
AUDIT = Path(__file__).parent
OUT = ROOT / 'docs/review/records/2026-10-12/five-character-card-catalog'
LOC_PATH = ROOT / 'sts2/localization/zhs/cards.json'
LOC = json.loads(LOC_PATH.read_text(encoding='utf-8-sig'))
CHAR_LOC = json.loads((ROOT / 'sts2/localization/zhs/characters.json').read_text(encoding='utf-8-sig'))
KW_LOC = json.loads((ROOT / 'sts2/localization/zhs/card_keywords.json').read_text(encoding='utf-8-sig'))
SOURCE = ROOT / 'sts2/src/Core/Models'
CHARACTERS = ['Ironclad', 'Silent', 'Regent', 'Necrobinder', 'Defect']
COVERAGE = [json.loads(l[9:]) for l in (AUDIT / 'coverage.ndjson').read_text(encoding='utf-8-sig').splitlines() if l.startswith('COVERAGE ')]
BY_NAME = {r['Name']: r for r in COVERAGE}
assert len(BY_NAME) == len(COVERAGE), 'duplicate source declaration name'
LOG_PATH = ROOT / '.audit/owner-shared-run-20261012/slice-final.log'
LOG = LOG_PATH.read_text(encoding='utf-8-sig').splitlines()
FORMAL_PATH = ROOT / 'mod-the-spire/base-spire/BaseSpire.Slice.Tests/SliceFormalSourceChecks.cs'
FORMAL = FORMAL_PATH.read_text(encoding='utf-8-sig')
CURATED = set(re.findall(r'"([a-z][a-z0-9-]+)"', FORMAL.split('BehaviorVerifiedIds =', 1)[1].split('];', 1)[0]))
SET_TEXT = (SOURCE.parent / 'Localization/DynamicVars/DynamicVarSet.cs').read_text(encoding='utf-8-sig')
ALIASES = dict(re.findall(r'public [^\n]+ (\w+) => [^\n]+_vars\["([^"]+)"\]', SET_TEXT))
UNRESOLVED = []
HASHES = {}

def read(path):
    HASHES[str(path.relative_to(ROOT)).replace('\\', '/')] = hashlib.sha256(path.read_bytes()).hexdigest()
    return path.read_text(encoding='utf-8-sig')

def slug(name):
    return re.sub(r'(?<!^)([A-Z])', r'_\1', name).upper()

def kebab(name):
    return slug(name).lower().replace('_', '-')

def link(path, label, line=None):
    rel = os.path.relpath(path, OUT).replace('\\', '/')
    # Markdown anchors on source line numbers are not checked/portable locally.
    return f'[{label}]({rel})'

def member(text, name):
    match = re.search(r'\b' + re.escape(name) + r'\b', text)
    if not match:
        return ''
    # decompiler consistently emits each member at one-tab indentation
    rest = text[match.end():]
    return re.split(r'\n\t(?:public|protected|private|internal) ', rest, maxsplit=1)[0]

def method(text, name):
    match = re.search(r'\b' + re.escape(name) + r'\s*\(\s*\)', text)
    if not match:
        return ''
    start = text.find('{', match.end())
    depth = 1
    i = start + 1
    while depth and i < len(text):
        depth += (text[i] == '{') - (text[i] == '}')
        i += 1
    return text[start + 1:i - 1]

def split_top(text, sep=','):
    depth = 0
    quote = False
    start = 0
    chunks = []
    for i, c in enumerate(text):
        if c == '"' and (i == 0 or text[i-1] != '\\'):
            quote = not quote
        if quote:
            continue
        if c in '({[':
            depth += 1
        elif c in ')}]':
            depth -= 1
        elif c == sep and depth == 0:
            chunks.append(text[start:i])
            start = i + 1
    return chunks + [text[start:]]

def scalar(arg, const):
    arg = arg.strip()
    if arg in const:
        return const[arg]
    if arg.startswith('"') and arg.endswith('"'):
        return arg[1:-1]
    if re.fullmatch(r'-?\d+(?:\.\d+)?[mMfFdD]?', arg):
        return float(arg.rstrip('mMfFdD'))
    return None

def source_values(text):
    const = {}
    for key, raw in re.findall(r'const (?:string|int|decimal) (\w+) = ([^;]+);', text):
        const[key] = scalar(raw, {})
    vals = {}
    for match in re.finditer(r'new (\w+Var)(?:<(\w+)>)?\(', member(text, 'CanonicalVars')):
        raw = member(text, 'CanonicalVars')[match.end():]
        depth = 1
        end = 0
        for end, c in enumerate(raw):
            depth += (c == '(') - (c == ')')
            if depth == 0:
                break
        args = [scalar(a, const) for a in split_top(raw[:end])]
        typ, generic = match.groups()
        key = generic if typ == 'PowerVar' else typ.removesuffix('Var')
        if args and isinstance(args[0], str):
            key = args[0]
            value = args[1] if len(args) > 1 else None
        else:
            value = args[0] if args else None
        # Calculated previews are runtime values, not static card-library values.
        if key.startswith('Calculated'):
            continue
        if isinstance(value, (int, float)):
            vals[key] = value
    up = dict(vals)
    upgrade = method(text, 'OnUpgrade')
    edits = []
    for m in re.finditer(r'base\.DynamicVars(?:\.(\w+)|\[([^\]]+)\])\.UpgradeValueBy\(([^)]+)\)', upgrade):
        key = ALIASES.get(m.group(1), m.group(1)) if m.group(1) else scalar(m.group(2), const)
        delta = scalar(m.group(3), const)
        if key in vals and isinstance(delta, (int, float)):
            up[key] += delta
            edits.append({'key': key, 'from': vals[key], 'to': up[key]})
        else:
            UNRESOLVED.append({'upgrade': m.group(0)})
    return vals, up, edits

def number(value):
    return str(int(value)) if isinstance(value, (int, float)) and value == int(value) else str(value)

def render(template, vals, upgraded, name, target, inherited=None):
    result = ''
    i = 0
    while i < len(template):
        if template[i] != '{':
            result += template[i]
            i += 1
            continue
        start = i
        depth = 1
        i += 1
        while i < len(template) and depth:
            depth += (template[i] == '{') - (template[i] == '}')
            i += 1
        assert depth == 0, (name, template)
        body = template[start + 1:i - 1]
        parts = body.split(':', 1)
        key = parts[0] or inherited
        fmt = parts[1] if len(parts) > 1 else ''
        if key in ('IfUpgraded', 'InCombat', 'IsTargeting', 'OnTable', 'IsOstyAlive', 'GainsBlock'):
            opts = split_top(fmt.removeprefix('show:').removeprefix('cond:'), '|')
            flag = upgraded if key == 'IfUpgraded' else False
            chosen = opts[0] if flag else (opts[1] if len(opts) > 1 else '')
            result += render(chosen, vals, upgraded, name, target, key)
        elif fmt.startswith('choose('):
            test, rest = fmt.split('):', 1)
            test = test[len('choose('):]
            opts = split_top(rest, '|')
            val = target if key == 'TargetType' else vals.get(key)
            hit = str(val) == test or number(val) == test
            chosen = opts[0] if hit else (opts[1] if len(opts) > 1 else '')
            result += render(chosen, vals, upgraded, name, target, key)
        elif fmt.startswith('plural:'):
            opts = split_top(fmt[len('plural:'):], '|')
            result += opts[0] if vals.get(key) == 1 else opts[-1]
        elif key == 'singleStarIcon':
            result += '★'
        elif key == 'energyPrefix':
            n = re.search(r'energyIcons\((\d+)\)', fmt)
            result += '[能量]' * (int(n.group(1)) if n else 1)
        elif key in vals:
            val = vals[key]
            if fmt.startswith('energyIcons'):
                result += number(val) + '点能量'
            elif fmt.startswith('starIcons'):
                result += '★' * int(val) if 0 <= val <= 5 else number(val) + '★'
            else:
                result += number(val)
        else:
            labels = {'CalculatedDamage':'动态伤害','CalculatedForge':'动态铸造值','CalculatedBlock':'动态格挡'}
            result += '【' + labels.get(key, str(key)) + '】'
            UNRESOLVED.append({'card': name, 'upgraded': upgraded, 'variable': key, 'expression': body})
    return re.sub(r'\[/?(?:gold|red|blue|green|purple|pink|orange|yellow|sine|jitter)(?:=[^]]+)?\]', '', result)

def keywords(text, upgraded):
    keys = re.findall(r'CardKeyword\.(\w+)', member(text, 'CanonicalKeywords'))
    keys = list(dict.fromkeys(keys))
    if upgraded:
        for op, key in re.findall(r'(AddKeyword|RemoveKeyword)\(CardKeyword\.(\w+)\)', method(text, 'OnUpgrade')):
            if op == 'AddKeyword' and key not in keys:
                keys.append(key)
            elif op == 'RemoveKeyword' and key in keys:
                keys.remove(key)
    return [KW_LOC.get(slug(k) + '.title', k) for k in keys]

def cost_info(text):
    ctor = re.search(r': base\(([^,]+), CardType\.(\w+), CardRarity\.(\w+), TargetType\.(\w+)', text)
    assert ctor, text[:150]
    cost, typ, rarity, target = ctor.groups()
    cost = cost.strip()
    n = scalar(cost, {})
    basecost = 'X' if 'HasEnergyCostX => true' in text else ('不可打出' if n is not None and n < 0 else cost)
    upcost = basecost
    change = re.search(r'EnergyCost\.UpgradeBy\((-?\d+)\)', method(text, 'OnUpgrade'))
    if change and isinstance(n, (int, float)):
        upcost = number(n + int(change.group(1)))
    star = member(text, 'CanonicalStarCost')
    starcost = re.search(r'=>\s*(\d+)', star)
    stars = 'X' if 'HasStarCostX => true' in text else (int(starcost.group(1)) if starcost else 0)
    upstars = stars
    change = re.search(r'(?:StarCost|StarCostUpgrade)\.UpgradeBy\((-?\d+)\)', method(text, 'OnUpgrade'))
    if change and isinstance(stars, int):
        upstars += int(change.group(1))
    return basecost, upcost, stars, upstars, typ, rarity, target

def mechanism_tags(text, raw, card):
    # Includes directly applied power sources: resource mechanisms often live in hooks.
    powers = set(re.findall(r'(?:PowerCmd\.Apply|HoverTipFactory\.FromPower)<(\w+)>', text))
    combined = text
    for power in powers:
        path = SOURCE / 'Powers' / (power + '.cs')
        if path.exists():
            combined += '\n' + read(path)
    tags = []
    for label, pattern in [
        ('星星资源/星星费用', r'PlayerCmd\.(?:GainStars|LoseStars)|CanonicalStarCost|HasStarCostX|StarsVar|singleStarIcon'),
        ('铸造/君主之剑', r'ForgeCmd|ForgeVar|SovereignBlade'),
        ('仆从衍生牌/变化', r'MinionStrike|MinionSacrifice|MinionDiveBomb'),
        ('奥斯提/召唤/独立生物', r'OstyCmd|\.Osty\b|\.IsOstyAlive|OstyDamageVar|SummonVar|Summon\('),
        ('灾厄结算', r'DoomPower|DoomVar'),
        ('充能球/槽位/触发', r'OrbCmd|OrbQueue|OrbSlot|FromOrb<|OrbModel'),
        ('集中与充能球数值', r'FocusPower|CalculatedFocus'),
        ('毒/毒触发', r'PoisonPower|PoisonCmd'),
        ('弃牌触发/奇巧', r'CardKeyword.Sly|AfterCardDiscarded|BeforeCardDiscarded'),
        ('牌实例持久修改/重放', r'Enchantment|Affliction|ReplayCount|\.Replay\('),
        ('跨玩家效果', r'MultiplayerOnly|TargetType.AnyAlly|TargetType.AllAllies|OtherPlayers'),
    ]:
        if re.search(pattern, combined + '\n' + raw):
            tags.append(label)
    return tags

def evidence(card):
    cid = kebab(card)
    refs = []
    if cid in CURATED:
        refs.append({'kind': 'curated-local-behavior', 'path': str(FORMAL_PATH.relative_to(ROOT)), 'line': next(i for i,l in enumerate(FORMAL.splitlines(), 1) if '"'+cid+'"' in l)})
    # Use logged per-card cases only, not incidental references in other assertions.
    case_pattern = re.compile(r'(?<![a-z0-9-])' + re.escape(cid) + r'/(?:normal|created-upgraded|armaments-upgraded)\b')
    class_pattern = re.compile(r'(?<![A-Za-z])' + re.escape(card) + r'/(?:normal|created-upgraded|armaments-upgraded|False|True)\b')
    explicit_family = card in ['Whirlwind','TearAsunder','PerfectedStrike','FiendFire','SecondWind','PrimalForce']
    for i, line in enumerate(LOG, 1):
        actual_anger = card == 'Anger' and line.startswith('ok   ENV-T05 正式 Anger（')
        actual_family = explicit_family and re.search(r'家族 [12]：'+card+r'\b',line)
        if line.startswith('ok ') and (case_pattern.search(line) or class_pattern.search(line) or actual_anger or actual_family):
            refs.append({'kind': 'executed-local-card-case', 'path': str(LOG_PATH.relative_to(ROOT)), 'line': i, 'case': line})
    return refs

def row_data(name, pool):
    path = SOURCE / 'Cards' / (name + '.cs')
    text = read(path)
    key = slug(name)
    raw = LOC[key + '.description']
    title = LOC[key + '.title']
    vals, up, changes = source_values(text)
    # These two vars read saved properties, initialized by the source class fields.
    if name == 'TheScythe':
        assert 'private int _currentDamage = 13;' in text
        vals['Damage'] = up['Damage'] = 13
    if name == 'GeneticAlgorithm':
        assert 'private int _currentBlock = 1;' in text
        vals['Block'] = up['Block'] = 1
    cost, upcost, stars, upstars, typ, rarity, target = cost_info(text)
    normal = render(raw, vals, False, name, target)
    upgraded = render(raw, up, True, name, target)
    keys, upkeys = keywords(text, False), keywords(text, True)
    if keys:
        normal = normal.rstrip() + '\n关键字：' + '、'.join(keys) + '。'
    if upkeys:
        upgraded = upgraded.rstrip() + '\n关键字：' + '、'.join(upkeys) + '。'
    coverage = BY_NAME.get(name)
    refs = evidence(name)
    state = '未声明' if coverage is None else ('已注册；有本地行为证据' if coverage['Registered'] and refs else '已注册；逐卡行为待核对' if coverage['Registered'] else '已声明；注册受阻')
    notes=[]
    if '【动态' in normal and 'CalculationBase' in vals:
        label='基础铸造' if '【动态铸造值】' in normal else '基础伤害'
        notes.append(label+number(vals['CalculationBase'])+'→'+number(up['CalculationBase'])+'；实际值随描述中的条件变化')
    if name in ['TheScythe','GeneticAlgorithm']:
        notes.append('显示新牌初始值；已成长的实例按保存值显示')
    if name == 'SovereignBlade':
        notes.append('显示无铸造/能力修正的新牌；SeekingEdge改变目标，Parry追加动态格挡，铸造改变伤害')
    if name == 'Shiv':
        notes.append('显示无能力修正的新牌；FanOfKnives改为全体目标')
    return dict(name=name, title=title, pool=pool, locale_key=key+'.description', source=str(path.relative_to(ROOT)).replace('\\','/'), normal=normal, upgraded=upgraded, raw_description=raw, normal_values=vals, upgraded_values=up, upgrade_changes=changes, cost=cost, upgraded_cost=upcost, stars=stars, upgraded_stars=upstars, type=typ, rarity=rarity, target=target, keywords=keys, upgraded_keywords=upkeys, multiplayer='MultiplayerOnly' in member(text,'MultiplayerConstraint'), upgradeable='MaxUpgradeLevel => 0' not in text, coverage=coverage, evidence=refs, state=state, mechanisms=mechanism_tags(text,raw,name), notes=notes)

def cell(text):
    return str(text).replace('|', '\\|').replace('\n', '<br>').strip()

def source_link(row):
    return link(ROOT / row['source'], '`'+row['name']+'`')

def base_link(row):
    coverage = row['coverage']
    if coverage is None:
        return ''
    filename = coverage['Resource'].split('.')[-2] + '.spire'
    path = ROOT / 'mod-the-spire/base-spire/BaseSpire/ContentSource' / filename
    assert path.exists(), path
    return link(path, 'base:'+str(coverage['Line']))

def status_cell(row):
    result = row['state']
    if row['coverage']:
        result += '<br>' + base_link(row)
        if not row['coverage']['Registered']:
            result += '<br>' + cell(row['coverage']['Reason'])
    if row['evidence']:
        ref = row['evidence'][0]
        result += '<br>' + link(ROOT / ref['path'], '本地证据:'+str(ref['line']))
    return result

def page(pool, rows):
    title = CHAR_LOC.get(slug(pool) + '.title', '衍生卡（共享 TokenCardPool）')
    poolpath = SOURCE / 'CardPools' / (pool + 'CardPool.cs')
    lines = [f'# {title}卡牌校对清单（2026-10-12）', '', f'原版 {link(poolpath, pool+"CardPool")} 共 **{len(rows)}** 张。亡灵契约师对应用户提到的“亡灵召唤师”。' if pool=='Necrobinder' else f'原版 {link(poolpath, pool+"CardPool")} 共 **{len(rows)}** 张。', '', '[返回清单总览](README.md)。这是源快照与实现证据的日期记录；列含义、符号及未验证范围见总览。普通/升级描述来自同一条中文本地化模板，数值只取原版源码；不会根据 base 的实现反推描述。', '', '| # / 卡牌 / 原版标识 | 类型、稀有度与费用（普通→升级） | 原版普通描述 | 原版升级描述 | base 实现证据 | 专属/共享机制线索 |', '| --- | --- | --- | --- | --- | --- |']
    types={'Attack':'攻击','Skill':'技能','Power':'能力','Status':'状态','Curse':'诅咒'}
    rarities={'Basic':'基础','Common':'普通','Uncommon':'罕见','Rare':'稀有','Token':'衍生','Event':'事件','Ancient':'先古','Status':'状态','Curse':'诅咒'}
    for i,r in enumerate(rows,1):
        identity=f'{i}. **{r["title"]}**<br>{source_link(r)}'
        if r['multiplayer']:
            identity += '<br>**仅多人**'
        cost=f'{r["cost"]}→{r["upgraded_cost"]} 能量'
        if r['stars'] or r['upgraded_stars']:
            cost += f'<br>{r["stars"]}→{r["upgraded_stars"]} ★'
        if not r['upgradeable']:
            cost += '<br>不可升级'
        notes='、'.join(r['mechanisms']) or '—'
        if r['notes']:
            notes += '<br>数值说明：'+cell('；'.join(r['notes']))
        lines.append('| '+ ' | '.join([identity, types.get(r['type'],r['type'])+' / '+rarities.get(r['rarity'],r['rarity'])+'<br>'+cost, cell(r['normal']), cell(r['upgraded']) if r['upgradeable'] else '不可升级；不适用', status_cell(r), notes])+' |')
    lines += ['', '“—”仅表示没有命中本次专属机制检索标签，不能据此认定该牌只需要简单原语。源标识链接指向原版卡类；base 链接中的数字是声明行，本地证据数字是对应日志/检查源码行。', '']
    if pool == 'Token':
        lines += ['## 角色卡与衍生卡的引用关系', '', '以下按原版卡类中的泛型卡引用归属，包含悬浮提示引用；不是生成行为的完整调用图。TokenCardPool 是共享池，不强行计入某一角色的 87/88 张。', '', '| 衍生卡 | 引用它的五角色卡 |', '| --- | --- |']
        for row in rows:
            users=[]
            pattern=re.compile(r'<'+re.escape(row['name'])+r'>')
            for p,rs in ALL.items():
                if p=='Token':continue
                for r in rs:
                    if pattern.search((ROOT/r['source']).read_text(encoding='utf-8-sig')):
                        users.append(r['title']+'（'+r['name']+'）')
            lines.append('| '+row['title']+' | '+('、'.join(users) or '五角色卡类中无直接泛型引用；可能由 Power/遗物/敌人等生成')+' |')
        lines.append('')
    (OUT/(pool.lower()+'.md')).write_text('\n'.join(lines),encoding='utf-8')

ALL={}
for path in [LOC_PATH, ROOT/'sts2/localization/zhs/characters.json', ROOT/'sts2/localization/zhs/card_keywords.json', SOURCE.parent/'Localization/DynamicVars/DynamicVarSet.cs']:
    read(path)
for pool in CHARACTERS+['Token']:
    text=read(SOURCE/'CardPools'/(pool+'CardPool.cs'))
    names=re.findall(r'ModelDb.Card<(\w+)>',member(text,'GenerateAllCards'))
    assert len(names)==len(set(names)), pool
    ALL[pool]=[row_data(n,pool) for n in names]
assert [len(ALL[c]) for c in CHARACTERS]==[87,88,88,88,88]
assert len({r['name'] for c in CHARACTERS for r in ALL[c]})==439
OUT.mkdir(parents=True,exist_ok=True)
for pool,rows in ALL.items():
    page(pool,rows)
summary={p:{'source_cards':len(rows),'declared':sum(r['coverage'] is not None for r in rows),'registered':sum(bool(r['coverage'] and r['coverage']['Registered']) for r in rows),'local_behavior_evidence':sum(bool(r['coverage'] and r['coverage']['Registered'] and r['evidence']) for r in rows),'multiplayer_only':sum(r['multiplayer'] for r in rows),'not_declared':sum(r['coverage'] is None for r in rows)} for p,rows in ALL.items()}
(AUDIT/'catalog.json').write_text(json.dumps({'date':'2026-10-12','scope':'local-sts2-source-snapshot','summary':summary,'cards':ALL,'unresolved':UNRESOLVED,'sha256':HASHES},ensure_ascii=False,indent=2),encoding='utf-8')
(AUDIT/'unresolved.json').write_text(json.dumps(UNRESOLVED,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False,indent=2))
print('unresolved',len(UNRESOLVED))
print(json.dumps(UNRESOLVED,ensure_ascii=False,indent=2))
