using System.Diagnostics;
using System.Text.Json;
using BaseSpire.SinglePlayer;
using BaseSpire.Slice;
using CoreTheSpire.Engine;

static double Measure(Action action, int repetitions = 1)
{
    var sw = Stopwatch.StartNew();
    for (var i = 0; i < repetitions; i++) action();
    return sw.Elapsed.TotalMilliseconds / repetitions;
}

var results = new List<object>();
BaseSpireRuntimeFactory? factory = null;
results.Add(new { metric = "factory_cold_ms", ms = Measure(() => factory = new(RunConfiguration.Ironclad(0, BaseSpireScope.DevMap))) });
results.Add(new { metric = "factory_warm_ms", ms = Measure(() => _ = new BaseSpireRuntimeFactory(RunConfiguration.Ironclad(0, BaseSpireScope.DevMap)), 3) });
results.Add(new { metric = "formal_build_ms", ms = Measure(() => _ = FormalSpirePackage.BuildRuleSet(out _), 3) });
foreach (var seed in new[] { "t05-map-alpha", "t05-map-beta" })
{
    var run = factory!.CreateSession(seed);
    var startMs = Measure(() => run.Start());
    var session = run.Session;
    var collection = session.RuleSet.Collections.Single(c => c.QualifiedId == "base-spire:RunStates").Id;
    var entity = session.State.CollectionMembers(collection).Single();
    var blob = session.State.GetField(entity, session.RuleSet.TypeByQualifiedId("base-spire:Run").FieldIndex("MapDraws")).AsString();
    var words = SourceActMapCompute.ParseWords(blob);
    var final = SourceActMapCompute.Replay(blob, 15);
    // Warm up before comparing deterministic pure calculations.
    SourceActMapCompute.Replay(blob, 15);
    var fullMs = Measure(() => SourceActMapCompute.Replay(blob, 15), 20);
    var prefixesMs = Measure(() => {
        var prefix = "";
        foreach (var word in words) {
            prefix = SourceActMapCompute.AppendWord(prefix, (long)word);
            SourceActMapCompute.Replay(prefix, 15);
        }
    }, 3);
    var materializationMs = Measure(() => {
        for (var i = 0; i < final.Cells.Count + final.Edges.Count; i++)
            SourceActMapCompute.Replay(blob, 15);
    }, 3);
    results.Add(new {
        seed, words = words.Count, nodes = final.Cells.Count, edges = final.Edges.Count,
        replayInvocations = words.Count + final.Cells.Count + final.Edges.Count,
        startMs, fullReplayMs = fullMs, prefixesMs, materializationReplayMs = materializationMs
    });
}
Console.WriteLine(JsonSerializer.Serialize(results, new JsonSerializerOptions { WriteIndented = true }));
