using System.Text.Json;
using BaseSpire.Slice;
using CoreTheSpire.Engine;

var links = new Dictionary<string, string> { ["StrengthPower"] = "strength", ["VulnerablePower"] = "vulnerable" };
var cases = new[] {
    ("existing-tail-conditional", "attack = { damage = 3 } if = { condition = { targetAlive = {} } then = { applyPower = { power = VulnerablePower stacks = 2 target = context.target } } }"),
    ("fixed-and-conditional-power", "applyPower = { power = StrengthPower stacks = 1 target = context.owner } attack = { damage = 3 } if = { condition = { targetAlive = {} } then = { applyPower = { power = VulnerablePower stacks = 2 target = context.target } } }"),
    ("conditional-before-next-effect", "if = { condition = { targetAlive = {} } then = { applyPower = { power = VulnerablePower stacks = 2 target = context.target } } } attack = { damage = 3 }"),
    ("two-distinct-damage-amounts", "attack = { damage = 3 } attack = { damage = 7 }"),
    ("two-equal-damage-amounts", "attack = { damage = 3 } attack = { damage = 3 }"),
    ("single-damage-ten", "attack = { damage = 10 }")
};
var results = new List<object>();
foreach (var (name, effects) in cases)
{
    var variant = "type = attack rarity = common cost = 1 target = { selectOne = { from = context.opponents where = alive } } keywords = {} play = { " + effects + " } hooks = {}";
    var text = "using namespace base-spire; card CouplingProbe { upgradeable = true normal = { " + variant + " } upgraded = { " + variant + " } }";
    File.WriteAllText(name + ".spire", text);
    var source = SpireCardSource.Parse(text, name + ".spire", links);
    results.Add(new {
        name, source.DeclaredCount, source.ParsedCount, source.LoweredCount,
        unsupported = source.Unsupported.Select(x => x.Reason).ToArray(),
        model = source.Cards.Select(c => new { c.NormalAmount, steps = c.NormalSteps.Select(s => s.ToString()).ToArray(), c.NormalConditional }).ToArray()
    });
    if ((name.StartsWith("two-") || name == "single-damage-ten") && source.Cards.Count == 1)
    {
        var original = FormalSpirePackage.Load().Model;
        var model = original with { Cards = source.Cards, Deck = new[] { new AuthorDeckEntry(source.Cards[0].Id, 1) } };
        var builder = new RuleSetBuilder();
        builder.Add(CombatSlicePackage.Build(includeTestHeadbutt: false, fromAuthorText: false, authorModel: model).Build());
        var session = new Session(builder.Build(), 20261001UL, new[] { SliceManifest.PlayerRole }, computeBackend: SourceWeightedPickBackend.Instance);
        session.Start();
        var monsterCollection = session.RuleSet.Collections.Single(x => x.QualifiedId == "base-spire:Monsters").Id;
        var monster = session.State.CollectionMembers(monsterCollection).First();
        var monsterHp = session.RuleSet.TypeByQualifiedId("base-spire:Monster").FieldIndex("Hp");
        var before = session.State.GetField(monster, monsterHp).AsInt();
        var initialBlock = session.State.GetField(monster, session.RuleSet.TypeByQualifiedId("base-spire:Monster").FieldIndex("Block")).AsInt();
        var initialPowerCount = session.State.AllInstances(session.RuleSet.TypeByQualifiedId("base-spire:Power").Id).Count;
        var hand = session.RuleSet.Collections.Single(x => x.QualifiedId == "base-spire:Hand").Id;
        var cardType = session.RuleSet.TypeByQualifiedId("base-spire:Card");
        Console.Error.WriteLine("Probe card id=" + source.Cards[0].Id + "; hand=" + string.Join(",", session.State.CollectionMembers(hand).Select(x => session.State.GetField(x, cardType.FieldIndex("DefinitionId")).AsString())));
        var card = session.State.CollectionMembers(hand).Single(x => session.State.GetField(x, cardType.FieldIndex("DefinitionId")).AsString() == source.Cards[0].Id);
        var action = session.LegalActions(SliceManifest.Player).Single(x => x.Definition.QualifiedId == "base-spire:PlayCard");
        session.Submit(action.Definition, SliceManifest.Player, new[] { Value.OfRef(card) });
        while (session.Status == SessionStatus.AwaitingDecision)
            session.Answer(new DecisionAnswer(session.PendingDecision!.RequestId, new[] { monster }));
        var after = session.State.GetField(monster, monsterHp).AsInt();
        results.Add(new { name = name + "-runtime", before, after, damage = before - after, initialBlock, initialPowerCount, sourceLiteralSum = name == "two-equal-damage-amounts" ? 6 : 10, status = session.Status.ToString() });
    }
}
Console.WriteLine(JsonSerializer.Serialize(results, new JsonSerializerOptions { WriteIndented = true }));
