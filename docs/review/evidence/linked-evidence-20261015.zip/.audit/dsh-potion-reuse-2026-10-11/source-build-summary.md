# ENV-T05-potion-reuse-20261011 源与构建证据

本记录保存 2026-10-11 的执行证据；交付状态只见[固定交接](../../docs/review/tofix/dsh-potion-reuse-handoff-2026-10-11.md)。

## 源核对与实现

| 瓶 | 独立源及语义 | 正式内容结果 |
| --- | --- | --- |
| ExplosiveAmpoule | [原版源](../../sts2/src/Core/Models/Potions/ExplosiveAmpoule.cs)：DamageVar(10m, ValueProp.Unpowered)，HittableEnemies，全体伤害 | [正式源](../../mod-the-spire/base-spire/BaseSpire/ContentSource/potions.spire#L122) 使用 `unpowered = true` 和 `attack = { damage = 10 target = allEnemies }`；复用现有群体IR及动作尾 |
| HeartOfIron | [药水源](../../sts2/src/Core/Models/Potions/HeartOfIron.cs)：PlatingPower 7；[能力源](../../sts2/src/Core/Models/Powers/PlatingPower.cs)：己方回合末 Amount unpowered格挡，后续己方回合开始减1 | [正式源](../../mod-the-spire/base-spire/BaseSpire/ContentSource/potions.spire#L187) 普通链接 `PlatingPower` → `base-spire:plating-power`，已有回合末按层格挡及回合开始递减；未使用敌人 `Plating` |
| LiquidBronze | [药水源](../../sts2/src/Core/Models/Potions/LiquidBronze.cs)：ThornsPower 3；[能力源](../../sts2/src/Core/Models/Powers/ThornsPower.cs)：BeforeDamageReceived 对 powered attack（另有 Omnislice 特例）反伤3，不要求收到伤害大于0 | [正式源](../../mod-the-spire/base-spire/BaseSpire/ContentSource/potions.spire#L194) 保留 unsupportedUse；未创建空效果、别名白名单或公共机制 |

实际正式加载由 [SinglePlayerContentSource](../../mod-the-spire/base-spire/BaseSpire/SinglePlayer/SinglePlayerContent.cs#L67) 完成，只从已加载 Powers 生成普通链接表。[SpirePotionSource](../../mod-the-spire/base-spire/BaseSpire/Slice/SpirePotionSource.cs#L18) 及 [PotionEffectSource](../../mod-the-spire/base-spire/BaseSpire/Slice/Effects/PotionEffectSource.cs) 共用既有编译和链接。只改三瓶的效果/未支持说明，48项元数据、顺序、稀有度和原11项程序未改。原检查独立逐项对照原版池及每瓶属性，最终25项通过。

本包生产/检查改动仅：[potions.spire](../../mod-the-spire/base-spire/BaseSpire/ContentSource/potions.spire)、[PotionReuseChecks.cs](../../mod-the-spire/base-spire/BaseSpire.Slice.Tests/PotionReuseChecks.cs)、[Program.cs](../../mod-the-spire/base-spire/BaseSpire.Slice.Tests/Program.cs)、[PotionFlowChecks.cs](../../mod-the-spire/base-spire/BaseSpire.Slice.Tests/PotionFlowChecks.cs)。Program新增入口及默认调用；PotionFlow仅改支持13/未支持35两处数量与对应文本。

## 局部反馈与更正

- [第一次构建](local-build.log) rc=0；[第一次局部运行](local-reuse.log) rc=-532462766（进程状态3762504530）：检查错误地要求敌人 `Plating` 也已加载。更正为验证通用ID与敌人ID不同，并记录实际链接；不是Power修复。
- [第二次构建](local-build-2.log) rc=0；[第二次局部运行](local-reuse-2.log) rc=-532462766（进程状态3762504530）：五组爆炸伤害通过，但末次击杀检查错误地把剩余其他瓶的 UsePotion 动作当成旧瓶可重复使用。更正为提交已销毁瓶实例、要求 IllegalAction 且状态不变。
- 第二次输出同时确认 `Thorns` 没有进入正式Power表。删除尚未执行的“人为挂未加载Power”的运行探针；不能把它解释为真实Thorns行为。使用实际链接表构造最小编译反例。
- [第三次构建](local-build-3.log) rc=0；[第三次局部运行](local-reuse-3.log) rc=0，11项通过。之后生产与检查内容未再改，执行最终串行门槛。

## 公共缺口最小反例

[检查实现](../../mod-the-spire/base-spire/BaseSpire.Slice.Tests/PotionReuseChecks.cs#L126) 从 `Content.Model.Powers` 构造链接表，分别以 `ThornsPower`、`Thorns` 编译一个仅含 `applyPower stacks=3 target=context.owner` 的 LiquidBronze。两次实际加载程序数均为0；未支持元数据仍保留。正式原瓶不可使用，可丢弃。

[最终反例输出](final-potion-reuse.log#L17)：

```text
power:Thorns: base-spire/enemies.spire: Thorns.events 的事件类型 'before_damage' 未支持（只支持 damage / block / power）；运行时未实现声明的角色/触发器/效果组合：不注册部分生效的能力
potion-reuse/minimal-liquid-bronze.spire(7,13): unregistered power 'ThornsPower'
potion-reuse/minimal-liquid-bronze.spire(7,13): unregistered power 'Thorns'
```

`potion-reuse/minimal-liquid-bronze.spire` 是检查内字符串的诊断名称，不是仓库文件。该反例由 `--potion-reuse-only` 实际执行，不需修改正式源。原版要求的后续反伤矩阵为 powered攻击9→反伤3、powered攻击0→反伤3、unpowered/非攻击→反伤0；这些是源期望，未声称玩家Thorns运行通过。[现有敌人声明](../../mod-the-spire/base-spire/BaseSpire/ContentSource/enemies.spire#L114) 另有 `positiveAmount=true`，即使解决加载仍须核对零伤害及玩家方向；不能直接等同玩家通用Thorns。

## 构建身份与门槛

工作目录 `F:/Scylier-Project/active/auto-the-spire`，SDK 9.0.306，Debug，seed=20261011UL，后端 BaseSpireComputeBackend.Instance。所有构建使用 `--artifacts-path .artifacts/parallel/dsh-potion-reuse`；所有运行DLL均来自同一目录。solution按要求会构建本包目录中的Host/Differential/reference依赖，不使用、覆盖负责人或其他线的DLL/obj/bin。

[构建清单](build-manifest.json) 保存时间、SDK、源及受保护派单记录SHA256。[最终复用日志](final-potion-reuse.log) 保存实际嵌入源摘要：potions `121e32c818cd784b`、ironclad-powers `c60f206794170e26`、enemies `80ee84a0fabc92a1`；正式内容聚合摘要 `7aabc15c408b2f79`。摘要仅标识本次读取内容；不代替共享工作区版本验收。

| 最终串行命令（均从工作目录执行） | rc | 结果/证据 |
| --- | --- | --- |
| `dotnet build AutoTheSpire.sln --artifacts-path .artifacts/parallel/dsh-potion-reuse -c Debug` | 0 | [solution构建](final-solution-build.log)，0错误、1项既有Differential空引用警告；之前局部构建还报告ActMap/SpirePowerSource既有警告 |
| `dotnet .artifacts/parallel/dsh-potion-reuse/bin/Core.TheSpire.Engine.Tests/debug/Core.TheSpire.Engine.Tests.dll` | 0 | [Engine](final-engine.log)，95项通过 |
| `dotnet .artifacts/parallel/dsh-potion-reuse/bin/BaseSpire.Slice.Tests/debug/BaseSpire.Slice.Tests.dll --potion-flow-only` | 0 | [药水流程](final-potion-flow.log)，25项通过，原11瓶、48元数据、库存/领取/丢弃、11/13奖励抽及跨房间回归 |
| `dotnet .artifacts/parallel/dsh-potion-reuse/bin/BaseSpire.Slice.Tests/debug/BaseSpire.Slice.Tests.dll --potion-reuse-only` | 0 | [复用检查](final-potion-reuse.log)，11项通过，含两项未支持/公共缺口检查；支持数量仅新增两瓶 |

最终门槛按表序串行执行一次。完整Slice、net运行、公开Boss/负责人不可变Host轨迹、本包新增瓶正常获得轨迹及训练均未执行。新行为检查加载正式药水/Power，使用受控初始库存、伤害状态和作者双敌战斗，不能算正常获得或公开整幕轨迹。

[末态git状态](git-status-after.log)记录共享工作区已有大量未提交内容；未commit/reset/清理。`git diff --check --`（仅四个授权源/检查路径）rc=0，见[检查日志](diff-check.log)；该命令对未跟踪文件无覆盖，因此不将其等同完整新文件审查。
