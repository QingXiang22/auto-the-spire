$ErrorActionPreference = 'Stop'
$root = 'F:/Scylier-Project/active/auto-the-spire'
$audit = "$root/.audit/dsh-power-fixture-2026-10-11"
$report = Get-Content -Raw "$audit/regression/regression.json" | ConvertFrom-Json
$owner = Get-Content -Raw "$root/.audit/dsh-plan-2026-10-11/owner-regression/regression.json" | ConvertFrom-Json
$before = Get-Content -Raw "$audit/inputs-before.json" | ConvertFrom-Json
$fields = @('case_id','kind','base_source','rng_profile','reference_scope','initialization','game_seed','contents','variants','semantic_actions','required_dimensions','expected_terminal')
$contractMatches = @($report.cases | ForEach-Object {
    $current = $_
    $original = $owner.cases | Where-Object case_id -EQ $current.case_id
    $differences = @($fields | Where-Object { ($current.$_ | ConvertTo-Json -Depth 50 -Compress) -cne ($original.$_ | ConvertTo-Json -Depth 50 -Compress) })
    [ordered]@{ case_id=$current.case_id; matched=($differences.Count -eq 0); mismatched_fields=$differences }
})
if (($report.expected_case_ids -join '|') -cne ($owner.expected_case_ids -join '|') -or @($contractMatches | Where-Object { -not $_.matched }).Count) { throw 'Original denominator or case contracts changed' }
$records = @($report.cases | ForEach-Object {
    $case = $_
    foreach ($side in @('base','reference')) {
        $path = "$audit/regression/records/$side/$($case.case_id).json"
        if (-not (Test-Path $path)) { continue }
        $record = Get-Content -Raw $path | ConvertFrom-Json
        $trajectory = @($record.boundaries | ForEach-Object {
            $boundary = $_
            [ordered]@{ boundary=$boundary.index; kind=$boundary.kind; power_facts=@($boundary.facts | Where-Object path -Like 'power.*') }
        })
        [ordered]@{
            case_id=$case.case_id; side=$side; path=$path.Substring($root.Length+1); sha256=(Get-FileHash $path -Algorithm SHA256).Hash.ToLowerInvariant()
            game_seed=$case.game_seed; profile=$record.rng_profile; status=$record.status
            initialization_random_count=$record.initialization_random_count; script_random=$record.script_random
            initial_state=$record.initial_state; session_identity=$record.session_identity; reference_identity=$record.reference_identity
            power_trajectory=$trajectory
        }
    }
})
$files = @($before.files | ForEach-Object {
    $hash = (Get-FileHash "$root/$($_.path)" -Algorithm SHA256).Hash.ToLowerInvariant()
    [ordered]@{ path=$_.path; before_sha256=$_.sha256; after_sha256=$hash; changed=($hash -cne $_.sha256) }
})
$sourcePaths = @(
    'sts2/src/Core/Commands/PowerCmd.cs','sts2/src/Core/Models/Powers/VulnerablePower.cs','sts2/src/Core/Models/Powers/WeakPower.cs','sts2/src/Core/Models/Powers/StrengthPower.cs','sts2/src/Core/Runs/RunManager.cs',
    'reference/sts2-sim/src/Sts2Sim.Core/Models/PowerModel.cs','reference/sts2-sim/src/Sts2Sim.Core/Models/Powers/VulnerablePower.cs','reference/sts2-sim/src/Sts2Sim.Core/Models/Powers/WeakPower.cs','reference/sts2-sim/src/Sts2Sim.Core/Runs/RunState.cs',
    'mod-the-spire/base-spire/BaseSpire/Slice/Content/slice-content.author','mod-the-spire/base-spire/BaseSpire/Slice/CombatSlicePackage.cs','mod-the-spire/base-spire/BaseSpire/SinglePlayer/BaseSpireRuntimeFactory.cs',
    'tools/differential/README.md','tools/differential/FixtureSuite.cs')
$evidence = [ordered]@{
    task_id='ENV-T04-power-fixture-20261011'; recorded_at=[datetime]::UtcNow.ToString('o'); delivery_status='tooling-delivered-strict-regression-red'
    run_id=$report.run_id; suite_sha256=$report.suite_sha256; exit_code=$report.exit_code; counts=$report.counts; verdicts=$report.verdicts
    original_denominator_preserved=$true; original_contract_comparison=$contractMatches
    file_changes=$files; source_reference_and_tool_hashes=@($sourcePaths | ForEach-Object { [ordered]@{path=$_; sha256=(Get-FileHash "$root/$_" -Algorithm SHA256).Hash.ToLowerInvariant()} })
    protected_dispatch_files=@('task.txt','task-record.json','inputs-before.json' | ForEach-Object { [ordered]@{path=".audit/dsh-power-fixture-2026-10-11/$_"; sha256=(Get-FileHash "$audit/$_" -Algorithm SHA256).Hash.ToLowerInvariant()} })
    random_units_warning='base raw-generator-words and reference native-counter-increments are not comparable absolute units; null remains unknown'
    self_test=$report.self_test; cases=@($report.cases | Select-Object case_id,game_seed,rng_profile,verdict,divergences); records=$records
}
$evidence | ConvertTo-Json -Depth 100 | Set-Content -Encoding utf8 "$audit/delivery-evidence.json"
$records | Where-Object { $_.case_id -in @('power-turn-end-decay','vulnerable-decay-via-bash','random-reshuffle-unsupported') } | ForEach-Object { '{0} {1}: init={2}; script={3}->{4}; proof={5}' -f $_.case_id,$_.side,$_.initialization_random_count,$_.script_random.before,$_.script_random.after,$_.initial_state.applied }
'Original 17 IDs and reported contracts preserved; evidence written.'
