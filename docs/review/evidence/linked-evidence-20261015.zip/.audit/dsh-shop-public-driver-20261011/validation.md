# ENV-T03-shop-public-driver 证据索引 — 2026-10-11 wave 2

- task_id: `ENV-T03-shop-public-driver-20261011`
- dispatch_id（= 派发记录 task_id）: `ENV-T03-shop-public-driver-20261011`
- session_id: `session-a1811025-b9e4-44d0-a2f2-2f7949935ade`
- request_id: `e1cc6a92-f19b-4d6c-85e9-9813ba5b4851`
- dispatch_record: [task-record.json](task-record.json)（`status: accepted`）
- 交接: [docs/review/tofix/dsh-shop-public-driver-handoff-2026-10-11-wave2.md](../../docs/review/records/2026-10-12/dsh-shop-public-driver-handoff-2026-10-11-wave2.md)
- updated_at: `2026-10-11T23:52:50+08:00`

本目录存本包的实际命令、返回码、原始帧与失败分类。长日志在本目录，状态与认领只看主清单。

## 1. 固定输入

| 输入 | 值 |
| --- | --- |
| Host DLL（Codex 固定，本包实跑） | `.artifacts/parallel/owner-flow-review-next-20261011/bin/OwnerHost/debug/Net.TheSpire.Host.dll` |
| Host DLL SHA256 | `78F2CDF57B5D04CDE0FE814933B21ABB041BC9024A41BC4AED285E2F55462B0A` |
| Host build / 身份 | `build=7fda0b085ec671b8`；ruleset `net:ruleset:4fa58ee1b2f76e3f`、catalog `net:catalog:b400d7f332f590cc`、backend `net:backend:simulation-0.2-350911d86bad900d`、protocol `0.2`、profile `base-spire-singleplayer-dev-map-v1` |
| 宿主声明的动作类型 | 17 个，**不含**任何商店动作（`catalog-peek-ownerhost.txt`） |
| wave-1 旧 Host（仅用于离线复算别人的记录） | `.artifacts/parallel/dsh-core-author-04/bin/Net.TheSpire.Host/debug/Net.TheSpire.Host.dll`，SHA256 `805C123D9941454E0B15E704CD48EB107A2E2A26DCC4555DDE8617513D0C1F6D` |
| 本包实跑的 seed | `ENV-T03-SEED-L`、`ENV-T03-SEED-K`、`ENV-T03-SEED-J`、`ENV-T03-SEED-E`、`ENV-T03-SEED-M` |
| 输出范围（scope） | `dev-map`，scenario `formal-dev` |

没有构建任何 C#（未运行 `dotnet build`，未写 `.artifacts` 下的任何构建目录）；只有 Python
语法检查与实际运行。

## 2. 被测与产出文件（写前/写后 SHA256）

| 文件 | SHA256 | 说明 |
| --- | --- | --- |
| `net-the-spire/client/run_game.py` | `77A8F13AB4945D5AA5582A528D78ED7CC8189C4D84881325264BE98E11CAEC9D` | 唯一生产文件：新增商店分支、删牌 decision 区分、`--shop-*` CLI、货架/目录证据字段 |
| `net-the-spire/client/test_shop_public.py` | `030363C0336C5AA8E18FC0CDEAB7DD9DC853795CA2EFB9B4779C99760B318B10` | 同目录唯一机制检查（离线，不启动 Host） |
| `net-the-spire/client/run_game.md` | `3D38062A82522583797D4163EF9E1FC1AC06526C9A3A682E0A12F9D6AD21B57B` | 运行器用法（CLI 表、决策顺序、输出、边界、两波证据） |
| `net-the-spire/client/README.md` | `348332E758635AEE86BF8F2213D26647A00FA6ABB78A1DD0F57F76BA84BB93C3` | 新增"公开商店驱动检查"一节 |
| `docs/design/net-the-spire/how-to-run-public-game.md` | `88ADB038B60638205E696B1F8C815F15B203F8A375BB0051CB710515C02A5B3C` | 教程第 6 节：商店公开交互的实际用法 |
| `docs/review/tofix/dsh-shop-public-driver-handoff-2026-10-11-wave2.md` | `8445EC3D019D504DE76261C9D848480CEE49223006693517BD2F6D87DF87136D` | 本包交接 |

未修改：`net_client.py`、`public_snapshot.py`、`test_potion_host.py`、任何 C#/Host/协议/schema、
`mod-the-spire/**`、`tools/**`、`ai-the-spire/**`、主清单。

## 3. 实际命令与返回码

| 检查 | 命令（仓库根目录，`$env:NET_THE_SPIRE_HOST_DLL` 指向固定 Host） | 返回码 / 结果 | 证据 |
| --- | --- | --- | --- |
| 语法 | `python -m py_compile net-the-spire/client/run_game.py` | rc 0 | — |
| 商店机制检查（全部分组） | `python -X utf8 -u net-the-spire/client/test_shop_public.py` | rc 0，`passed=672 failed=0` | [test-shop-public-full.txt](test-shop-public-full.txt) |
| wave-1 记录逐快照复算（17 个 run、2340 步） | `python -X utf8 -u net-the-spire/client/test_shop_public.py --only replay --run-dir .audit/dsh-public-run-driver-2026-10-11/runs/<RUN>` | 17/17 rc 0 | [replay-sweep-wave1.txt](replay-sweep-wave1.txt) |
| 固定 Host：不进店（`auto`） | `python -X utf8 -u net-the-spire/client/run_game.py --scope dev-map --seed ENV-T03-SEED-L --output .audit/dsh-shop-public-driver-20261011/runs/prefix-seed-L-auto --max-actions 80 --use-potions` | rc 4，`unsupported_map_room`，19 步 | `runs/prefix-seed-L-auto/`、[run-prefix-seed-L-auto.txt](run-prefix-seed-L-auto.txt) |
| 固定 Host：强制进店（负对照） | 同上但 `--shop-room enter --shop-policy buy --shop-remove` | rc 4，`fault_host_rejected`（`backend_fault`：房间类型 商店 尚未实现），19 步 | `runs/prefix-seed-L-enter-shop/`、[run-prefix-seed-L-enter-shop.txt](run-prefix-seed-L-enter-shop.txt) |
| 固定 Host：正常前缀 seed-K | 同上，`ENV-T03-SEED-K`，`--max-actions 400` | rc 4，127 步后在 `StartNextRoom` 撞宿主内容缺口 | `runs/prefix-seed-K/`、[run-prefix-seed-K.txt](run-prefix-seed-K.txt) |
| 固定 Host：seed-J / seed-E / seed-M | 同上，`--max-actions 260` | J 94 步、E 105 步（同一内容缺口）；M 46 步 `unsupported_map_room` | `runs/prefix-seed-{J,E,M}/`、`run-prefix-seed-*.txt` |
| 新旧脚本同 Host A/B | `python -X utf8 -u .audit/dsh-shop-public-driver-20261011/tools/compare-runs.py runs/prefix-baseline-seed-L runs/prefix-seed-L-auto` | rc 0，`语义差异=0 仅句柄不同=19` | [compare-seed-L-baseline-vs-new.txt](compare-seed-L-baseline-vs-new.txt) |
| 相位覆盖 | `python -X utf8 -u .audit/dsh-shop-public-driver-20261011/tools/phase-coverage.py runs` | battle/travel/reward 覆盖；无 treasure/rest/shop | [phase-coverage-fixed-host.txt](phase-coverage-fixed-host.txt) |
| 商店证据字段 | `python -X utf8 -u .audit/dsh-shop-public-driver-20261011/tools/shop-evidence.py runs/prefix-seed-L-auto runs/prefix-seed-L-enter-shop runs/prefix-seed-M` | 见输出 | [shop-evidence.txt](shop-evidence.txt) |
| wave-1 分支覆盖 | `python -X utf8 -u .audit/dsh-shop-public-driver-20261011/tools/branch-coverage.py` | 见输出 | [branch-coverage.txt](branch-coverage.txt) |
| 宿主目录声明 | `python -X utf8 -u .audit/dsh-shop-public-driver-20261011/tools/catalog-peek.py` | 17 个动作，0 个商店动作 | [catalog-peek-ownerhost.txt](catalog-peek-ownerhost.txt) |

`prefix-baseline-seed-L` 是**改动前**的 `run_game.py` 在同一 Host、同一 seed、同一 scope 上的基线
（本包开工第一步跑的），用于 A/B 比较；其余 `runs/prefix-*` 都用最终脚本。

## 4. 复算结果（wave-1 记录，当前规则）

`replay-sweep-wave1.txt` 的逐 run 结果：17 个记录共 **2340 步**全部复算，**每一步挑的候选都在该
快照当前的 `legal_actions` 里**（候选闭合 2340/2340）。其中 **1844 步**与记录的动作和
`candidate_id` **逐字一致**；`seed-F`／`seed-I`／`seed-J`／`seed-K`／`seed-K-repeat`／`seed-L`／
`seed-M` 这 7 个 run 的记录**整局没有任何旧变体步骤**（共 960 步，全部逐字一致）。其余 496 步的
`reason` 自报为 wave-1 试过的旧规则变体（低血先格挡 / 同类里费用低者先 / 无门槛用药水 / 旧地图偏好），
按动作名与候选闭合核对，首差例子：

| 记录 | 首差 | 记录的选择 | 当前规则的选择 | 原因（记录自报） |
| --- | --- | --- | --- | --- |
| `seed-B` | step 9 / obs 1620 | `PlayCard` `strike-ironclad`（cost 1） | `PlayCard` `bash`（Amount 8） | `combat: 先出攻击牌(同职业里费用低的先)` |
| `seed-G` | step 133 / obs 5761 | `PlayCard` `defend-ironclad` | `PlayCard` `bash` | `combat: 低血先格挡` |
| `act1-potions-A3` | step 73 / obs 3918（Hp 66/80） | `UsePotion` `e142` | `PlayCard` | `combat: use potion e142 (UseSupported=true)` |
| `smoke-6` / `act1-full-A` | step 1 / obs 1426 | 另一个 `Monster` 节点 | `e42` | `map: implemented room type preferred` |

这些差异来自**记录本身**（`reason` 是当时驱动器写的），不是本包改动：`run_game.py` 的地图/奖励/
营火/战斗/药水/decision 代码路径除商店分支外未改（见 §2 文件与交接的修改清单）。

## 5. 固定 Host 上的边界（本包实跑，逐条留证）

| 现象 | 具体值 | 判断 |
| --- | --- | --- |
| 地图只提供 `Shop` 节点 | `seed-L` 19 步、`seed-M` 46 步 → `unsupported_map_room`、退出码 4、`run_complete=false` | 开发边界，非故障；`auto` 不进店是因为宿主目录没有声明商店动作 |
| 强制进店 | `--shop-room enter` → 宿主 `backend_fault`：`房间类型 商店 尚未实现` → `fault_host_rejected`、退出码 4 | 商店在该 Host 上**未接线**；**没有**写成商店通过 |
| 正常前缀内容缺口 | `seed-K` 127 步 / `seed-J` 94 步 / `seed-E` 105 步 → `StartNextRoom`：`missing enemy behavior base-spire:fogmog`（K）与 `base-spire:cubex-construct`（J/E） | 固定 Host 的**内容缺口**（敌人行为未登记），与商店/驱动器无关；更长前缀与 treasure/rest/shop 相位在本 Host 上不可达 |
| 会话内句柄 | `candidate_id` / 实体引用跨会话不同（`compare-runs.py` 的"仅句柄不同"） | 公开语义键稳定、句柄按会话绑定；跨会话比较只能比语义层 |

## 6. 未验证 / 依赖

1. **真实公开商店轨迹未验证**：本包没有拿到"商店已接线"的同构建 Host，因此
   `地图 → 商店 → 公开商品选择/删牌 decision → 离店 → 回地图` 的原始帧与长期变化**未产生**。
   依赖 **ENV-T09 最终 Host**；`run_game.py` 的商店分支与 `--shop-*` 已就绪，届时同一条脚本加
   `--shop-room auto --shop-policy buy --shop-remove` 即可取证。
2. **`ActCompleted` / 幕转换、treasure/rest 相位在固定 Host 上未到达**（沿用 wave-1 的未覆盖结论；
   离线复算里 seed-K/E/J 的 treasure/campfire 决策已按当前规则逐字复现）。
3. **满药水栏购买、金币不足、删牌涨价（第二次进店）等 Engine 守卫**在本包里只由合成快照与
   A 侧的候选域语义覆盖，没有真实商店 Host 上的现场拒绝证据。
4. 本包**没有**运行 C# 侧套件、`dotnet build`、Slice/Engine/net 套件，也没有跑 `tools` 冒烟脚本
   （B 线文件，未触碰）。

## 7. 只读契约复核与文档检查

**A 侧公开契约只读复核**（消费方核对，不改 A 的文件）：`mod-the-spire/base-spire/BaseSpire/Slice/ShopRoomWiring.cs`
在本包工作期间被 A 持续编辑（复核时 SHA256 `9EE5E0924FC50E31B46183E221773DAC376BB012C72E8111F4F946AEB4D83847`，
66954 字节，mtime 2026-10-11 23:19:04）。复核结果：本包消费的符号**未变**——
动作名 `BuyShopCard`/`BuyShopRelic`/`BuyShopPotion`/`RemoveShopCard`/`LeaveShop`、集合 `ShopOffers`、
Run 字段 `ShopCardRemovalsUsed`、`ShopOffer` 的 12 个公开字段（`Slot`/`Kind`/`DefinitionId`/`SourceName`/
`Rarity`/`PoolKind`/`PoolIndex`/`OnSale`/`Price`/`Sold`/`Unsupported`/`UnsupportedReason`）、删牌用
`DecisionResponseKind.EntityRef` 发正式 decision；并且 `BuyableOffers`（候选域）与 `BuyGuard`（守卫）
仍然是同一组条件（种类 / 未售 / 非 `Unsupported` / 金币足够 / 药水栏有位置），因此"候选就是当前可买的"
这一前提成立，客户端不需要重判资金或容量。

同时观察到共享工作区里的并行改动：`mod-the-spire/base-spire/workpacks/shop-flow/*.cs` 已由 A 改名为
`*.cs.frozen-20261011`（商店模块正式进入 `BaseSpire/Slice/`），因此
[`dsh-shop-flow-handoff-2026-10-11.md`](../../docs/review/records/2026-10-11/dsh-shop-flow-handoff-2026-10-11.md)
里指向这两个 workpack 文件的链接现在失效。本包**没有**改这些文件，只记录现象。

| 检查 | 命令 | 结果 |
| --- | --- | --- |
| 文档检查 | `python -X utf8 tools/doc-check/check_docs.py` | 扫描 421 个 Markdown，报 **6 个既有失败**（`dsh-shop-flow-handoff-2026-10-11.md` 的两个 workpack 链接被 A 的改名打断；`dsh-power-fixture-handoff-2026-10-11.md` 与 `dsh-startup-alignment-handoff-2026-10-11-f68b943d.md` 的行锚点链接）。本包新增/改动的 5 份文档**没有**报告问题（修掉了自己一度引入的一个目录链接） |
| 空白检查 | `git diff --check` | rc 0（本包改动都在未跟踪目录里，该命令只覆盖已跟踪文件的改动） |
