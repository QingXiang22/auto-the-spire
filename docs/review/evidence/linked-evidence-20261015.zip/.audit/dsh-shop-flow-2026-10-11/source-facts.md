# 源依据：商店（Merchant）机制逐条核对

只读核对 `sts2/src/Core/**`（源树，未修改）。行号以下文核对时的版本为准。
所有"引擎口径"指本 Slice 用 `VanillaRandomLayout` + `SampleInt` 复现时的对应物。

## 1. 随机流归属（最容易搞错）

- 源玩家级流枚举 `sts2/src/Core/Entities/Rngs/PlayerRngType.cs`：`Rewards, Shops, Transformations`（顺序即枚举序）。
- `sts2/src/Core/Random/PlayerRngSet.cs:19-29` 三个属性；`:43-47` `CreateRng` 用 `StringHelper.SnakeCase(enum)` 作流名；`sts2/src/Core/Random/Rng.cs:52-55` 种子混入名字哈希。
- 本 Slice 对应物（`mod-the-spire/base-spire/BaseSpire/Slice/VanillaRandomLayout.cs`）：
  - `:44-45` `PlayerStreamTypes = ["Rewards", "Shops", "Transformations"]`；
  - `:113-115` `EnginePlayerStreamName(t) => $"base-spire:player:{SnakeCase(t)}"`；
  - `:37-42` `RunStreamTypes` 12 条里**没有**任何商店流。
  - ⇒ 商店使用 `base-spire:player:shops` 与 `base-spire:player:rewards`，两套计数器独立。

| 抽取点 | 源 | 流 |
| --- | --- | --- |
| 打折格下标 `NextInt(5)` | `MerchantInventory.cs:100` | Shops |
| 彩卡稀有度 roll（`RollWithoutChangingFutureOdds`） | `CardFactory.cs:50` → `CardRarityOdds.cs:98` | **Rewards**（`PlayerOddsSet.cs:24` `CardRarity = new CardRarityOdds(rng.Rewards)`） |
| 彩卡选卡 `NextItem(items)` | `CardFactory.cs:57` | Shops |
| 彩卡升级 roll `RollForUpgrade(..., -999999999m)` | `CardFactory.cs:58` → `:285` | **Rewards**（无条件消费） |
| 无色卡选卡 `NextItem` | `CardFactory.cs:78` | Shops |
| 无色卡升级 roll | `CardFactory.cs:79` | **Rewards** |
| 卡价抖动 `NextFloat(0.95f,1.05f)` | `MerchantCardEntry.cs:124` | Shops |
| 遗物稀有度 `RollRarity` ×2 | `MerchantInventory.cs:128-131` → `RelicFactory.cs:82` | **Rewards**（第 3 格固定 `RelicRarity.Shop`） |
| 遗物价抖动 `NextFloat(0.85f,1.15f)` | `MerchantRelicEntry.cs:44` | Shops |
| 药水生成（3 瓶） | `MerchantInventory.cs:143` | Shops |
| 药水价抖动 `NextFloat(0.95f,1.05f)` | `MerchantPotionEntry.cs:69` | Shops |
| 删牌 | `OneOffSynchronizer.cs:87-102` | 无随机（玩家选牌） |

单张彩卡抽数 = Rewards ×2 + Shops ×1；单张无色卡 = Rewards ×1 + Shops ×1。`RunState.CreateCard`（`RunState.cs:383-389`）**不消费随机数**（`ToMutable`/`AddCard`/`AfterCreated` 均无 Rng）。Hook 默认实现（`AbstractModel.cs:1750/1761/1774`、`:1537-1540`）不消费。

## 2. 阈值与价格常量

- 商店卡稀有度（`Odds/CardRarityOdds.cs`）：`:39` `ShopCommonOdds = Scarcity ? 0.585f : 0.54f`；`:25`/\`:154` `shopUncommonOdds = 0.37f`；`:41` `ShopRareOdds = Scarcity ? 0.045f : 0.09f`；偏移 `_baseRarityOffset = -0.05f`、`_maxRarityOffset = 0.4f`、`RarityGrowth = Scarcity ? 0.005f : 0.01f`。
  - `CardRarityOdds.cs:96-110` 判定顺序：`num = NextFloat(); if (num < ShopRareOdds + offset) Rare; else if (num < 0.37f + ShopRareOdds + offset) Uncommon; else Common;`，其中 `offset` 是传入的**持久 `CurrentValue`**（此处 `RollWithoutChangingFutureOdds` 只读不写）。
  - 允许性回绕 `GetNextAllowedRarity`（`CardFactory.cs:263-281`）+ `CardRarityExtensions.cs:14-31`（`Common→Uncommon→Rare→Common`，其余→None）；一圈回起点返回 `None` 并抛 `InvalidOperationException`。
- 药水稀有度（`PotionFactory.cs:67-81`）：`num = NextFloat(); num <= 0.1f → Rare; num <= 0.35f → Uncommon; else Common;`，再在同稀有度列表里 `NextItem`，并 `list.Remove(item)`（只影响本次调用局部列表）。
- 遗物稀有度（`RelicFactory.cs:80-94`）：`num = NextFloat(); num < 0.5f → Common; num < 0.83f → Uncommon; else Rare;`。
- 卡价（`MerchantCardEntry.cs:38-51,118-129`）：`Rare 150 / Uncommon 75 / 其它 50`；无色池 `(int)MathF.Round(base * 1.15f)`；再 `Mathf.RoundToInt(base * Shops.NextFloat(0.95f,1.05f))`；在售 `/= 2`（整数除）。在售格 `SetOnSale()` 会**再算一次价**（第二次抖动）。
- 遗物价（`Models/RelicModel.cs:304-315`）：`Common 175 / Uncommon 225 / Rare 275 / Shop 200 / Ancient|Starter|Event 999999999 / None 1`；逐遗物可 override（9 个 `Fake*.cs` 全为 50）；再 `(int)Math.Round(cost * Shops.NextFloat(0.85f,1.15f))`。
- 药水价（`MerchantPotionEntry.cs:50-58,60-71`）：`Rare 100 / Uncommon 75 / 其它 50`；`TestMode.IsOff` 时 `(int)MathF.Round(base * Shops.NextFloat(0.95f,1.05f))`。
- 删牌价（`MerchantCardRemovalEntry.cs:20-33`）：`BaseCost + PriceIncrease * player.ExtraFields.CardShopRemovalsUsed`，`BaseCost = Inflation ? 100 : 75`，`PriceIncrease = Inflation ? 50 : 25`；本 Slice 无 Ascension ⇒ 75 + 25n（价格序列 75/100/125…）。`CardShopRemovalsUsed` 跨整局累计（`ExtraPlayerFields.cs:10-14`，存档键 `card_shop_removals_used`）。
- 药水栏容量：`Player.initialMaxPotionSlotCount = 3`（`Players/Player.cs:28`），对应本 Slice `SliceManifest.PotionSlotCount = 3`。

## 3. 库存生成顺序（`MerchantInventory.cs:78-156`）

1. `PopulateCharacterCardEntries`：先 `num = PlayerRng.Shops.NextInt(5)`（`:100`，决定折扣格），再按 `_coloredCardTypes = [Attack, Attack, Skill, Skill, Power]`（`:15-22`）逐格 `new MerchantCardEntry(...).Populate()` 后加入；`num == i` 的那格 `SetOnSale()`（`:107-110`）。黑名单 = 本库存**已经加入**的卡（`:71` `CardEntries => CharacterCardEntries.Concat(ColorlessCardEntries)`，`:74` `_cardPool.Except(second)`）。
2. `PopulateColorlessCardEntries`：`ModelDb.CardPool<ColorlessCardPool>()`，按 `_colorlessCardRarities = [Uncommon, Rare]`（`:24-28`）各建一格。
3. `PopulateRelicEntries`：先算 `[RollRarity(Player), RollRarity(Player), RelicRarity.Shop]`（**先全部求值**），再 `foreach` `AddRelicEntry`。
4. `PopulatePotionEntries`：`CreateRandomPotionsOutOfCombat(Player, 3, PlayerRng.Shops)` 先全部生成，再逐个包成 `MerchantPotionEntry(item.ToMutable(), Player)`。
5. `CardRemovalEntry = new MerchantCardRemovalEntry(player)`，然后给 `AllEntries` 每个挂 `PurchaseCompleted += UpdateEntries`。

遗物取货（`MerchantRelicEntry.cs:37-40`）：`RelicFactory.PullNextRelicFromBack(player, rarity, r => (blacklist==null || !blacklist.Contains(r)) && r.IsAllowedInShops).ToMutable()`；`RelicGrabBag.PullFromBack`（`Runs/RelicGrabBag.cs:148-173`）从 `Count-1` 递减取第一个命中并 `RemoveAt`（**袋尾**），随后 `RelicFactory` 再从 `SharedRelicGrabBag` 移除；空袋回退 `Shop→Common→Uncommon→Rare→None`，最后 `_mpFallbackDequeue`；`FallbackRelic = ModelDb.Relic<Circlet>()`（`Models/Relics/Circlet.cs`：`Rarity => RelicRarity.None`、`IsStackable => true`）。`RelicCmd.Obtain`（`Commands/RelicCmd.cs:35-55`）不消费随机数。
回补（`MerchantRelicEntry.cs:73-77`）：`FillSlot(RelicFactory.RollRarity(_player), blacklist)`（仍 **Rewards**）。
药水回补（`MerchantPotionEntry.cs:100-104`）：算了 `hashSet` 却传 `Array.Empty<PotionModel>()`（源偏差点，本 Slice 记录、不复制）。

## 4. 购买与写回

- `MerchantEntry.cs`：`:19-30` `Cost` 在 `CurrentRoom is MerchantRoom` 时套 `Hook.ModifyMerchantPrice`；`:32` `EnoughGold => Cost <= player.Gold`；`:69-96` 基类 wrapper 顺序 = 未库存 → `FailureOutOfStock`；金币不足 → `FailureGold`；否则 `OnTryPurchase`，成功后按 `Hook.ShouldRefillMerchantEntry` 走 `RestockAfterPurchase` 或 `ClearAfterPurchase`，再 `Hook.AfterItemPurchased`，最后 `InvokePurchaseCompleted`。
- 卡（`MerchantCardEntry.cs:131-149`）：先 `CardPileCmd.Add(card, PileType.Deck)`（失败 → `FailureSpace`，返回 `(false,0)`），再非 ignoreCost 时 `PlayerCmd.LoseGold(Cost, player, GoldLossType.Spent)`；无色池记 `BoughtColorless`；返回 `(true, Cost)`。
- 遗物（`MerchantRelicEntry.cs:55-70`）：先 `LoseGold(Cost)`，再 `BoughtRelics` + `RelicCmd.Obtain`。
- 药水（`MerchantPotionEntry.cs:73-93`）：先 `PotionCmd.TryToProcure(Model, player)`；失败按 `NotAllowed → FailureForbidden`、否则 `FailureSpace`（`TooFull`），返回 `(false,0)` **不扣金**；成功才 `LoseGold` + `BoughtPotions`。
  - `PotionCmd.TryToProcure`（`Commands/PotionCmd.cs:16-53`）：hook 拒绝 → `NotAllowed`；`Player.AddPotionInternal`（`Players/Player.cs:624-666`）：`slotIndex < 0` 时取 `_potionSlots.IndexOf(null)`，槽已占或找不到空槽 → `TooFull`。
- 删牌（`MerchantCardRemovalEntry.cs` + `Multiplayer/Game/OneOffSynchronizer.cs:87-102`）：wrapper **不检查 `IsStocked`**，只查金币；`OnTryPurchase` 先 `if (Used) return (false,0)`；选牌 `CardSelectCmd.FromDeckForRemoval`（`Commands/CardSelectCmd.cs:621-625`）= 牌堆实例过滤 `c.IsRemovable`（`CardModel.cs:737` `!Keywords.Contains(CardKeyword.Eternal)`），Curse 排最后；只有选到实例才 `LoseGold(goldCost)` → `CardPileCmd.RemoveFromDeck(card)`（非 Deck 抛 `InvalidOperationException`）→ `CardShopRemovalsUsed++`；取消 = 不扣金、不删、不计数。扣金实现在删牌之前（`PlayerCmd.cs:178-200`：`Gold = int.Max(0, Gold - amount)`）。成功后 `OnCardRemovalUsed()` → `SetUsed()`（`Nodes/Screens/Shops/NMerchantCardRemoval.cs:94-98`），店里 `Used` 不持久化 ⇒ 每次进店只能删一次，价格上涨只体现在下一次进店。

## 6. 选卡细节（`CardFactory.cs`）

- 彩卡同稀有度多张：`CardFactory.cs:56-57` `items = optionsArr.Where(c => c.Rarity == rarity2 && c.Type == type).ToList()` → `Shops.NextItem(items)`；**无 shuffle**，顺序 = 传入 `options` 顺序（`Except` 保持首序列顺序），根顺序 = `CardPoolModel.cs:75 GenerateAllCards()` 的声明顺序。
- 无色路径 `CreateForMerchant(player, options, CardRarity rarity)`（`CardFactory.cs:69-80`）：过滤**只按稀有度**（无 `CardType`）、**不调 `GetNextAllowedRarity`**、**不抽稀有度**；仍 1× `Shops.NextItem` + 1× Rewards 升级 roll。
- `RollForUpgrade`（`CardFactory.cs:283-305`）：`decimal num = (decimal)rng.NextFloat();` 在 `card.IsUpgradable` 判断**之前**，故**无条件消费 1 次 Rewards**；`-999999999m` 时 `num <= originalOdds` 恒 false ⇒ 商店卡不经此升级，实际升级只来自 `Hook.ModifyMerchantCardCreationResults`（MoltenEgg/FresnelLens 等），不消费随机数。
- `Hook.ModifyMerchantCardPool/ModifyMerchantCardRarity/ModifyMerchantCardCreationResults/ModifyMerchantPrice` 默认实现均不消费随机数。
- 折扣 hook（本 Slice 未建模）：`MembershipCard` ×0.5、`TheCourier` ×0.8（`MerchantEntry.cs:24-29`）。

## 5. 离店

`Rooms/MerchantRoom.cs`：`Exit(runState)`（非 TestMode）把**未售出**的彩卡+无色卡以 `CardChoices{wasPicked:false}`、遗物与药水以 `ModelChoiceHistoryEntry` 写入 `CurrentMapPointHistoryEntry.GetEntry(player.NetId)`；`Resume` 抛 `NotImplementedException`。
