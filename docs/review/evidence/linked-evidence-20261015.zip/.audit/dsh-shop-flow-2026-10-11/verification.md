# ENV-T09.2 商店流程隔离包 — 验证记录（2026-10-11）

- task_id: `ENV-T09-shop-flow-parallel-20261011`
- session_id: `session-7fab171b-624d-4018-8a74-2c97e4fc8959`
- 任务记录: [task-record.json](task-record.json)
- 源事实: [source-facts.md](source-facts.md)（源行号与逐字常量）
- 原始运行输出: [verification-run.txt](verification-run.txt)

## 1. 输入（冻结二进制，只读引用，未写回工作区）

```
D499BB1C9D08181B122537F3018D48D1B9B57B4B8E31666B1B837C9B50896BBE  BaseSpire.dll
2EC0B3F9C1BDB9617CB70D53407B20D953A51169050A54F4E1BB33EC31DCC317  Core.TheSpire.dll
```

路径：`.artifacts/parallel/dsh-core-author-04/bin/BaseSpire/debug/`（哈希用
`Get-FileHash -Algorithm SHA256` 现场核对，与任务书一致）。验证工程**没有** `ProjectReference`，
也没有把这两个 DLL 复制回源码树。

被测源码（工作包内的两个文件，验证时按 SHA256 逐字节固定）：

```
FAF5F232BDD843F625D470666DFB05FD707D48C47F257273CE3B37EBF30E25FC  mod-the-spire/base-spire/workpacks/shop-flow/ShopCompute.cs
2F56969EB6B49F8893D2A8130FBF606A446B2A46D84AE287B456DA9A19E930F3  mod-the-spire/base-spire/workpacks/shop-flow/ShopRoomWiring.cs
BBFEC483541B0CDDBAD8A3F0B4E2E7B14F954FA58FE6EE791AD779C7C16ACE4D  mod-the-spire/base-spire/workpacks/shop-flow/ShopFlowChecks/Program.cs
2A5A93F8736839B6F3FFDF0A5551439E3DFEE16694691BA3BBDB696D2D88B17B  mod-the-spire/base-spire/workpacks/shop-flow/ShopFlowChecks/ShopFlowHarness.cs
6C0011EE3444808843A75F241B650583C09D3411105A5479119E8100C994C03F  mod-the-spire/base-spire/workpacks/shop-flow/ShopFlowChecks/Check.cs
B2E25A467A20C30059DC1ED36721C9EFB8B1D1D2D8B0F16D1282EC001B747160  mod-the-spire/base-spire/workpacks/shop-flow/ShopFlowChecks/ShopFlowChecks.csproj
```

## 2. 命令与返回码

```powershell
# 构建（仓库根目录）
dotnet build mod-the-spire/base-spire/workpacks/shop-flow/ShopFlowChecks/ShopFlowChecks.csproj `
  -c Release --artifacts-path .artifacts/parallel/dsh-shop-flow
# → 已成功生成（0 warning / 0 error）

# 运行
dotnet .artifacts/parallel/dsh-shop-flow/bin/ShopFlowChecks/release/ShopFlowChecks.dll
# → exit code 0；passed=13 failed=0（完整输出见 verification-run.txt）
```

验证工程自带组合计算后端：`ShopCompute.TryExecute(asset.Entry, inputs, outputs)` 命中即返回，否则
逐字转发冻结的 `BaseSpireComputeBackend.Instance`（药水/宝箱/地图资产仍走原后端；后端 Id 相同，
因此正式集成只需在 `BaseSpireComputeBackend.Execute` 里加同一行委派）。

## 3. 13 条检查与它们各自能判别的错误

| 检查 | 判别点 |
| --- | --- |
| 库存：14 格源顺序 / 彩卡类型序列 / 无色固定稀有度 / 唯一折扣格 / 遗物可买判据 | 商品顺序、`_coloredCardTypes = [Attack,Attack,Skill,Skill,Power]`、彩卡按 identity 不重复、无色两格固定 uncommon/rare 且来自无色池、只有彩卡区可能在售、`Unsupported` 判据 = 是否在 `SpireRelics` 里登记 |
| 流序：Shops/Rewards 抽数与价格区间 | 每笔抽数都有来源（Shops 25 / Rewards 14，见 §4 的退化说明）；彩卡价 150/75/50×[0.95,1.05)、在售价整除 2、无色 ×1.15（区间与同稀有度彩卡不相交）、遗物 175/225/275/200×[0.85,1.15)、药水 100/75/50×[0.95,1.05) |
| 流序：首张彩卡稀有度 = 独立重放 | 用 `RandomService` + `VanillaRandomLayout.SeedAllStreams` 独立重放"折扣格（Shops）+ 首张彩卡稀有度（Rewards）"，按源阈值（0.09/0.37 + 持久 offset）算出期望稀有度并与货架对账 |
| 金币不足 | 提交被明确拒绝（`SessionStateInvalid` + 具名消息），金币/牌组/售出状态/抽数全部不变 |
| 买卡 | 真实长期牌进入 `LongTermDeck`、定义与货架一致、扣金恰好一次、售罄后再提交被拒且不变 |
| 买遗物 | 先扣金 → 建 `Relics` 持有实例 → 执行 `AfterObtained` 效果（Pear +10 MaxHp 同时回血；判定按登记表计算） |
| 未登记效果的遗物 | 源清单袋里必然出现未登记遗物；它被标 `Unsupported` + 具名原因，提交被拒且金币/遗物/售出状态不变 |
| 买药水 | 进药水栏最低空槽（0/1/2）、扣金一次、栏内定义 = 买到的那几瓶 |
| 满药水栏 | 3/3 时重进商店再买被拒（`药水栏已满`），金币与药水栏不变 |
| 删牌 | 同定义两实例只删**被选中的那个**（另一实例仍在）、扣 75、`ShopCardRemovalsUsed` +1、售罄后该商品不在任何候选域、下一间价格 = 100（75 + 25×1） |
| 离店 | 相位回到 2（`TravelReady`）；离店后四个购买动作都不合法 |
| 重复进店 | 重进后仍是 14 格且没有残留的售出状态 |
| 药水 pick 路径（非退化格） | 换 seed 找到**非退化**药水格：定义来自药水池、`Unsupported=false`、货架稀有度 = 该药水的稀有度、价格按掷出的稀有度基准（本轮 `SHOP-POTION-LIVE-0` 有 2 格） |

## 4. 抽数对账（本轮内容下的实测值）

`SHOP-STREAMS-20261011` 实测：**Shops 26 / Rewards 14**（验证输出第 7 行打印实测值）。

```
Shops  26 = 1 折扣 + 5×(选卡 1 + 价格 1) + 1 在售价 + 2×(选卡 1 + 价格 1) 无色
           + 3 遗物价 + 3 药水价 + (3 药水稀有度 + 3 药水 pick − 2 退化 pick)
Rewards 14 = 5 彩卡稀有度 + 5 彩卡升级 + 2 无色升级 + 2 遗物稀有度
```

退化格数随 seed 变化（该 seed 的 3 个药水格里有 2 格落在 `common`）：本轮内容的
`PotionInventoryRules.Pool` 只有 2 瓶（`rare=1, uncommon=1`，可用 2 瓶），而 `common` 桶为空，
因此这些格是**退化格**：模块不抽那笔 pick、把该格标成 `Unsupported` + `PotionBucketReason`，
购买被明确拒绝。源侧在同样的内容下会在空候选上抛异常。
正常路径（各稀有度桶非空）的抽数是 `ShopRoomWiring.ExpectedShopsDraws = 28` /
`ExpectedRewardsDraws = 14`，验证程序按 `28 − 退化格数` 对账。

验证输出里同时打印了药水池构成、三个药水格的 `rarity/id/poolIndex/unsupported`，以及非退化格出现在哪个
seed，便于复核这条退化路径与 pick 路径。

## 5. 本轮未覆盖（不得当作已验证）

- **没有**跑正式 `--scope dev-map` 的公开整局：`MapRoomWiring` 目前把 `Shop` 房型判为未实现并具名
  `Fail`，公共运行器会在该节点停成 `unsupported_map_room`；本包的验证走的是自带最小宿主的真实 Engine 会话。
- **没有**双侧/公开协议对拍，也没有宣布官方 Run 通过。
- 未建模（见交接）：遗物 `IsAllowedInShops` 与"已见"过滤、`Hook.ModifyMerchantPrice` 折扣
  （MembershipCard/TheCourier）、`Hook.ShouldRefillMerchantEntry` 补货、`ModifyMerchantCardCreationResults`
  升级、`FailureSpace`（牌位上限）、删牌的 `IsRemovable`/Eternal 过滤、遗物 `MerchantCost` 覆盖、
  `MarkRelicAsSeen`/`BoughtColorless|Relics|Potions` 历史、`MerchantRoom.Exit` 的地图点历史写入、
  飞升（Ascension）删牌价变体。
