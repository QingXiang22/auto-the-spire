import json, subprocess
from pathlib import Path
out = Path(__file__).parent
tool = 'tools/base-spire-dev/bin/Debug/net9.0/BaseSpire.Dev.dll'
results=[]
for keyword in ['', 'exhaust']:
    name='hook-external-exhaust' if not keyword else 'hook-own-exhaust'
    variant='type = skill rarity = common cost = 0 target = { selectSelf = {} } keywords = { '+keyword+' } play = { gainBlock = { amount = 1 } } hooks = { onExhaust = { gainBlock = { amount = 2 } } }'
    source='using namespace context-review; card HookProbe { normal = { '+variant+' } upgraded = { '+variant+' } }'
    path=out/(name+'.spire')
    path.write_text(source+'\n', encoding='utf-8')
    command=['dotnet',tool,'check',str(path)]
    process=subprocess.run(command,capture_output=True,text=True,encoding='utf-8',errors='replace')
    (out/(name+'.log')).write_text(process.stdout+process.stderr,encoding='utf-8')
    result=dict(name=name,command=command,exit_code=process.returncode,output=json.loads(process.stdout))
    results.append(result)
    print(json.dumps(dict(name=name,exit_code=process.returncode,output=result['output']),ensure_ascii=False))
assert results[0]['exit_code']==2 and results[0]['output']['parsed']==1 and results[0]['output']['lowered']==0
assert results[1]['exit_code']==0 and results[1]['output']['registered']==1
(out/'hook-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
