import hashlib, json, subprocess, time
from pathlib import Path

out = Path(__file__).parent
root = Path.cwd()
def variant(cost, play):
    return 'type = attack rarity = common cost = '+str(cost)+' target = { selectOne = { from = context.opponents where = alive } } keywords = {} play = { '+play+' } hooks = {}'
cards = {
    'combo': 'using namespace context-review; card Combo { normal = { '+variant(1, 'attack = { damage = 2 } gainBlock = { amount = 3 } attack = { damage = 5 }')+' } upgraded = { '+variant(1, 'attack = { damage = 3 } gainBlock = { amount = 4 } attack = { damage = 8 }')+' } }',
    'upgrade-cost': 'using namespace context-review; card CostProbe { normal = { '+variant(2, 'attack = { damage = 2 }')+' } upgraded = { '+variant(1, 'attack = { damage = 3 }')+' } }',
    'existing-power': 'using namespace context-review; card PowerCombo { normal = { '+variant(0, 'applyPower = { power = base-spire:strength stacks = 2 target = context.owner } attack = { damage = 3 }')+' } upgraded = { '+variant(0, 'applyPower = { power = base-spire:strength stacks = 3 target = context.owner } attack = { damage = 4 }')+' } }',
    'new-power': 'package review-mod { power QuietArmor { trigger = afterCardExhausted effect = gainBlock(1, perPowerStack=QuietArmor) } }',
}
for name, text in cards.items():
    (out / (name+'.spire')).write_text(text+'\n', encoding='utf-8')

results=[]
def run(name, command):
    start=time.perf_counter()
    process=subprocess.run(command, capture_output=True, text=True, encoding='utf-8', errors='replace')
    (out / (name+'.log')).write_text(process.stdout+process.stderr, encoding='utf-8')
    result=dict(name=name, command=command, exit_code=process.returncode, seconds=round(time.perf_counter()-start,3))
    try: result['output']=json.loads(process.stdout)
    except ValueError: pass
    results.append(result)
    (out/'results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k!='output'}, ensure_ascii=False), flush=True)
    return result

tool='tools/base-spire-dev/bin/Debug/net9.0/BaseSpire.Dev.dll'
for name, id in [('combo','combo'), ('existing-power','power-combo'), ('upgrade-cost','cost-probe')]:
    path=str(out/(name+'.spire'))
    run(name+'-check', ['dotnet',tool,'check',path])
    for version in ['normal','upgraded']:
        run(name+'-'+version, ['dotnet',tool,'play',path,'context-review:'+id,version])
run('new-power-author-tool', ['dotnet',tool,'check',str(out/'new-power.spire')])
run('power-frontend', ['dotnet','run','--project',str(out/'PowerProbe')])

byname={r['name']:r for r in results}
def delta(name, field):
    play=byname[name]['output']['play']
    return play['after'][field]-play['before'][field]
assert byname['combo-check']['exit_code']==0
assert delta('combo-normal','targetHp')==-7 and delta('combo-normal','block')==3
assert delta('combo-upgraded','targetHp')==-11 and delta('combo-upgraded','block')==4
assert delta('existing-power-normal','targetHp')==-5
assert delta('existing-power-upgraded','targetHp')==-7
assert delta('upgrade-cost-normal','energy')==-2
# Independent DSL expectation is -1; the current author probe only flips Upgraded, so this reproduces its limitation.
assert delta('upgrade-cost-upgraded','energy')==-2
assert byname['new-power-author-tool']['exit_code']==2
assert byname['power-frontend']['exit_code']==0

paths=[
    'docs/examples/base-card-mod/two-hits.spire',
    'docs/design/mod-the-spire/modding-guide.md',
    'tools/base-spire-dev/README.md',
    'mod-the-spire/base-spire/BaseSpire/Slice/SpirePowerSource.cs',
    'mod-the-spire/base-spire/BaseSpire/Slice/CombatSlicePackage.cs',
    'mod-the-spire/base-spire/BaseSpire/Slice/SpireCardSource.cs',
    'mod-the-spire/base-spire/BaseSpire/Slice/Effects/SourceEffectPrograms.cs',
    'mod-the-spire/base-spire/BaseSpire/Slice/Effects/CardEffectProgram.cs',
    'mod-the-spire/base-spire/BaseSpire/Slice/Effects/CardEffectCompiler.cs',
    'mod-the-spire/base-spire/BaseSpire/Slice/Effects/CardEffectExpressions.cs',
]
sizes=[]
for name in paths:
    path=root/name
    text=path.read_text(encoding='utf-8-sig')
    sizes.append(dict(path=name, lines=len(text.splitlines()), characters=len(text), sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
(out/'readset.json').write_text(json.dumps(sizes, ensure_ascii=False, indent=2), encoding='utf-8')
print('All context-review reproductions completed; negative results are findings, not feature passes.', flush=True)
