"""ENV-T04-strict-reshuffle-close-20261012: build the two negative reference-record sets.

Both negatives reuse the existing `--records <外部参考记录目录>` path and the existing
Comparator (no tool source change, no new suite case, no history matrix):

  N1 pile-order  : only `random-reshuffle-unsupported`'s `boundary[3].pile.draw.order` gets a
                   pure permutation (swap the first two entries; same multiset, same size, same
                   `sorted` set) -> the strict suite must report a `collection` first diff on the
                   drawn draw-pile order and return non-zero. If exact order were not compared,
                   the run would stay rc 0.
  N2 missing-stream: only that case's `boundaries[*].streams` are emptied -> the reference side
                   has no per-boundary reading of the real `Shuffle` stream. The strict suite must
                   return non-zero and the reference `streams` dimension must really be reported
                   missing.
"""
import json
import pathlib
import shutil

ROOT = pathlib.Path(__file__).resolve().parents[2]
SOURCE = ROOT / ".artifacts/parallel/dsh-strict-reshuffle-close-20261012/full-regression/records/reference"
AUDIT = ROOT / ".audit/dsh-strict-reshuffle-close-20261012"
CASE = "random-reshuffle-unsupported.json"


def fresh(name: str) -> pathlib.Path:
    target = AUDIT / name / "records"
    if target.exists():
        shutil.rmtree(target)
    shutil.copytree(SOURCE, target)
    return target


def load(path: pathlib.Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def dump(path: pathlib.Path, record: dict) -> None:
    path.write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


# -- N1: pure permutation of the drawn draw-pile order ------------------------------------------
n1 = fresh("negative-pile-order") / CASE
record = load(n1)
boundary = record["boundaries"][3]
for fact in boundary["facts"]:
    if fact["path"] == "pile.draw.order":
        parts = fact["value"].split(",")
        before = fact["value"]
        parts[0], parts[1] = parts[1], parts[0]
        fact["value"] = ",".join(parts)
        print(f"N1 pile.draw.order: {before} -> {fact['value']}")
        break
else:
    raise SystemExit("N1: pile.draw.order not found")
dump(n1, record)

# -- N2: drop the reference per-boundary real stream readings -----------------------------------
n2 = fresh("negative-missing-streams") / CASE
record = load(n2)
for boundary in record["boundaries"]:
    boundary["streams"] = []
dump(n2, record)
print("N2 boundaries[*].streams emptied for", CASE)
