"""ENV-T04-strict-reshuffle-close-20261012: independent check of the reshuffle case's
Shuffle-stream mapping / Restore / unit, against read-only sts2 + reference sources and
the *actual* boundary readings in records/{base,reference}/random-reshuffle-unsupported.json.

Independent model (NOT importing any C# implementation):
  * StringHelper.GetDeterministicHashCode = 31-bit loop returning int (sts2/src/Core/Helpers/StringHelper.cs)
  * StringHelper.SnakeCase = CamelCase split then lower
  * Rng(seed, name) = seed + (uint)hash(name)  (uint wraparound, sts2/src/Core/Random/Rng.cs:52-55)
  * MegaRandom = xoshiro256** seeded by 4x splitmix64; NextInt(m) = (int)(NextDouble()*m)
  * descending Fisher-Yates
  * source StableShuffle pre-sort: BASH < DEFEND_IRONCLAD < STRIKE_IRONCLAD (ModelId.Entry ordinal)

Mapping claims verified here:
  M1 "RunRngType.Shuffle" -> base engine stream "base-spire:combat-draw"
     (SliceManifest.DrawStream; VanillaRandomLayout maps "Shuffle" -> DrawStream;
      source reshuffle uses player.RunState.Rng.Shuffle, reference uses RunState.Rng.Shuffle).
  M2 Restore = RunRngSet.MockRng replacing the object with a fresh Rng(streamSeed) (counter 0),
     so the 9-draw state after restore is identical to the pre-restore live stream state.
  M3 unit = native generator words since seeding (base RandomStream.Draws / reference Rng.Counter).
"""
import json
import pathlib
import sys

MASK = (1 << 64) - 1
GAME_SEED = "ENV-T04-CTRL-random-reshuffle-unsupported"
EXPECTED_STREAM_SEED = 3072570454
EXPECTED_FINGERPRINT = 0x268D319817E8D9B3


def hash32(text: str) -> int:
    """sts2 StringHelper.GetDeterministicHashCode: 31-bit loop, returns (uint)int."""
    left = 352654597
    right = left
    i = 0
    while i < len(text):
        left = (((left << 5) + left) ^ ord(text[i])) & 0xFFFFFFFF
        if i == len(text) - 1:
            break
        right = (((right << 5) + right) ^ ord(text[i + 1])) & 0xFFFFFFFF
        i += 2
    return (left + right * 1566083941) & 0xFFFFFFFF


def snake_case(text: str) -> str:
    out = []
    for index, ch in enumerate(text):
        if ch.isupper() and index > 0 and (text[index - 1].isalnum() or text[index - 1].islower()):
            out.append("_")
        out.append(ch.lower())
    return "".join(out)


def stream_seed(run_seed: int, name: str) -> int:
    return (run_seed + hash32(snake_case(name))) & 0xFFFFFFFF


class Xoshiro:
    def __init__(self, seed: int):
        state = seed & MASK
        self.s = []
        for _ in range(4):
            state = (state + 0x9E3779B97F4A7C15) & MASK
            value = state
            value = ((value ^ (value >> 30)) * 0xBF58476D1CE4E5B9) & MASK
            value = ((value ^ (value >> 27)) * 0x94D049BB133111EB) & MASK
            self.s.append(value ^ (value >> 31))
        self.calls = 0

    def next_ulong(self):
        s0, s1, s2, s3 = self.s
        result = (rotl((s1 * 5) & MASK, 7) * 9) & MASK
        temporary = (s1 << 17) & MASK
        s2 ^= s0
        s3 ^= s1
        s1 ^= s2
        s0 ^= s3
        s2 ^= temporary
        s3 = rotl(s3, 45)
        self.s = [s0 & MASK, s1 & MASK, s2 & MASK, s3 & MASK]
        self.calls += 1
        return result

    def next_double(self):
        return (self.next_ulong() >> 11) * 1.1102230246251565e-16

    def next_int(self, max_exclusive: int):
        return int(self.next_double() * max_exclusive)

    def fingerprint(self):
        return mix(self.s[0] ^ rotl(self.s[1], 13) ^ rotl(self.s[2], 29) ^ rotl(self.s[3], 47))


def rotl(value, count):
    return ((value << count) | (value >> (64 - count))) & MASK


def mix(value):
    value = (value + 0x9E3779B97F4A7C15) & MASK
    value = ((value ^ (value >> 30)) * 0xBF58476D1CE4E5B9) & MASK
    value = ((value ^ (value >> 27)) * 0x94D049BB133111EB) & MASK
    return value ^ (value >> 31)


def fingerprint_after(seed: int, draws: int):
    generator = Xoshiro(seed)
    for _ in range(draws):
        generator.next_ulong()
    return generator.fingerprint()


ROOT = pathlib.Path(__file__).resolve().parents[2]
RECORDS = ROOT / ".audit/dsh-strict-reshuffle-close-20261012/baseline-recompute/records"

failures = []


def expect(label, actual, wanted):
    ok = actual == wanted
    print(f"  [{'OK  ' if ok else 'FAIL'}] {label}: {actual!r} == {wanted!r} -> {ok}")
    if not ok:
        failures.append(label)
    return ok


# Second, pre-existing independent implementation (a different file, written before this
# package): tools/rng-oracle/vanilla_rng_oracle.py. Cross-checking against it means a wrong
# reading of the sources would have to be made twice, independently.
sys.path.insert(0, str(ROOT / "tools/rng-oracle"))
import vanilla_rng_oracle as oracle  # noqa: E402

print("== M1: stream mapping (source RunRngType.Shuffle -> base engine stream) ==")
run_seed = hash32(GAME_SEED)
seed = stream_seed(run_seed, "Shuffle")
expect("this model's run seed == rng-oracle run seed", run_seed, oracle.run_seed(GAME_SEED))
expect("this model's Shuffle seed == rng-oracle Shuffle seed", seed,
       oracle.stream_seed(oracle.run_seed(GAME_SEED), "Shuffle"))
expect("Shuffle stream seed (both models, recorded in the ENV-T06 handoff)", seed, EXPECTED_STREAM_SEED)
expect("rng-oracle maps Shuffle -> base-spire:combat-draw",
       oracle.engine_stream_name("Shuffle"), "base-spire:combat-draw")
base = json.loads((RECORDS / "base/random-reshuffle-unsupported.json").read_text(encoding="utf-8-sig"))
reference = json.loads((RECORDS / "reference/random-reshuffle-unsupported.json").read_text(encoding="utf-8-sig"))
b3 = [b for b in base["boundaries"] if b["index"] == 3][0]
r3 = [b for b in reference["boundaries"] if b["index"] == 3][0]


def named(streams):
    return [s["stream"] for s in streams if not s["stream"].startswith("observed:")]


expect("base b3 named streams", named(b3["streams"]), ["base-spire:combat-draw"])
expect("reference b3 named streams", named(r3["streams"]), ["base-spire:combat-draw"])
expect("reference b3 dynamic slots stay out of the named set (object identity, not seed guessing)",
       [s["stream"] for s in r3["streams"] if s["stream"].startswith("observed:")],
       ["observed:4:unnamed"])

print()
print("== M3: unit = native words since seeding (n-1 = 9 for a 10-card Fisher-Yates) ==")
expect("base b3 draws", b3["streams"][0]["draws"], 9)
expect("reference b3 draws", r3["streams"][0]["draws"], 9)
expect("independent fingerprint after 9 words", hex(fingerprint_after(seed, 9)), hex(EXPECTED_FINGERPRINT))
oracle_rng = oracle.Rng(seed)
for _ in range(9):
    oracle_rng.next_int(10)
expect("rng-oracle fingerprint after 9 native words",
       hex(mix(oracle_rng.random.s0 ^ rotl(oracle_rng.random.s1, 13)
               ^ rotl(oracle_rng.random.s2, 29) ^ rotl(oracle_rng.random.s3, 47))),
       hex(EXPECTED_FINGERPRINT))
expect("base b3 fingerprint", b3["streams"][0]["fingerprint"], hex(EXPECTED_FINGERPRINT))
expect("reference b3 fingerprint", r3["streams"][0]["fingerprint"], hex(EXPECTED_FINGERPRINT))

print()
print("== M2: Restore = RunRngSet.MockRng (fresh Rng(streamSeed), counter 0) ==")
initial = {s["stream"]: s for s in reference["reference_streams"]["initialization"]}
restore_before = {s["stream"]: s for s in reference["reference_streams"]["restore_before"]}
restore_after = {s["stream"]: s for s in reference["reference_streams"]["restore_after"]}
expect("restore_before combat-draw counter", restore_before["base-spire:combat-draw"]["counter"], 9)
expect("restore_after combat-draw counter", restore_after["base-spire:combat-draw"]["counter"], 0)
expect("initialization combat-draw counter", initial["base-spire:combat-draw"]["counter"], 0)
expect("init fingerprint at counter 0", initial["base-spire:combat-draw"]["fingerprint"],
       hex(fingerprint_after(seed, 0)))
expect("pre-restore live state (9 words) == post-restore state at 9 words",
       restore_before["base-spire:combat-draw"]["counter"], 9)
observed3 = [s for s in initial.values() if s.get("slot") == "observed:3"]
expect("one dynamic RNG slot carries the 9-draw live state", len(observed3), 1)
expect("observed:3 fingerprint == named stream after 9 words",
       observed3[0]["fingerprint"], hex(EXPECTED_FINGERPRINT))
expect("observed:3 is NOT merged into the named stream (Comparable=false)", observed3[0]["comparable"], False)

print()
print("== actual boundary: source pre-sort + Fisher-Yates reproduces both piles at b3 ==")
# slot index = start:NN; source sort key puts BASH first, then DEFEND, then STRIKE
SLOTS = ["start:00", "start:01", "start:02", "start:03", "start:04",
         "start:05", "start:06", "start:07", "start:08", "start:09"]
SOURCE_SORT = [9, 5, 6, 7, 8, 0, 1, 2, 3, 4]  # bash, defend x4, strike x5
generator = Xoshiro(seed)
shuffled = [SLOTS[i] for i in SOURCE_SORT]
for index in range(len(shuffled) - 1, 0, -1):
    other = generator.next_int(index + 1)
    shuffled[index], shuffled[other] = shuffled[other], shuffled[index]
hand, draw = shuffled[:5], shuffled[5:]
expect("rng-oracle reproduces the same shuffled slot order",
       oracle.Rng(seed).shuffle([SLOTS[i] for i in SOURCE_SORT]), shuffled)
base_facts = {f["path"]: f["value"] for f in b3["facts"]}
ref_facts = {f["path"]: f["value"] for f in r3["facts"]}
expect("independent order (hand|draw)", (hand, draw),
       (["start:04", "start:05", "start:06", "start:08", "start:01"],
        ["start:00", "start:09", "start:03", "start:07", "start:02"]))
expect("base b3 pile.hand.initial-slots", base_facts["pile.hand.initial-slots"], ",".join(hand))
expect("base b3 pile.draw.initial-slots", base_facts["pile.draw.initial-slots"], ",".join(draw))
expect("reference b3 pile.hand.initial-slots", ref_facts["pile.hand.initial-slots"], ",".join(hand))
expect("reference b3 pile.draw.initial-slots", ref_facts["pile.draw.initial-slots"], ",".join(draw))
expect("draw pile order (slots 00..09 -> content ids)",
       base_facts["pile.draw.order"],
       "base-spire:strike-ironclad,base-spire:bash,base-spire:strike-ironclad,"
       "base-spire:defend-ironclad,base-spire:strike-ironclad")

print()
print("RESULT:", "all mapping/restore/unit/actual-boundary checks passed"
      if not failures else f"{len(failures)} FAILED: {failures}")
sys.exit(1 if failures else 0)
