# ENV-T04 地图独立对拍子包：case 设计与源定位（落盘前的设计稿）

- 日期：2026-10-08（Asia/Shanghai）
- 本文件位置：本包 audit 目录（**不参与编译**，停止门未开时只写这里）
- 停止门状态：C（`session-3baaf675-…`，ENV-T03 地图 Host）与 A（`session-20bb6663-…`，ENV-T05 连续攻击修复）实测仍在活跃写入，
  两份交接文件均未出现 → `tools/differential/` 参与编译的改动与共享构建**尚未开始**。
- 目标 case：`map-generated-alpha`（seed `t05-map-alpha`）、`map-generated-beta`（seed `t05-map-beta`）。

## 1. 判定语义（本包声称什么、不声称什么）

- 比较的是**幕 1 地图生成机制**：同一原始字符串 seed → 独立 `act_1_map` 命名流（counter 0）→
  参考用自己的 `Rng`/`MegaRandom`/`StandardActMap`/`MapPathPruning`/`MapPostProcessing` 真正生成网格。
- **不**比较开局到首次洗牌/起手的其它随机流，也不比较 `ChooseMapPoint` 动作语义（参考侧没有动作模型）。
  非地图流的开局比较仍由既有 `rng-initial-shuffle` 等 case 负责；边界写进交接与 case notes。
- 不声称正常多房间/奖励跑通：base 侧选中未实现房型仍具名 `Fail`，本 case 只停在 `Start()` 后的地图相位边界。
- base 侧事实**只从引擎公开投影读**（`base-spire:MapNodes` 集合 + `base-spire:MapChildren` 关系 + 地图流诊断），
  **不用** `SourceActMapCompute.Replay/ParseWords` 反推地图形状自证。

## 2. base 侧源定位（只读，已核对）

| 位置 | 事实 |
| --- | --- |
| `mod-the-spire/base-spire/BaseSpire/SinglePlayer/BaseSpireRuntimeFactory.cs:81-82` | `ActMapEnabled => string.Equals(Configuration.ScopeId, BaseSpireScope.DevMap, StringComparison.Ordinal)` |
| 同上 `:150-159` | `mapStream = MapRoomWiring.ActMapStreamName`；`mapSeed = VanillaRandomLayout.ActMapSeed(runSeed, 1)`；`session.Random.SeedStream(mapStream, mapSeed)` |
| 同上 `:161-166` | 建局阶段消费随机数即抛（地图抽数只发生在 `Start()` 里） |
| `mod-the-spire/base-spire/BaseSpire/Slice/VanillaRandomLayout.cs:219-236` | `ActMapSeed(uint runSeed, int act) => StreamSeed(runSeed, $"act_{act}_map")` = `unchecked(runSeed + DeterministicHashCode("act_1_map"))` |
| `mod-the-spire/base-spire/BaseSpire/Slice/MapRoomWiring.cs` | 常量 `ActMapStreamName="base-spire:run:act_1_map"`、`NodesCollectionName="MapNodes"`、`ChildrenRelationName="MapChildren"`、`ChooseActionName="ChooseMapPoint"`；Run 字段 `CurrentNode/MapPhase/MapFloor/MapNodeCount/MapDraws` |
| 同上 `:316-362` | 增量抽样：每轮 `SampleInt(ActMapStreamName, 0, 1<<53, payload)` → `blob = blob + ";" + payload` → 纯计算重放；`WordBudget` 内未完成则 `Fail("base-spire: 幕 1 地图生成超出抽数预算（未完成即停，不补齐随机数）")` |
| `mod-the-spire/base-spire/BaseSpire/Slice/SourceActMapCompute.cs:50-68` | `Span = 1L << 53`、`ActRooms = 15`、`WordBudget = 512`；`Replay` 契约：rest 高斯先、unknown 后，再 `TryGenerate(payloads, rng.DrawsUsed, 15, counts, hasSecondBoss: false, enablePruning: true)` |
| `mod-the-spire/base-spire/BaseSpire/SinglePlayer/RunConfiguration.cs` | `DevMap = "base-spire-singleplayer-dev-map-v1"`；`Ironclad(int ascension = 0, string scopeId = BaseSpireScope.Dev)` |

- 结论：`VanillaRandomLayout.ActMapSeed(RngSourceCompat.RunSeed(seed), 1) == RngSourceCompat.StreamSeed(RngSourceCompat.RunSeed(seed), "act_1_map")`。

## 3. 参考侧源定位（只读，已核对）

| 位置 | 事实 |
| --- | --- |
| `reference/sts2-sim/src/Sts2Sim.Core/Runs/RunState.cs:373-383` | `var mapRng = new Rng(Rng.Seed, $"act_{CurrentActIndex + 1}_map"); MapPointTypeCounts pointTypeCounts = act.GetMapPointTypes(mapRng, Ascension); Map = new StandardActMap(mapRng, act.BaseNumberOfRooms, pointTypeCounts, …)` |
| `reference/.../Content/ActDefinition.cs:61,84-88` | `public abstract int BaseNumberOfRooms { get; }`；`GetMapPointTypes(Rng)` 默认 `new AscensionManager(AscensionLevel.None)`；两参重载默认委托给单参 |
| `reference/.../Content/Acts/Overgrowth.cs:20,68-73` | `BaseNumberOfRooms => 15`；`int restCount = mapRng.NextGaussianInt(7, 1, 6, 7); int unknownCount = MapPointTypeCounts.StandardRandomUnknownCount(mapRng);` |
| `reference/.../Map/MapPointTypeCounts.cs` | `StandardRandomUnknownCount(Rng rng) => rng.NextGaussianInt(12, 1, 10, 14)`；`NumOfElites` 纯算术不消耗随机 |
| `reference/.../Map/StandardActMap.cs:1-150` | `public StandardActMap(Rng mapRng, int numberOfRooms, MapPointTypeCounts pointTypeCounts, bool hasSecondBoss = false, bool enablePruning = true)`；`_mapLength = numberOfRooms + 1`；`GenerateMap(); AssignPointTypes(); if(enablePruning) MapPathPruning.PruneAndRepair(…);` 后 `CenterGrid/SpreadAdjacentMapPoints/StraightenPaths` |
| `reference/.../Map/ActMap.cs` | `GetAllMapPoints()` **不含** `StartingMapPoint/BossMapPoint/SecondBossMapPoint`；`GetColumnCount()/GetRowCount()` = Grid 维度 |
| `reference/.../Random/Rng.cs:23-53,507` | `public Rng(ulong seed = 0uL)`；`public Rng(ulong seed, string name) : this(seed + StringHelper.GetDeterministicHashCode(name))`；`ToSerializable()` → `state0..3` |
| `reference/.../Random/MegaRandom.cs:156-171` | `FillSerializableState(rng) { rng.state0=_s0; … state3=_s3; }` |
| `reference/.../Random/RngDiagnostics.cs:8,17` | `public delegate void RngDrawObserver(Rng rng, string op, double min, double max, int arity); public static RngDrawObserver? DrawObserver;`（每次抽样触发；Gaussian 内部走 `_random.NextDouble()`，**事件数 ≠ 底层字数**） |

## 4. 严格入口改动设计（停 C/A 停止门后再落盘）

### 4.1 fixture 与 suite

- `FixtureSuite.cs`：新增 `CaseKinds.Map = "map"`（进 `All`）；`FixtureCase` 末尾追加可选参数 `string BaseScope = BaseScopes.Dev`，
  校验只允许 `dev` / `dev-map`；`BaseScopes` 常量表新增。
- `BaseBackend.OpenFormalSession`：按 `fixture.BaseScope` 选 `RunConfiguration.Ironclad(0, BaseSpireScope.DevMap)`（默认仍是 `Dev`，既有 15 case 行为不变）。
- `BaseBackend.Run`：`Kind == Map` 走同一 `RunScripted`，但事实取 `EngineSnapshot.MapFacts(session)`、流只取地图流。
- `ReferenceBackends` / `ReferenceBackend.Run`：`Kind == Map` → 新 `ReferenceMapEntry.Run(fixture)`。
- `suites/regression.json`：`expected_case_ids` 15 → 17，追加 `map-generated-alpha`/`map-generated-beta`；
  原 15 条 ID/`required_dimensions`/失败分类逐字不动。

### 4.2 新 case 声明（草案）

```json
{
  "id": "map-generated-alpha",
  "title": "真实工厂地图生成：t05-map-alpha 的幕 1 网格与地图流",
  "rng_profile": "vanilla-compatible@1",
  "kind": "map",
  "base_source": "formal-dev-factory",
  "base_scope": "dev-map",
  "game_seed": "t05-map-alpha",
  "reference_scope": "compared",
  "required_dimensions": ["facts", "streams"],
  "expected_terminal": "running",
  "script": [],
  "group": "env-t04-map"
}
```

### 4.3 事实路径（两侧逐字同名；两侧都由各自引擎公开面读出）

- `map.count`：节点总数
- `map.rows` / `map.cols`：`GetRowCount()` / `GetColumnCount()`
- `map.node.[c,r].type`：每个点的房型枚举序数（含起点与 BOSS 点）
- `map.edge.[pc,pr]->[cc,cr]`：每条父→子边记 `"1"`
- `map.start` / `map.boss` / `map.second_boss`：`[c,r]`（无二王记 `none`）
- `map.words_consumed`：本 case 的地图流消耗字数

base 侧：点集 = `base-spire:MapNodes` 全部成员（`MapNode.Col/Row/Type`，`Type` 读 `AsEnumOrdinal()`）；
边 = 各点 `RelationTargets(base-spire:MapChildren)`；`map.words_consumed` = `session.Random.DrawCount(mapStream)`。

参考侧：点集 = `GetAllMapPoints()` ∪ {`StartingMapPoint`,`BossMapPoint`}（`SecondBossMapPoint` 为 null 记 `none`）；
边 = 各点 `Children`；`map.words_consumed` = 状态对齐字数（见 4.5）。

### 4.4 流维度：唯一可比单位是「底层 64 位字数」

- base 侧每字一个 payload，故 `Draws = Diagnostics()` 里地图流的 `Draws` = payload 数 = 源实际消费字数；
  指纹 = 引擎自己算的 `StateFingerprint`（`EngineSnapshot.Streams` 已投影为 `"0x" + x16`）。
- 参考侧 `Rng.Counter` 数的是 **API 调用**（一次高斯只 +1），与 base 不同单位，直接比会造假差异 → 不用。
  改为：`new RngSourceCompat.Xoshiro256StarStar(mapSeed)` 逐步 `NextULong()`，直到状态等于
  `mapRng.ToSerializable().state0..3`，步数即底层字数（上界 `SourceActMapCompute.WordBudget`，即 512）；
  指纹 = `RngSourceCompat.FingerprintText(state0..3)`（与 core `StateFingerprint` 同一公式）。
- 若 512 步内对不上 → 记为**未对齐**（draws = -1 + note），由比较器如实报差异，不伪造对齐。

### 4.5 参考身份（进入 `CaseRecord.ReferenceIdentity`）

- `ProfileId = RngSourceCompat.ProfileId`（`source-compat-sts2-frozen@1`），`Adapter/Version = reference:sts2-sim / env-t04-map-entry@1`
- `Enablement`：map case 直接用源派生种子构造参考自己的 `Rng`，不经 `RunRngSet.MockRng`；纲领仍是"只换种子派生"
- `Scope`：仅 `act_1_map` 一条流的种子派生（源 hash32 + uint 回绕）；参考地图算法/抽样/遍历/剪枝/后处理一律不动
- `Streams`：[`("act_1_map", "base-spire:run:act_1_map", mapSeed)`]
- `Replaces/NotReplaced` 复用 `RngSourceCompat.Replaces/NotReplaced`（后者的"地图"一条仍成立：改的是**种子派生**不是地图算法）
- `SourceFiles`：复用负责人本轮登记的 `.audit/dsh-supervisor/review-2026-10-08-2153/map-source-inputs.json`（8 个 path+sha256），
  并用工作区当前文件重算对照；`ReferenceHead` 用 `Repo.GitHead("reference/sts2-sim")`
- `ProfileCodeSha256`：`Repo.DigestFiles(["tools/differential/RngSourceCompat.cs"])`

## 5. 参考侧入口（新文件 `ReferenceMapEntry.cs`，`#if REFERENCE_SIM`）

```csharp
var runSeed = RngSourceCompat.RunSeed(gameSeed);                       // 源 hash32（31 位循环）
var mapSeed = RngSourceCompat.StreamSeed(runSeed, "act_1_map");        // uint 加法回绕
var mapRng = new Sts2Sim.Core.Random.Rng((ulong)mapSeed);              // 参考自己的 MegaRandom
var act = new Overgrowth();
var counts = act.GetMapPointTypes(mapRng, new AscensionManager(AscensionLevel.None));
var map = new StandardActMap(mapRng, act.BaseNumberOfRooms, counts, hasSecondBoss: false, enablePruning: true);
```

- 不调用 `RunState` 的内建地图（那条走参考原生 ulong 派生，不在本 case 比较范围内）；只用参考自己的公开类型。
- 另用 `RngDiagnostics.DrawObserver` 在**局部**捕获参考地图生成期间的抽样 API 序列（`op` 名单）入 notes，
  用于人工核对流调用形态；观察不消费随机数，且必须在 `finally` 里恢复全局钩子。

## 6. 待落盘清单（停 C/A 后执行）

1. `tools/differential/FixtureSuite.cs`：`CaseKinds.Map`、`BaseScopes`、`FixtureCase.BaseScope`、校验
2. `tools/differential/BaseBackend.cs`：`OpenFormalSession` 按 scope、`Run` 的 map 分支、`StartLabel` 带 scope
3. `tools/differential/EngineSnapshot.cs`：`MapFacts(session)`、`MapStreams(session)`（或 `Streams(session, name)` 重载）
4. `tools/differential/ReferenceBackend.cs`：`Kind == Map` 分派 + 参考地图事实投影
5. `tools/differential/ReferenceMapEntry.cs`：新文件（参考独立地图生成 + 身份 + 状态对齐）
6. `tools/differential/RngSourceCompat.cs`：`Xoshiro256StarStar` 加"状态是否等于给定 4 字"的只读方法（不改抽样语义）
7. `tools/differential/suites/regression.json`：新增两条 case + `expected_case_ids`
8. `tools/differential/README.md`：新增 kind/字段/比较边界的说明（必要 tools 文档）
9. 构建与执行：`dotnet build tools/differential/Differential.csproj -c Release`；
   `powershell -NoProfile -ExecutionPolicy Bypass -File tools\differential\test-env.ps1 -Suite regression`
   （本机只有 Windows PowerShell 5.1，无 `pwsh`；脚本保持 ASCII-only）
10. 交接 + 本包 task-record 收尾

## 7. 未决/风险

- 两侧房型枚举序数是否逐字同序（base 是移植件、参考是自己的枚举）→ 由比较器如实判定，不预先假定通过。
- base `MapNode.Type` 在起点/BOSS 点上的取值是否与参考 `StartingMapPoint/BossMapPoint.PointType` 一致 → 同上。
- 参考生成器是否为 `Xoshiro256StarStar` 模型（否则状态对不上 → draws = -1 如实报差异）。
- `EngineSnapshot.Streams` 是否包含未被抽过的种子流（`Draws = 0`）→ 本 case 只投影地图一条，规避该问题。

## 预落盘草稿（等 C/A 停止门）

`draft/` 下已写好可直接复制的三个 `.cs` 与逐处补丁计划：
- `draft/MapFacts.cs`：两侧共用的地图事实路径词表（只格式化，不推导）。
- `draft/MapSnapshot.cs`：base 侧只读 `base-spire:MapNodes`/`base-spire:MapChildren`，流只留 `base-spire:run:act_1_map`。
- `draft/ReferenceMapEntry.cs`：`#if REFERENCE_SIM` 参考侧独立生成入口（源派生种子 + 参考自己的 StandardActMap/剪枝/后处理）。
- `draft/patch-plan.md`：`RngSourceCompat`/`FixtureSuite`/`BaseBackend`/`ReferenceBackend`/`suites/regression.json` 的逐处改动与门后验证清单。

关键取舍：base 边界 Actions 传空表——参考侧无 `ChooseMapPoint` 对应物，放进来只会造出与本 case 主张无关的 `present` 差异（本 case 比地图形状与地图流）。
