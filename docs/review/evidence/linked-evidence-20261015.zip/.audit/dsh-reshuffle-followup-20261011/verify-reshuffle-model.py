"""Independent re-derivation of the reshuffle first difference for ENV-T04.

Model (from read-only sts2/ + reference/sts2-sim sources, mirrored by tools/differential/RngSourceCompat.cs):
  * run seed  = StringHelper.GetDeterministicHashCode(game seed string)  (31-bit loop, uint)
  * stream    = unchecked(runSeed + GetDeterministicHashCode(SnakeCase("Shuffle")))
  * MegaRandom = xoshiro256** seeded by 4x splitmix64
  * NextInt(max) = (int)(NextDouble() * max); NextDouble = (NextULong() >> 11) * 2**-53
  * Fisher-Yates: for i = n-1 .. 1: j = NextInt(i+1); swap(list[i], list[j])
"""

import re

MASK = (1 << 64) - 1

SLOTS = [
    ("start:00", "strike-ironclad"), ("start:01", "strike-ironclad"),
    ("start:02", "strike-ironclad"), ("start:03", "strike-ironclad"),
    ("start:04", "strike-ironclad"), ("start:05", "defend-ironclad"),
    ("start:06", "defend-ironclad"), ("start:07", "defend-ironclad"),
    ("start:08", "defend-ironclad"), ("start:09", "bash"),
]
CARD_OF = {slot: card for slot, card in SLOTS}


def det_hash(text):
    left = 352654597
    right = left
    index = 0
    while index < len(text):
        left = (((left << 5) + left) ^ ord(text[index])) & 0xFFFFFFFF
        if index == len(text) - 1:
            break
        right = (((right << 5) + right) ^ ord(text[index + 1])) & 0xFFFFFFFF
        index += 2
    return (left + right * 1566083941) & 0xFFFFFFFF


def snake_case(text):
    """StringHelper.SnakeCase: insert '_' before an uppercase letter that follows an
    alphanumeric character, then lowercase.  Python's re has no \\G, so scan manually."""
    trimmed = text.strip()
    out = []
    for index, char in enumerate(trimmed):
        if index > 0 and char.isupper() and (trimmed[index - 1].isalnum()):
            out.append("_")
        out.append(char)
    return "".join(out).lower()


def rotl(value, count):
    return ((value << count) | (value >> (64 - count))) & MASK


class Xoshiro:
    """xoshiro256** with 4x splitmix64 seeding (MegaRandom)."""

    def __init__(self, seed):
        state = seed & MASK
        self.s = []
        for _ in range(4):
            state = (state + 0x9E3779B97F4A7C15) & MASK
            value = state
            value = ((value ^ (value >> 30)) * 0xBF58476D1CE4E5B9) & MASK
            value = ((value ^ (value >> 27)) * 0x94D049BB133111EB) & MASK
            self.s.append(value ^ (value >> 31))
        self.calls = 0

    def next_ulong(self):
        s0, s1, s2, s3 = self.s
        result = (rotl((s1 * 5) & MASK, 7) * 9) & MASK
        temporary = (s1 << 17) & MASK
        s2 ^= s0
        s3 ^= s1
        s1 ^= s2
        s0 ^= s3
        s2 ^= temporary
        s3 = rotl(s3, 45)
        self.s = [s0 & MASK, s1 & MASK, s2 & MASK, s3 & MASK]
        self.calls += 1
        return result

    def next_double(self):
        return (self.next_ulong() >> 11) * 1.1102230246251565e-16

    def next_int(self, max_exclusive):
        return int(self.next_double() * max_exclusive)

    def skip(self, words):
        for _ in range(words):
            self.next_ulong()

    def state(self):
        return ",".join(hex(word) for word in self.s)


def shuffle(items, generator):
    items = list(items)
    draws = []
    for index in range(len(items) - 1, 0, -1):
        other = generator.next_int(index + 1)
        draws.append((index, other))
        items[index], items[other] = items[other], items[index]
    return items, draws


def invert(output_order, draws):
    items = list(output_order)
    for index, other in reversed(draws):
        items[index], items[other] = items[other], items[index]
    return items


GAME_SEED = "ENV-T04-CTRL-random-reshuffle-unsupported"
run_seed = det_hash(GAME_SEED)
stream_hash = det_hash(snake_case("Shuffle"))
shuffle_seed = (run_seed + stream_hash) & 0xFFFFFFFF
print(f"game_seed            = {GAME_SEED}")
print(f"run_seed (hash32)    = {run_seed}")
print(f"hash32('shuffle')    = {stream_hash}")
print(f"Shuffle stream seed  = {shuffle_seed}")
print()

discard_order = [slot for slot, _ in SLOTS]

# observed outputs: slots of the combined 10-card reshuffled list, hand (first 5) then draw pile
base_observed = ["start:09", "start:01", "start:02", "start:04", "start:06",
                 "start:05", "start:00", "start:08", "start:03", "start:07"]
ref_observed = ["start:02", "start:08", "start:07", "start:05", "start:00",
                "start:03", "start:06", "start:04", "start:09", "start:01"]

print("A) base: Shuffle stream at cursor 0 over the discard-pile order")
gen = Xoshiro(shuffle_seed)
base_shuffled, base_draws = shuffle(discard_order, gen)
print(f"   computed = {','.join(base_shuffled)}")
print(f"   observed = {','.join(base_observed)}")
print(f"   MATCH    = {base_shuffled == base_observed}  draws={len(base_draws)} "
      f"bounds={[i + 1 for i, _ in base_draws]}")
print(f"   stream state after = {gen.state()}  calls={gen.calls}")

print()
print("B) reference: Shuffle stream at cursor 9 over its own pre-shuffle order")
gen9 = Xoshiro(shuffle_seed)
gen9.skip(9)
print(f"   state at cursor 9 = {gen9.state()}")
ref_shuffled, ref_draws = shuffle(discard_order, gen9)
derived_input = invert(ref_observed, ref_draws)
print(f"   observed  = {','.join(ref_observed)}")
print(f"   derived pre-shuffle order (inverted FY over the cursor-9 swap list)")
print(f"             = {','.join(derived_input)}")
print(f"             = {','.join(CARD_OF[s] for s in derived_input)}")
fwd_gen = Xoshiro(shuffle_seed)
fwd_gen.skip(9)
fwd, _ = shuffle(derived_input, fwd_gen)
print(f"   forward check: shuffle(derived input, cursor 9) == observed -> {fwd == ref_observed}")

print()
print("C) cursor-aligned comparison (what the probe sees once the reference cursor is restored to 0)")
gen_a = Xoshiro(shuffle_seed)
aligned_discard, _ = shuffle(discard_order, gen_a)
gen_b = Xoshiro(shuffle_seed)
aligned_sorted, _ = shuffle(derived_input, gen_b)
print(f"   base  (discard order)      : {','.join(aligned_discard)}")
print(f"   ref   (its own order)      : {','.join(aligned_sorted)}")
print(f"   identical                  = {aligned_discard == aligned_sorted}")

print()
print("D) pre-shuffle input orders")
print(f"   base  : {','.join(discard_order)}")
print(f"           {','.join(CARD_OF[s] for s in discard_order)}")
print(f"   ref   : {','.join(derived_input)}")
print(f"           {','.join(CARD_OF[s] for s in derived_input)}")

print()
print("E) reference StableShuffle pre-sort key (CardModel.CompareTo: Id, then upgrade level)")
ids = sorted(set(CARD_OF.values()))
print(f"   Id order: {ids}")
print(f"   sorted multiset = {[card for card in ids for _ in range(sum(1 for s in discard_order if CARD_OF[s] == card))]}")


# --- F) per-side sample / bounds / fingerprint table -------------------------------------------
def fingerprint(state):
    s0, s1, s2, s3 = state
    value = s0 ^ rotl(s1, 13) ^ rotl(s2, 29) ^ rotl(s3, 47)
    value = (value + 0x9E3779B97F4A7C15) & MASK
    value = ((value ^ (value >> 30)) * 0xBF58476D1CE4E5B9) & MASK
    value = ((value ^ (value >> 27)) * 0x94D049BB133111EB) & MASK
    value = value ^ (value >> 31)
    return "0x" + format(value, "016x")


def table(label, cursor, order):
    generator = Xoshiro(shuffle_seed)
    generator.skip(cursor)
    before_state = list(generator.s)
    before_fp = fingerprint(before_state)
    shuffled, draws = shuffle(order, generator)
    after_fp = fingerprint(generator.s)
    bounds = [index + 1 for index, _ in draws]
    samples = [other for _, other in draws]
    print()
    print(f"F) {label}")
    print(f"   stream seed        = {shuffle_seed}")
    print(f"   cursor before      = {cursor}   fingerprint before = {before_fp}")
    print(f"   bounds (NextInt)   = {bounds}")
    print(f"   samples (values)   = {samples}")
    print(f"   draws              = {len(draws)}   cursor after = {generator.calls}   "
          f"fingerprint after = {after_fp}")
    print(f"   shuffled order     = {','.join(shuffled)}")
    print(f"   hand (first 5)     = {','.join(shuffled[:5])}")
    print(f"   draw (rest)        = {','.join(shuffled[5:])}")
    return before_fp, after_fp


table("base: cursor 0 over discard order 00..09 (recorded 0x268d319817e8d9b3 after 9)", 0, discard_order)
table("reference (unaligned): cursor 9 over Id-sorted input (recorded 0xdc2712a5020077bd after 18)",
      9, derived_input)
table("reference (aligned by this package): cursor 0 over Id-sorted input", 0, derived_input)

