using CoreTheSpire.Engine;

var rules = EngineDslCompiler.LoadFiles("docs/examples/core-choice-counter/counter.spire");
var session = new Session(rules, 42, ["player", "player"]);
session.Start();
var first = session.Participant(0);
var second = session.Participant(1);
var firstActions = session.LegalActions(first);
var secondActions = session.LegalActions(second);
Console.WriteLine($"SameRole: first={firstActions.Count}, second={secondActions.Count}");
// Second player can initiate an action whose decision is explicitly directed to the first player.
session.Submit(secondActions.Single().Definition, second, []);
Console.WriteLine($"Initiator={second}; requestedParticipant={session.PendingDecision!.Participant}");
var offered = session.LegalActions(first);
Console.WriteLine($"Pending: status={session.Status}; offeredActions={offered.Count}");
try
{
    session.Submit(offered.Single().Definition, first, offered.Single().Bindings.Single());
    throw new Exception("Expected rejection while awaiting a decision.");
}
catch (EngineFaultException ex)
{
    Console.WriteLine($"PendingSubmit: {ex.Code}; {ex.Message}");
    if (ex.Code != EngineFaultCode.IllegalAction) throw;
}
var pending = session.PendingDecision!;
session.Answer(new DecisionAnswer(pending.RequestId, Instances: [pending.Candidates[0]]));
Console.WriteLine($"Resume: status={session.Status}; pending={session.PendingDecision is not null}");
