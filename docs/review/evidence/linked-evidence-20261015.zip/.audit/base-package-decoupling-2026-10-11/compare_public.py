import json
from pathlib import Path
root=Path('.audit/base-package-decoupling-2026-10-11')
skip={'session_id','request_id'}
def stable(value):
    if isinstance(value,dict): return {k:stable(v) for k,v in value.items() if k not in skip}
    if isinstance(value,list): return [stable(v) for v in value]
    return value
report={}
for name in ('frames.ndjson','steps.ndjson'):
    before=[stable(json.loads(s)) for s in (root/'before-public'/name).read_text(encoding='utf-8').splitlines()]
    after=[stable(json.loads(s)) for s in (root/'after-public'/name).read_text(encoding='utf-8').splitlines()]
    mismatch=next((i for i,(a,b) in enumerate(zip(before,after)) if a!=b),None)
    report[name]={'before_rows':len(before),'after_rows':len(after),'equal':before==after,'first_difference':mismatch}
    if mismatch is not None:
        (root/(name+'.first-difference.json')).write_text(json.dumps({'before':before[mismatch],'after':after[mismatch]},ensure_ascii=False,indent=2),encoding='utf-8')
a=json.loads((root/'before-public/summary.json').read_text(encoding='utf-8'))
b=json.loads((root/'after-public/summary.json').read_text(encoding='utf-8'))
report['identity']={'before':a['identity'],'after':b['identity'],'equal':a['identity']==b['identity']}
report['ignored_fields']=sorted(skip)
(root/'behavior-comparison.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
assert all(report[k]['equal'] for k in ('frames.ndjson','steps.ndjson','identity'))
