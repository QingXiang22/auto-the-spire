# ENV-T03 C 线声明扩展子包 — 执行摘要（2026-10-08）

- task_id: `ENV-T03`；dispatch_id: `ENV-T03-declaration-extension-20261008`
- 执行会话: `session-185c891a-e2ef-4fd5-a92e-724112e61418`；派单记录 `task-record.json`（本目录）
- 唯一交接: `docs/review/tofix/dsh-env-t03-declaration-extension-handoff-2026-10-08.md`
- 结论：**本子包完成，可评审**。C# 410/410、Python 157/157、旧客户端回归 103/103 全绿；父项 **ENV-T03 不关闭**。

## 一句话能力

用**同一通用规则提供方**（`EngineDslCompiler.LoadFiles`）+ 同一 `ControlHost(ISessionSource, ledgerCapacity)` 接缝，加载两套仅相差「规则声明」的 core/0.2 规则包（`baseline.spire` / `extended.spire`），
证明新增公开字段与合法 Action **不需要 net 生产源码新增任何逐项注册行**即可出现在 describe/catalog/observe、并可由 step 正确执行；同时新增隐藏字段不出现、新增内部 procedure 不成为外部操作、过期候选/错 expected_identity 在执行前拒绝且重发幂等、身份随规则变化而与每局 seed 无关。

## 交付物（sha256 / 字节）

| 文件 | bytes | sha256 |
| --- | --- | --- |
| net-the-spire/fixtures/declaration-extension/baseline.spire | 2447 | `36299AE4C1B42E377C2E3A7EBE6E8880F629821850B89A4F3D85FCDFD1F44533` |
| net-the-spire/fixtures/declaration-extension/extended.spire | 3308 | `6147C1433367028573C07E401E13182440B36191B8CC750D237B9C5538883C03` |
| net-the-spire/fixtures/declaration-extension/public-metadata.json | 768 | `D5F1FC1D4196262CE4103AB1CEE82D7F7BADB9F5B909A1AA767D7704A8D37B8F` |
| net-the-spire/fixtures/declaration-extension/README.md | 3193 | `1BF0E20FB0C802D9959ED1759BC364CE6DD12CCE510490F2BF12C9188E7C9F9C` |
| net-the-spire/Net.TheSpire.Host/TextRuleProviderSpec.cs | 10542 | `32CA13823FCEBC4DA6A636E27C0679D04114109DC4A38096DF7DBD03A02D6AB3` |
| net-the-spire/Net.TheSpire.Host/TextRuleScenario.cs | 2838 | `00CBA5BBCBCABF95B3BEC52B4C11D907C3B102096BDD945E4B1162FCF9208529` |
| net-the-spire/Net.TheSpire.Host/TextRuleSource.cs | 4218 | `BC180ACCE52E5F29FE56989FA3119E872ECCD3BE3AE87DEB02C023370591A5F5` |
| net-the-spire/Net.TheSpire.Host/Program.cs | 16753 | `909E3CB6E356E2141C16DB14B7269747A19EC95AC16D9F186BD8A795CB5747F4` |
| net-the-spire/Net.TheSpire.Tests/DeclarationExtensionChecks.cs | 33420 | `E5930AA5AEAA54DBFB2786A9724C8D58EBB7F24186F9A2F3E2E3A179F9B72D46` |
| net-the-spire/Net.TheSpire.Tests/Program.cs | 2155 | `17144997644D0FEAAEA76601A4BBE1638BEDEB2BA7608D836C5480A21CB7DAB8` |
| net-the-spire/client/net_client.py | 18116 | `721C3E46B8F93B6CE1D74269BFD8240C74D5215A97A053EEF7783F1894C40D1E` |
| net-the-spire/client/test_declaration_extension.py | 34639 | `D43FF922CDED7BC166FC89783E2A53A809A0342F90C52CD500E44B9E37E9AE34` |
| net-the-spire/text-rule-packages.md | 6594 | `AA0DD9D51166B47AC6D4A0F6AD51AD363F9FE2D62CCE2410DFF0F902D44197F3` |
| net-the-spire/coverage-n-02.md | 16336 | `F3E5D647969694CE50F183A84E8182FE0A9401FCEA6A13C5C6E4FF5A3F1CC976` |
| net-the-spire/Net.TheSpire.Host/bin/Debug/net9.0/Net.TheSpire.Host.dll | 41472 | `7980f115be3a47259019e401210f725d2c21d78f66ffeae39bdc9ff5a80cdec7` |

Host DLL LastWriteTime = 2026-10-08 20:10:45（本地）。

## 实现摘要

- **规则包测试资源（不参与编译）**：两包逐字相同，只差四处声明——`Marker` 增公开字段 `Bump`（Int 0..1000000 default 0）、增隐藏字段 `Secret`（`visibility = Hidden` default 7）、增内部 `procedure Retally`（无任何 action/订阅引用）、增合法 `action Mark`（参数 `amount`，`choices = [1, 3]`）。`public-metadata.json` 只含四类不可推导元数据与提供方配置（两包共享）。
- **Host 泛型接缝**：新增 `--scenario text-rules --rules <entry.spire> --public-metadata <file.json> [--game-seed]`，由 `TextRuleProviderSpec`/`TextRuleScenario`/`TextRuleSource` 组成；与 base 工厂并列注册在既有 `ISessionSource` 上，**没有** 为 `Bump`/`Secret`/`Retally`/`Mark` 写 Profile/ID 表或特殊 handler。
- **C# 检查**：`Net.TheSpire.Tests/DeclarationExtensionChecks.cs` 新增 E-01…E-08（真实宿主：目录/观察/执行/隐藏字段/内部 procedure/拒绝与幂等/未支持结构显式报错/schema 逐帧校验）；net 套件 393 → **410** 条。
- **Python 检查**：新增 `net-the-spire/client/test_declaration_extension.py`（真实宿主子进程 + 每帧用 `docs/contracts/net/0.2/wire.schema.json` 校验 + NDJSON 证据日志），分组 catalog/trajectory/identity/rejections/schema。
- **客户端修复（本包范围内、旧 0.1/0.2 套件回归通过）**：`net_client.py` `request()` 不再往 `error` 对象注入 `request_id`（`$defs.Error` 是 `additionalProperties:false`）；`stderr_text()` 正确处理二进制 stderr（原先 bytes/str 相加抛 `TypeError`）。
- **net 文档**：新增 `net-the-spire/text-rule-packages.md` 并把它接入 `coverage-n-02.md`。

## 最终串行验证（A 已实际停止后执行，命令与退出码）

| 步骤 | 命令 | 退出码 | 日志 | 结果 |
| --- | --- | --- | --- | --- |
| 构建 | `dotnet build AutoTheSpire.sln`（同 `run-final.ps1` 记录） | 0 | `build-final.log` | 0 警告 0 错误，增量 5.29s |
| net 检查 | `dotnet run --project net-the-spire/Net.TheSpire.Tests -v minimal --nologo` | 0 | `net-final.log` | **410 executed / 410 passed / 0 failed**（含 E-08：E-01…E-08 全绿） |
| 本包 Python 检查 | `python -X utf8 -u net-the-spire/client/test_declaration_extension.py --log .audit/dsh-env-t03-declaration-extension-2026-10-08/artifacts/declaration-extension-evidence.ndjson` | 0 | `client-declaration-extension-final.log` | **157 passed / 0 failed / 157 executed**（catalog 36 / trajectory 29 / identity 18 / rejections 56 / schema 18） |
| 既有客户端回归 | `python -X utf8 -u net-the-spire/client/test_client.py` | 0 | `client-all-final.log` | **103 passed / 0 failed / 103 executed** |
| 文档 | `python tools/doc-check/check_docs.py` | 4 | `doc-check-final.log` | 4 条失败**全部**在 A 的 `docs/review/tofix/dsh-env-t05-map-room-handoff-2026-10-08.md`（`:17/:23/:52/:60` 的 `../README.md[#env-t05]` 缺目标，应为同目录 `README.md`）；本包文档 0 问题 |

退出码汇总见 `exit-codes.txt`。执行记录脚本 `run-final.ps1`（同一内容以 inline 方式执行，见「首差」）。

## 关键实况（可复查）

- **真实 ready 横幅**（stderr，记入证据日志 `artifacts/declaration-extension-evidence.ndjson` 的 `host-banner` 条目）：
  - baseline：`net-the-spire host ready: scenario=text-rules protocol=0.2 scope=net-text-rules-declaration-extension-v1 build=net-text-rules-declaration-extension-v1|rules=d589153c7c924811 ruleset=net:ruleset:362f9217df658b91 projection=declaration:PlayerView rng_profile=rejection-uniform@1 default_game_seed=DECL-EXT-00 rules=…\baseline.spire frame_limit=1048576`
  - extended：同形，`build=…|rules=6ed229e742d8685a ruleset=net:ruleset:d14d0ece0ff8ff3a rules=…\extended.spire`
- **身份三元组（同一提供方、两个规则包）**：
  - baseline `net:ruleset:362f9217df658b91` / `net:catalog:a6063c491bbb2a26` / `net:backend:simulation-0.2-1b934efa420e9973`
  - extended `net:ruleset:d14d0ece0ff8ff3a` / `net:catalog:ae35798d5b89565e` / `net:backend:simulation-0.2-6195cc24ad502061`
- **目录差（get_catalog，同一 schema）**：`fields` 4 → 6（新增 `net:field:declaration:Marker.Bump`、`net:field:declaration:Mark.amount`；`Marker.Secret` **不出现**）；`action_types` 2 → 3（新增 `net:action:declaration:Mark`，`required_fields=[net:field:declaration:Mark.amount]`；`Retally` **不出现**）；`terminal_reasons` 1（`net:reason:declaration:ReachedLimit`，outcome=win，字段 `ReachedLimit.Value` 落在 `optional_fields`——声明里是裸 `Int`，net 如实转述不擅自升必填）。
- **真实会话与 seed**：`session-4d06ca43c689-1`，`start` 回显 seed 字符串 `'DECL-EXT-00'`；另一轮用 `'DECL-EXT-00 '`（尾随空格）验证 seed 原样发送、身份不随 seed 变化。
- **「生产源码不逐项注册」源码证据**：在 `net-the-spire/Net.TheSpire`、`net-the-spire/Net.TheSpire.Contracts`、`net-the-spire/Net.TheSpire.Host` 搜 `Bump|Retally|ReachedLimit|declaration:Marker|declaration:Mark\b` → **0 命中**；命中仅在测试（`Net.TheSpire.Tests/DeclarationExtensionChecks.cs`）与检查脚本里。
- **并发门（A 已停止，未验收）**：`artifacts/sessions-at-final.txt` 显示 A `session-3a7026c3-9a61-4e44-9393-b7077d8a0fc1` `running=false`（asOfSeq 1060，其交接仍 `in_progress`）；B 新包 `session-e17943ba-7805-421d-884d-9bffc2574240` false/855；本包 `session-185c891a-…` true/1436。另有本仓 `1446136e-eb48-4d28-8c94-f6d9a6d05ee9` true/1387，不在任何 `.audit` 记录内，不属于 A/B/C 门。停止 ≠ 验收。

## 首差与偏差

1. **`doc-check` 退出码 4**：失败不在本包文件，全部是 A 的 `docs/review/tofix/dsh-env-t05-map-room-handoff-2026-10-08.md` 链接多一层目录（应为同目录 `README.md`）。本包文档 0 问题；未越界修改 A 的交接。
2. **PowerShell 执行策略**：`& .\run-final.ps1` 被拒（`UnauthorizedAccess`／「在此系统上禁止运行脚本」），最终以同内容 inline 执行；`run-final.ps1` 仍作为命令记录保留。
3. **客户端两处缺陷在本包内修复**：`request()` 曾把 `request_id` 注入 `$defs.Error`（Python schema 判定不合规，宿主真实字节合规）；`stderr_text()` 曾对 bytes 做 str 相加。修复后旧客户端 103/103 回归通过。
4. **终局字段位置**：`terminal ReachedLimit { fields = { Value = Int } }` 在目录中落在 `optional_fields`（`DerivedPublicProfile.cs:568,573` 的 `Required: !field.Optional`），C# 检查因此断言「恰好落在必填或可选之一」。

## 未验证／边界（不得由本包推断）

- 本扩展例**不等于**完整 base 原版；不覆盖多选/枚举形状（遇到未知结构显式 unsupported，不静默删公开事实）。
- 父项 ENV-T03 的两个开放问题（两集合公开表达、正常连续攻击 `PowerStacksOf` 故障）仍待 A 线，与本包无关。
- 未重跑整个 T04/地图/训练；未开下一生产包。

## 接手第一步

1. 读本目录 `task-record.json` 与唯一交接的「原完成条件逐项对照」。
2. 复核命令：`dotnet run --project net-the-spire/Net.TheSpire.Tests -v minimal --nologo` → 期望 410/410；`python -X utf8 -u net-the-spire/client/test_declaration_extension.py --log <tmp>` → 期望 157/157。
3. 需要独立复核时用 `.audit/dsh-env-t03-declaration-extension-2026-10-08/artifacts/declaration-extension-evidence.ndjson`（44 行：header + 2 横幅 + 41 帧）做离线 schema 复查。
