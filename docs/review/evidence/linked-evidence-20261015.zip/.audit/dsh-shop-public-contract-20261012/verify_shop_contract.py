#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ENV-T03-shop-public-contract：一次性只读校验 helper（真实帧 × net 0.2 契约 × 商店公开闭合）。

本 helper 只读：固定 Host 身份、负责人已录的两份真实商店轨迹
（`.audit/owner-project-review-20261012/shop-{buy-remove,remove}/`）、
`docs/contracts/net/0.2/wire.schema.json` 与 `tools/contract-check/wire_layers.py`。
它不写任何生产文件、不启动 Host、不构建 C#、不重算玩法、不生成随机结果。

它回答四个问题：

1. **L1 结构**：`frames.ndjson` 里每一帧 request/response（含内嵌 snapshot）是否满足 0.2 wire schema。
2. **L2/L3 语义**：公开目录（`get_catalog` 结果）内部闭合，以及每个公开快照对目录的引用闭合、
   适用域、数量、唯一性、排序（复用只读的 `tools/contract-check/wire_layers.py`）。
3. **L4 控制**：request/response 配对、账本、能力声明——**按 0.2 改写**两处旧 0.1 规则：
   `start` 结果形状是 `{session_id, seed, snapshot}`；`start.payload.seed` 是 0.2 的游戏 seed
   字符串（非空），不是 0.1 的规范 uint64 十进制字符串。改写点全部打印，避免用旧限制判 0.2。
4. **商店公开闭合**：14 格库存与不可买原因、买卡永久副本与金币一次扣除、
   `RemoveShopCard` 暂停后按已公开实例删对牌、`MapPhase 7 -> 2` 与后续合法候选。

用法（仓库根目录）::

    python -X utf8 -u .audit/dsh-shop-public-contract-20261012/verify_shop_contract.py
    python -X utf8 -u .audit/dsh-shop-public-contract-20261012/verify_shop_contract.py --verbose
    python -X utf8 -u .audit/dsh-shop-public-contract-20261012/verify_shop_contract.py --json-out <path>

退出码：0 = 全部通过；1 = 存在违规（首条给具体定位）；2 = 资产/输入缺失。
"""

from __future__ import annotations

import argparse
import hashlib
import json
import pathlib
import sys
from dataclasses import dataclass, field

HERE = pathlib.Path(__file__).resolve().parent          # .audit/dsh-shop-public-contract-20261012
ROOT = HERE.parents[1]                                  # 仓库根
CONTRACT_CHECK = ROOT / "tools" / "contract-check"
sys.path.insert(0, str(CONTRACT_CHECK))

import wire_layers  # noqa: E402  (只读复用；0.2 差异在下方显式覆盖)

SCHEMA_PATH = ROOT / "docs" / "contracts" / "net" / "0.2" / "wire.schema.json"
HOST_DLL = (ROOT / ".artifacts" / "parallel" / "owner-project-review-20261012" / "bin"
            / "Net.TheSpire.Host" / "debug" / "Net.TheSpire.Host.dll")
DEFAULT_RUN_DIRS = [
    ROOT / ".audit" / "owner-project-review-20261012" / "shop-buy-remove",
    ROOT / ".audit" / "owner-project-review-20261012" / "shop-remove",
]

SHOP_PHASE = 7
TRAVEL_READY_PHASE = 2        # LeaveShop 回到的旅行相位（真实帧 20/23 步观察值）
SHOP_ACTION_NAMES = ("BuyShopCard", "BuyShopRelic", "BuyShopPotion", "RemoveShopCard", "LeaveShop")
SHOP_OFFERS_SEQUENCE = "ShopOffers"
SHOP_OFFER_KINDS = ("card", "relic", "potion", "removal")
EXPECTED_SHELF_SLOTS = 14
SECRET_PATTERN = ("rng", "random", "seed", "debug", "hidden", "internal")


# --------------------------------------------------------------------------- #
# 发现记录
# --------------------------------------------------------------------------- #
@dataclass
class Finding:
    rule: str
    path: str
    message: str

    def render(self) -> str:
        return f"[{self.rule}] {self.path}: {self.message}"


@dataclass
class Report:
    findings: list[Finding] = field(default_factory=list)
    facts: dict = field(default_factory=dict)
    counts: dict = field(default_factory=dict)

    def bad(self, rule: str, path: str, message: str) -> None:
        self.findings.append(Finding(rule, path, message))

    def want(self, condition: bool, rule: str, path: str, message: str) -> bool:
        if not condition:
            self.bad(rule, path, message)
        return bool(condition)

    def bump(self, name: str, amount: int = 1) -> None:
        self.counts[name] = self.counts.get(name, 0) + amount


#: 把违规按"是否是商店公开闭合"和"是否是本包无写权限的 Host 侧声明"分开，避免一条 Host 侧
#: 结构声明问题掩盖商店收口结论。
HOST_SIDE_RULES = ("L4/I-84",)


def classify(finding: Finding) -> str:
    if finding.rule.startswith("shop/"):
        return "商店公开闭合"
    if finding.rule in HOST_SIDE_RULES and "supported_structures" in finding.path:
        return "Host 结构声明（非本包写权限，待负责人裁决）"
    return "0.2 wire 门槛（L1/L2/L3/L4）"


# --------------------------------------------------------------------------- #
# 0.2 覆盖：两处旧 0.1 规则不适用于 0.2
# --------------------------------------------------------------------------- #
OVERRIDES: list[str] = []

#: 0.2 `StartResult = {session_id, seed, snapshot}`（0.1 只有 `{session_id, snapshot}`）。
START_RESULT_KEYS_02 = frozenset({"session_id", "seed", "snapshot"})


def result_matches_02(operation: str, result) -> bool:
    if operation == "start":
        return isinstance(result, dict) and frozenset(result) == START_RESULT_KEYS_02
    return _ORIGINAL_RESULT_MATCHES(operation, result)


def seed_02(seed, path: str) -> list:
    """0.2 的 `start.payload.seed` 是游戏 seed 字符串（`GameSeedString`：非空字符串）。

    0.1 的 I-76（规范 uint64 十进制字符串）**不适用于 0.2**：真实轨迹用 `ENV-T03-SEED-L`
    这类文本 seed。这里只按 0.2 检查"非空字符串"，不按 0.1 的数值形式判 0。
    """
    if not isinstance(seed, str):
        return [wire_layers._f("I-76-02", "L4", path, "0.2 seed 必须是字符串（GameSeedString）")]
    if not seed:
        return [wire_layers._f("I-76-02", "L4", path, "0.2 seed 必须非空（GameSeedString minLength=1）")]
    return []


_ORIGINAL_RESULT_MATCHES = wire_layers._result_matches
_ORIGINAL_CHECK_SEED = wire_layers._check_seed
wire_layers._result_matches = result_matches_02
wire_layers._check_seed = seed_02
OVERRIDES.append(
    "L4 I-81 start 结果形状改用 0.2 的 {session_id, seed, snapshot}（0.1 为 {session_id, snapshot}）")
OVERRIDES.append(
    "L4 I-76 start.payload.seed 改用 0.2 GameSeedString（非空字符串）；不再要求 0.1 的规范 uint64 十进制")


# --------------------------------------------------------------------------- #
# 资产与帧读取
# --------------------------------------------------------------------------- #
def sha256_file(path: pathlib.Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def read_frames(path: pathlib.Path) -> list:
    out = []
    for index, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        if not line.strip():
            continue
        record = json.loads(line)
        record["_line"] = index
        out.append(record)
    return out


# --------------------------------------------------------------------------- #
# 公开快照的只读访问（形状与 net-the-spire/client/public_snapshot.py 一致，但本 helper 独立实现，
# 以便在被测消费者之外独立读取公开字段）
# --------------------------------------------------------------------------- #
def field_value(entity, name):
    if not entity:
        return None
    for item in entity.get("fields") or []:
        fid = item.get("field_id") or ""
        if fid.endswith("." + name) and item.get("state") == "known":
            raw = item.get("value")
            if isinstance(raw, str) and raw.lstrip("-").isdigit():
                return int(raw)
            return raw
    return None


def entities_of(snapshot: dict) -> dict:
    if not isinstance(snapshot, dict):
        return {}
    return {item["instance_id"]: item for item in snapshot.get("entities") or []}


def find_entity(snapshot: dict, kind_suffix: str):
    if not isinstance(snapshot, dict):
        return None
    for item in snapshot.get("entities") or []:
        if (item.get("kind_id") or "").endswith(":" + kind_suffix):
            return item
    return None


def sequence_of(snapshot: dict, type_suffix: str) -> list:
    if not isinstance(snapshot, dict):
        return []
    for item in snapshot.get("sequences") or []:
        if (item.get("type_id") or "").endswith(":" + type_suffix):
            return list(item.get("elements") or [])
    return []


def candidate_action(candidate: dict) -> str:
    return (candidate.get("action_type") or "").rsplit(":", 1)[-1]


def candidate_offer_ref(candidate: dict):
    for item in candidate.get("fields") or []:
        if (item.get("field_id") or "").endswith(".Offer") and item.get("state") == "known":
            return item.get("value")
    return None


def candidate_instance_ref(candidate: dict):
    for item in candidate.get("fields") or []:
        if item.get("state") == "known":
            return item.get("value")
    return None


# --------------------------------------------------------------------------- #
# 帧分层
# --------------------------------------------------------------------------- #
def split_frames(frames: list) -> dict:
    requests, responses, ledger, snapshots = [], [], {}, []
    for record in frames:
        body = record.get("frame") or {}
        if record.get("dir") == "client->host":
            requests.append(body)
            if body.get("request_id") is not None:
                ledger[body["request_id"]] = body.get("operation")
        else:
            responses.append(body)
        result = body.get("result") if isinstance(body, dict) else None
        if isinstance(result, dict) and isinstance(result.get("snapshot"), dict):
            snapshots.append(result["snapshot"])
        elif isinstance(body, dict) and "legal_actions" in body and "observations" not in body \
                and body.get("protocol_version") == "0.2":
            snapshots.append(body)
    return {"requests": requests, "responses": responses, "ledger": ledger, "snapshots": snapshots}


def build_steps(frames: list) -> list:
    """按 `request_id` 配对 step 请求与响应，生成 `[{request, pre, post, response, rejected}]`。

    **被拒绝的 step 必须没有快照、也不得推进**：它对不上「后置快照」，只在 `post=None` +
    `rejected=True` 里留证；后续步骤的 `pre` 必须仍是同一个快照（拒绝不推进）。
    非 step 响应（start/observe/attach）携带的公开快照推进 `current`（observe 是公开读，不推进状态）。
    """
    by_id, steps, current = {}, [], None
    for record in frames:
        body = record.get("frame") or {}
        if record.get("dir") == "client->host":
            if body.get("request_id") is not None:
                by_id[body["request_id"]] = body
            continue
        request = by_id.get(body.get("request_id"))
        result = body.get("result") if isinstance(body, dict) else None
        snapshot = result.get("snapshot") if isinstance(result, dict) else None
        usable = isinstance(snapshot, dict) and "legal_actions" in snapshot
        if request is None or request.get("operation") != "step":
            if usable:
                current = snapshot
            continue
        steps.append({"request": request, "pre": current, "post": snapshot if usable else None,
                      "response": body, "line": record["_line"], "rejected": not usable})
        if usable:
            current = snapshot
    return steps


# --------------------------------------------------------------------------- #
# 检查 1：身份与固定构建
# --------------------------------------------------------------------------- #
def check_identity(report: Report, run_dir: pathlib.Path, summary: dict, asset_sha: dict) -> None:
    where = f"{run_dir.name}"
    host = summary.get("host") or {}
    recorded = (host.get("dll_sha256") or "").upper()
    actual = asset_sha.get("host_dll_sha256")
    report.facts.setdefault("build", {})[where] = {
        "host_dll": host.get("dll"),
        "recorded_dll_sha256": recorded,
        "fixed_host_dll_sha256": actual,
        "identity": summary.get("identity"),
        "scenario_profile": summary.get("scenario_profile"),
        "seed_accepted": summary.get("seed_accepted"),
        "scope": summary.get("scope"),
    }
    report.want(recorded == actual, "build/host-sha",
                f"{where}.summary.host.dll_sha256",
                f"记录 {recorded} != 固定 Host 实际 {actual}（证据必须来自同一构建）")
    identity = summary.get("identity") or {}
    report.want(identity.get("protocol_version") == "0.2", "build/protocol",
                f"{where}.summary.identity.protocol_version",
                f"协议版本必须是 0.2，实际 {identity.get('protocol_version')!r}")
    for key in ("ruleset_id", "catalog_id", "backend_profile_id"):
        report.want(bool(identity.get(key)), "build/identity", f"{where}.summary.identity.{key}",
                    "身份字段缺失")


# --------------------------------------------------------------------------- #
# 检查 2：L1 结构（0.2 wire schema）
# --------------------------------------------------------------------------- #
def check_l1(report: Report, run_dir: pathlib.Path, frames: list, schema: dict) -> None:
    import jsonschema

    where = run_dir.name
    defs = schema.get("$defs") or {}

    def validator_for(def_name: str):
        sub = {"$schema": schema["$schema"], "$defs": defs, "$ref": f"#/$defs/{def_name}"}
        return jsonschema.Draft202012Validator(sub)

    request_validator = validator_for("Request")
    response_validator = validator_for("Response")
    snapshot_validator = validator_for("PublicSnapshot")
    catalog_validator = validator_for("PublicCatalog")

    for record in frames:
        body = record.get("frame") or {}
        tag = f"{where}.frames.ndjson:{record['_line']}"
        if record.get("dir") == "client->host":
            for error in request_validator.iter_errors(body):
                report.bad("L1/0.2-Request", tag + "".join(f"[{p}]" for p in error.absolute_path),
                           error.message[:300])
            report.bump("l1_request_frames")
        else:
            for error in response_validator.iter_errors(body):
                report.bad("L1/0.2-Response", tag + "".join(f"[{p}]" for p in error.absolute_path),
                           error.message[:300])
            report.bump("l1_response_frames")
            result = body.get("result") if isinstance(body, dict) else None
            if isinstance(result, dict) and isinstance(result.get("declarations"), dict):
                for error in catalog_validator.iter_errors(result):
                    report.bad("L1/0.2-Catalog", tag + "".join(f"[{p}]" for p in error.absolute_path),
                               error.message[:300])
        result = body.get("result") if isinstance(body, dict) else None
        snapshot = result.get("snapshot") if isinstance(result, dict) else None
        if isinstance(snapshot, dict):
            for error in snapshot_validator.iter_errors(snapshot):
                report.bad("L1/0.2-Snapshot", tag + "".join(f"[{p}]" for p in error.absolute_path),
                           error.message[:300])
            report.bump("l1_snapshots")


# --------------------------------------------------------------------------- #
# 检查 3：L2/L3 语义（只读复用 wire_layers）
# --------------------------------------------------------------------------- #
def check_l2_l3(report: Report, run_dir: pathlib.Path, parts: dict) -> dict:
    where = run_dir.name
    catalog = None
    for response in parts["responses"]:
        result = response.get("result") if isinstance(response, dict) else None
        if isinstance(result, dict) and isinstance(result.get("declarations"), dict):
            catalog = result
            break
    if catalog is None:
        report.bad("L2/catalog", f"{where}.frames.ndjson",
                   "轨迹里没有 get_catalog 结果：无法做目录闭合与快照对目录检查")
        return {}
    for finding in wire_layers.check_catalog(catalog):
        report.bad(f"L2/{finding.rule_id}", f"{where}.{finding.path}", finding.message)
    report.bump("l2_catalog_declarations", sum(
        len(items) for items in (catalog.get("declarations") or {}).values() if isinstance(items, list)))

    for index, snapshot in enumerate(parts["snapshots"]):
        report.want(snapshot.get("catalog_id") == catalog.get("catalog_id"), "L3/catalog-id",
                    f"{where}.snapshot[{index}].catalog_id",
                    f"快照 catalog_id {snapshot.get('catalog_id')!r} != 目录 "
                    f"{catalog.get('catalog_id')!r}")
        for finding in wire_layers.check_snapshot(snapshot, catalog):
            report.bad(f"L3/{finding.rule_id}",
                       f"{where}.snapshot[obs={snapshot.get('observation_id')}].{finding.path}",
                       finding.message)
        report.bump("l3_snapshots")
    return catalog


# --------------------------------------------------------------------------- #
# 检查 4：L4 控制（0.2）
# --------------------------------------------------------------------------- #
def check_l4(report: Report, run_dir: pathlib.Path, parts: dict, catalog, summary: dict) -> None:
    where = run_dir.name
    findings = wire_layers.check_control(requests=parts["requests"], responses=parts["responses"],
                                         catalog=catalog)
    for finding in findings:
        report.bad(f"L4/{finding.rule_id}", f"{where}.{finding.path}", finding.message)

    for response in parts["responses"]:
        result = response.get("result") if isinstance(response, dict) else None
        if isinstance(result, dict) and isinstance(result.get("capabilities"), dict):
            for finding in wire_layers.check_capabilities(result["capabilities"], catalog):
                report.bad(f"L4/{finding.rule_id}", f"{where}.{finding.path}", finding.message)
        if isinstance(result, dict) and ("session_status" in result):
            for finding in wire_layers.check_result_state_combinations(
                    result, "observe_result" if "session_status" in result else "attach_result"):
                report.bad(f"L4/{finding.rule_id}", f"{where}.{finding.path}", finding.message)

    # 0.2：start 请求的 seed 必须被原样接受并在 start 结果里回显（seed_action_replay=public_trace）。
    start_request = next((item for item in parts["requests"] if item.get("operation") == "start"), None)
    start_result = None
    for response in parts["responses"]:
        request_id = response.get("request_id") if isinstance(response, dict) else None
        if request_id and parts["ledger"].get(request_id) == "start":
            start_result = response.get("result")
            break
    if start_request is not None and isinstance(start_result, dict):
        requested = (start_request.get("payload") or {}).get("seed")
        echoed = start_result.get("seed")
        report.want(requested == echoed, "L4/I-76-02-echo",
                    f"{where}.start.result.seed",
                    f"0.2 start 结果必须回显本局实际 seed：请求 {requested!r} != 结果 {echoed!r}")
        report.want(echoed == summary.get("seed_accepted"), "L4/seed-summary",
                    f"{where}.summary.seed_accepted",
                    f"summary.seed_accepted {summary.get('seed_accepted')!r} != start.seed {echoed!r}")
        report.facts.setdefault("seed", {})[where] = {"requested": requested, "echoed": echoed}
        report.bump("l4_seed_echo_checked")

    # 目录声明的动作类型 vs 快照里实际发布的动作类型（只做包含关系，不要求目录里的动作都出现）。
    if isinstance(catalog, dict):
        declared = {(item.get("id") or "").rsplit(":", 1)[-1]
                    for item in (catalog.get("declarations") or {}).get("action_types") or []}
        for name in SHOP_ACTION_NAMES:
            report.want(name in declared, "L4/shop-actions-declared", f"{where}.catalog.action_types",
                        f"目录未声明商店动作 {name}")


# --------------------------------------------------------------------------- #
# 检查 5：商店公开闭合
# --------------------------------------------------------------------------- #
def _coerce(value):
    """公开 decimal 字段在 wire 上是字符串；这里与 `public_snapshot.field` 同规则转回整数。"""
    if isinstance(value, str) and value.lstrip("-").isdigit():
        return int(value)
    return value


def offer_rows(snapshot: dict) -> list:
    entities = entities_of(snapshot)
    rows = []
    for position, ref in enumerate(sequence_of(snapshot, SHOP_OFFERS_SEQUENCE)):
        entity = entities.get(ref) if isinstance(ref, str) else None
        rows.append({"position": position, "ref": ref, "kind_id": (entity or {}).get("kind_id"),
                     "fields": {item.get("field_id", "").rsplit(".", 1)[-1]: _coerce(item.get("value"))
                                for item in (entity or {}).get("fields") or []
                                if item.get("state") == "known"}})
    return rows


def int_field(entity, name):
    value = field_value(entity, name)
    return value if isinstance(value, int) else None


def public_run_fields(snapshot) -> dict:
    """Run 实体的全部公开字段（用来判「拒绝不推进」——逐字段比较，不做子集比较）。"""
    if not isinstance(snapshot, dict):
        return {}
    run = find_entity(snapshot, "Run")
    return {item.get("field_id", "").rsplit(".", 1)[-1]: _coerce(item.get("value"))
            for item in (run or {}).get("fields") or [] if item.get("state") == "known"}


def last_usable_post(steps: list):
    for step in reversed(steps):
        if isinstance(step.get("post"), dict):
            return step["post"]
    return None


def check_shop(report: Report, run_dir: pathlib.Path, frames: list, summary: dict, catalog) -> None:
    where = run_dir.name
    steps = build_steps(frames)
    if not steps:
        report.bad("shop/frames", f"{where}.frames.ndjson", "没有可分析的 step 帧")
        return

    # 候选闭合：每一步提交的 candidate_id 必须在该步前置快照的 legal_actions 里（同观察号）。
    # 被拒绝的 step 是**负对照**：必须有具名错误、没有快照，且不得推进公开状态。
    for index, step in enumerate(steps):
        payload = step["request"].get("payload") or {}
        pre = step["pre"]
        tag = f"{where}.step#{index + 1}(obs={None if pre is None else pre.get('observation_id')})"
        expected = payload.get("expected_observation_id")
        if step["rejected"]:
            error = step["response"].get("error") or {}
            nxt = steps[index + 1] if index + 1 < len(steps) else None
            report.want(step["response"].get("ok") is False, "shop/rejected-step-ok", tag,
                        "被拒绝的 step 必须 ok=false")
            report.want(step["post"] is None, "shop/rejected-step-no-snapshot", tag,
                        "被拒绝的 step 不得返回快照")
            report.want(isinstance(error, dict) and error.get("code") and error.get("execution_state")
                        and error.get("retry_mode"), "shop/rejected-step-error", tag,
                        f"拒绝必须有具名 code/execution_state/retry_mode，实际 {error}")
            report.want(error.get("execution_state") in ("not_started", "completed"),
                        "shop/rejected-step-execution-state", tag,
                        f"拒绝的 execution_state={error.get('execution_state')!r} 不是"
                        f"not_started/completed（不得是 unknown）")
            report.want(expected == (pre or {}).get("observation_id"),
                        "shop/rejected-step-expected-obs", tag,
                        f"负对照用的 expected_observation_id={expected} 必须就是当前观察号")
            if nxt is not None:
                report.want(nxt["pre"] is pre or (
                    (nxt["pre"] or {}).get("observation_id") == (pre or {}).get("observation_id")
                    and public_run_fields(nxt["pre"]) == public_run_fields(pre)),
                    "shop/rejected-step-no-advance", tag,
                    "被拒绝后下一步的前置快照必须与拒绝前完全相同（拒绝不推进）")
            report.facts.setdefault("rejected_steps", {}).setdefault(where, []).append(
                {"obs": (pre or {}).get("observation_id"),
                 "candidate_id": payload.get("candidate_id"),
                 "error_code": error.get("code"), "execution_state": error.get("execution_state"),
                 "retry_mode": error.get("retry_mode"),
                 "advanced": not (nxt is not None and (nxt["pre"] or {}).get("observation_id")
                                  == (pre or {}).get("observation_id"))})
            report.bump("shop_rejected_steps")
            continue
        legal = {item.get("candidate_id"): item for item in pre.get("legal_actions") or []}
        candidate_id = payload.get("candidate_id")
        report.want(step["response"].get("ok") is True, "shop/step-ok", tag,
                    f"step 失败：{json.dumps(step['response'].get('error'), ensure_ascii=False)[:200]}")
        report.want(expected == pre.get("observation_id"), "shop/expected-obs", tag,
                    f"expected_observation_id={expected} != 前置快照 observation_id "
                    f"{pre.get('observation_id')}")
        report.want(candidate_id in legal, "shop/candidate-closure", tag,
                    f"candidate_id={candidate_id!r} 不在该步前置快照的 legal_actions 里")
        report.bump("shop_steps")
        if candidate_id not in legal:
            continue
        step["action"] = candidate_action(legal[candidate_id])
        step["candidate"] = legal[candidate_id]
        step["tag"] = tag

    shop_steps = [step for step in steps if "action" in step and step["action"] in SHOP_ACTION_NAMES]
    phase7 = [step for step in steps if int_field(find_entity(step["pre"], "Run"), "MapPhase") == SHOP_PHASE]
    report.want(bool(phase7), "shop/phase7", f"{where}.frames.ndjson",
                "整段轨迹里没有出现公开 MapPhase=7（没有进店证据）")
    if not phase7:
        return

    entry_snapshot = phase7[0]["pre"]
    visit_snapshots = []
    for step in steps:
        if int_field(find_entity(step["pre"], "Run"), "MapPhase") == SHOP_PHASE:
            for candidate_snapshot in (step["pre"], step["post"]):
                if isinstance(candidate_snapshot, dict) and candidate_snapshot not in visit_snapshots:
                    visit_snapshots.append(candidate_snapshot)
    run_entry = find_entity(entry_snapshot, "Run")
    gold_entry = int_field(run_entry, "Gold")
    removals_entry = int_field(run_entry, SHOP_REMOVALS_USED := "ShopCardRemovalsUsed")

    # --- 5.1 14 格库存与不可买原因 ---
    rows = offer_rows(entry_snapshot)
    report.facts.setdefault("shelf", {})[where] = {
        "entry_observation_id": entry_snapshot.get("observation_id"),
        "gold": gold_entry,
        "removals_used": removals_entry,
        "slots": [row["fields"].get("Slot") for row in rows],
        "kinds": [row["fields"].get("Kind") for row in rows],
        "prices": [row["fields"].get("Price") for row in rows],
        "unsupported": [row["fields"].get("SourceName") or row["fields"].get("DefinitionId")
                        for row in rows if row["fields"].get("Unsupported") is True],
        "sold_at_entry": [row["ref"] for row in rows if row["fields"].get("Sold") is True],
    }
    report.want(len(rows) == EXPECTED_SHELF_SLOTS, "shop/shelf-size",
                f"{where}.{SHOP_OFFERS_SEQUENCE}",
                f"进店货架 {len(rows)} 格 != {EXPECTED_SHELF_SLOTS} 格")
    slots = [row["fields"].get("Slot") for row in rows]
    report.want(slots == list(range(EXPECTED_SHELF_SLOTS)), "shop/shelf-slots",
                f"{where}.{SHOP_OFFERS_SEQUENCE}",
                f"公开 Slot 必须是 0..{EXPECTED_SHELF_SLOTS - 1} 且按发布顺序递增，实际 {slots}")
    for row in rows:
        tag = f"{where}.ShopOffers[slot={row['fields'].get('Slot')}]"
        report.want((row["kind_id"] or "").endswith(":ShopOffer"), "shop/offer-kind", tag,
                    f"货架元素 kind_id={row['kind_id']!r} 不是 ShopOffer")
        report.want(row["fields"].get("Kind") in SHOP_OFFER_KINDS, "shop/offer-field-kind", tag,
                    f"Kind={row['fields'].get('Kind')!r} 不在 {SHOP_OFFER_KINDS}")
        for name in ("Slot", "Kind", "DefinitionId", "SourceName", "Rarity", "PoolKind",
                     "PoolIndex", "OnSale", "Price", "Sold", "Unsupported", "UnsupportedReason"):
            report.want(name in row["fields"], "shop/offer-required-public", tag,
                        f"公开字段 {name} 未 known（不猜值）")
        if row["fields"].get("Unsupported") is True:
            reason = row["fields"].get("UnsupportedReason")
            report.want(isinstance(reason, str) and reason.strip() != "", "shop/unsupported-reason", tag,
                        "Unsupported=true 但没有给出非空 UnsupportedReason")
            identity = row["fields"].get("DefinitionId") or row["fields"].get("SourceName")
            report.want(bool(identity), "shop/unsupported-identity", tag,
                        "不可买条目既没有 DefinitionId 也没有 SourceName：无法保留源身份")

    # 不可买/已售的公开条目不得出现在同一快照的可买候选里。
    for snapshot in visit_snapshots:
        entities = entities_of(snapshot)
        bad_refs = set()
        for row in offer_rows(snapshot):
            if row["fields"].get("Sold") is True or row["fields"].get("Unsupported") is True:
                bad_refs.add(row["ref"])
        for candidate in snapshot.get("legal_actions") or []:
            ref = candidate_offer_ref(candidate) or candidate_instance_ref(candidate)
            if ref in bad_refs:
                report.bad("shop/unbuyable-not-offered",
                           f"{where}.obs={snapshot.get('observation_id')}",
                           f"已售/不可买条目 {ref}（{entities.get(ref, {}).get('instance_id')}）"
                           f"出现在候选 {candidate.get('candidate_id')} 里")
        report.bump("shop_visit_snapshots")

    # --- 5.2 买卡：永久副本 + 金币一次扣除（期望按记录策略，不按未发生的分支判失败） ---
    recorded_policy = summary.get("policy") or {}
    buys = [step for step in shop_steps if step["action"].startswith("Buy")]
    if recorded_policy.get("shop_policy") == "buy":
        report.want(bool(buys), "shop/buy-present", f"{where}.frames.ndjson",
                    "记录策略是 --shop-policy=buy，但轨迹里没有购买步骤")
    else:
        report.want(not buys, "shop/buy-absent", f"{where}.frames.ndjson",
                    f"记录策略是 {recorded_policy.get('shop_policy')!r}，但轨迹里出现了购买步骤")
    for step in buys:
        tag = step["tag"]
        ref = candidate_offer_ref(step["candidate"])
        entities_pre = entities_of(step["pre"])
        offer = entities_pre.get(ref) if isinstance(ref, str) else None
        report.want(offer is not None, "shop/buy-offer", tag,
                    f"购买候选的 Offer={ref!r} 不在前置快照实体里")
        if offer is None:
            continue
        price = int_field(offer, "Price")
        definition_id = field_value(offer, "DefinitionId")
        kind = field_value(offer, "Kind")
        gold_pre = int_field(find_entity(step["pre"], "Run"), "Gold")
        gold_post = int_field(find_entity(step["post"], "Run"), "Gold")
        report.want(isinstance(price, int) and gold_pre is not None and gold_post is not None
                    and gold_pre - gold_post == price, "shop/buy-gold-once", tag,
                    f"金币必须恰好扣一次：{gold_pre} -> {gold_post}，公开 Price={price}")
        report.want(field_value(entities_of(step["post"]).get(ref), "Sold") is True,
                    "shop/buy-mark-sold", tag,
                    f"购买后同一公开货架条目 {ref} 的 Sold 必须为 true")
        gold_after_visit = gold_post
        # 买卡：永久副本必须进公开 LongTermDeck，且此后一直留在那里。
        if kind == "card":
            deck_pre = sequence_of(step["pre"], "LongTermDeck")
            deck_post = sequence_of(step["post"], "LongTermDeck")
            added = [item for item in deck_post if item not in deck_pre]
            report.want(len(added) == 1 and len(deck_post) == len(deck_pre) + 1, "shop/buy-deck-add", tag,
                        f"买卡后公开 LongTermDeck 必须恰好 +1：{len(deck_pre)} -> {len(deck_post)}，"
                        f"新增={added}")
            if len(added) == 1:
                new_ref = added[0]
                new_entity = entities_of(step["post"]).get(new_ref) or {}
                report.want(new_entity.get("content_id") == definition_id, "shop/buy-copy-identity", tag,
                            f"新副本 content_id={new_entity.get('content_id')!r} != 商品 DefinitionId "
                            f"{definition_id!r}")
                last = last_usable_post(steps)
                report.want(last is not None and new_ref in sequence_of(last, "LongTermDeck"),
                            "shop/buy-copy-permanent", tag,
                            f"买到的实例 {new_ref} 在轨迹末尾已不在公开 LongTermDeck 里（不是永久副本）")
        report.facts.setdefault("buys", {}).setdefault(where, []).append(
            {"obs": step["pre"].get("observation_id"), "candidate": step["candidate"]["candidate_id"],
             "offer_ref": ref, "kind": kind, "definition_id": definition_id, "price": price,
             "gold": [gold_pre, gold_post]})

    # --- 5.3 删牌：暂停后按已公开实例删对牌 ---
    # 配对规则：`RemoveShopCard` 的**下一步**必须是同一观察号上的 `net.answer_decision`（删牌 decision），
    # 不能用"整局里所有 answer_decision"配对（战斗/手牌选择也会发 answer_decision）。
    step_index = {id(step): index for index, step in enumerate(steps)}
    removals = [step for step in shop_steps if step["action"] == "RemoveShopCard"]
    pairs = []
    for step in removals:
        index = step_index[id(step)]
        nxt = steps[index + 1] if index + 1 < len(steps) else None
        tag = step["tag"]
        if nxt is None or nxt.get("action") != "net.answer_decision" \
                or nxt["pre"].get("observation_id") != step["post"].get("observation_id"):
            report.bad("shop/remove-pair", tag,
                       "提交 RemoveShopCard 后必须紧跟同一观察号上的 net.answer_decision（删牌 decision）；"
                       f"实际下一步={None if nxt is None else (nxt.get('action'), nxt['pre'].get('observation_id'))}")
            continue
        pairs.append((step, nxt))

    # 记录要求删牌却没有删牌候选时，必须能用公开事实解释（删牌位公开 Price > 当前金币）。
    for step in phase7:
        snapshot = step["pre"]
        if any(candidate_action(item) == "RemoveShopCard" for item in snapshot.get("legal_actions") or []):
            continue
        rows = [row for row in offer_rows(snapshot) if row["fields"].get("Kind") == "removal"]
        if not rows:
            continue
        run = find_entity(snapshot, "Run")
        gold = int_field(run, "Gold")
        price = rows[0]["fields"].get("Price")
        if removals:
            continue
        report.facts.setdefault("removal_unavailable", {})[where] = {
            "observation_id": snapshot.get("observation_id"), "gold": gold,
            "removal_price": price, "slot_sold": rows[0]["fields"].get("Sold")}
        report.want(isinstance(price, int) and isinstance(gold, int) and gold < price,
                    "shop/remove-candidate-explained", f"{where}.obs={snapshot.get('observation_id')}",
                    f"删牌位 Sold=false 但没有 RemoveShopCard 候选，且公开金币 {gold} 未低于公开价格 "
                    f"{price}：候选缺失无法用公开事实解释")

    for step, answer in pairs:
        tag = step["tag"]
        paused = step["post"]
        deck_paused = sequence_of(paused, "LongTermDeck")
        entities_paused = entities_of(paused)
        decision_candidates = list(paused.get("legal_actions") or [])
        report.want(paused.get("status") == "decision", "shop/remove-paused", tag,
                    f"提交 RemoveShopCard 后必须暂停在 decision，实际 {paused.get('status')!r}")
        report.want(all(candidate_action(item) == "net.answer_decision"
                        for item in decision_candidates), "shop/remove-decision-domain", tag,
                    f"删牌 decision 只应有 net.answer_decision 候选，实际 "
                    f"{sorted({candidate_action(item) for item in decision_candidates})}")
        refs = [candidate_instance_ref(item) for item in decision_candidates]
        report.want(bool(refs) and all(isinstance(ref, str) and ref in set(deck_paused) for ref in refs),
                    "shop/remove-deck-domain", tag,
                    f"删牌 decision 候选必须是本快照公开 LongTermDeck 的实例：候选={refs}，"
                    f"LongTermDeck={deck_paused}")
        # answer 用的 candidate 必须来自暂停快照，且引用的实例已在暂停快照公开。
        answer_ref = candidate_instance_ref(answer["candidate"])
        report.want(answer["pre"].get("observation_id") == paused.get("observation_id"),
                    "shop/remove-answer-same-obs", answer["tag"],
                    f"answer 的前置观察号 {answer['pre'].get('observation_id')} != 暂停观察号 "
                    f"{paused.get('observation_id')}")
        report.want(answer_ref in refs, "shop/remove-answer-published", answer["tag"],
                    f"answer 选的实例 {answer_ref!r} 不是暂停快照里已公开的删牌候选 {refs}")
        report.want(answer_ref not in sequence_of(answer["post"], "LongTermDeck"),
                    "shop/remove-instance-gone", answer["tag"],
                    f"删除后实例 {answer_ref!r} 仍在公开 LongTermDeck 里")
        deck_after = sequence_of(answer["post"], "LongTermDeck")
        report.want(len(deck_after) == len(deck_paused) - 1, "shop/remove-deck-count", answer["tag"],
                    f"删牌后公开 LongTermDeck 必须恰好 -1：{len(deck_paused)} -> {len(deck_after)}")
        removals_pre = int_field(find_entity(step["pre"], "Run"), "ShopCardRemovalsUsed")
        removals_post = int_field(find_entity(answer["post"], "Run"), "ShopCardRemovalsUsed")
        report.want(isinstance(removals_pre, int) and isinstance(removals_post, int)
                    and removals_post - removals_pre == 1, "shop/remove-counter", answer["tag"],
                    f"ShopCardRemovalsUsed 必须恰好 +1：{removals_pre} -> {removals_post}")
        removal_ref = candidate_offer_ref(step["candidate"])
        price = int_field(entities_of(step["pre"]).get(removal_ref), "Price")
        gold_pre = int_field(find_entity(step["pre"], "Run"), "Gold")
        gold_post = int_field(find_entity(answer["post"], "Run"), "Gold")
        report.want(isinstance(price, int) and gold_pre is not None and gold_post is not None
                    and gold_pre - gold_post == price, "shop/remove-gold-once", answer["tag"],
                    f"删牌金币必须恰好扣一次：{gold_pre} -> {gold_post}，公开 Price={price}")
        report.want(field_value(entities_of(answer["post"]).get(removal_ref), "Sold") is True,
                    "shop/remove-mark-sold", answer["tag"],
                    f"删牌后删牌位 {removal_ref} 的 Sold 必须为 true")
        report.facts.setdefault("removals", {}).setdefault(where, []).append(
            {"request_obs": step["pre"].get("observation_id"), "paused_obs": paused.get("observation_id"),
             "deck_before": len(deck_paused), "deck_after": len(deck_after),
             "removed_ref": answer_ref, "removed_card": (entities_paused.get(answer_ref) or {}).get("content_id"),
             "candidates": len(decision_candidates), "price": price,
             "removals_used": [removals_pre, removals_post], "gold": [gold_pre, gold_post]})

    # --- 5.4 离店：MapPhase 7 -> 2 且后续候选合法 ---
    leaves = [step for step in shop_steps if step["action"] == "LeaveShop"]
    report.want(bool(leaves), "shop/leave-present", f"{where}.frames.ndjson",
                "商店访问没有 LeaveShop 步骤")
    for step in leaves:
        tag = step["tag"]
        phase_after = int_field(find_entity(step["post"], "Run"), "MapPhase")
        report.want(phase_after == TRAVEL_READY_PHASE, "shop/phase-back", tag,
                    f"离店后公开 MapPhase 必须回到 {TRAVEL_READY_PHASE}，实际 {phase_after}")
        legal = step["post"].get("legal_actions") or []
        report.want(bool(legal), "shop/post-leave-candidates", tag,
                    "离店后的快照没有公开候选")
        report.want(step["post"].get("status") == "decision", "shop/post-leave-status", tag,
                    f"离店后必须是 decision，实际 {step['post'].get('status')!r}")
        declared = {(item.get("id") or "") for item in
                    ((catalog or {}).get("declarations") or {}).get("action_types") or []}
        for candidate in legal:
            report.want(candidate.get("action_type") in declared, "shop/post-leave-declared", tag,
                        f"离店后候选动作 {candidate.get('action_type')!r} 未在目录声明")
        report.facts.setdefault("leaves", {}).setdefault(where, []).append(
            {"obs": step["pre"].get("observation_id"), "phase_after": phase_after,
             "gold": int_field(find_entity(step["post"], "Run"), "Gold"),
             "removals_used": int_field(find_entity(step["post"], "Run"), "ShopCardRemovalsUsed"),
             "next_candidates": [candidate_action(item) for item in legal]})

    # --- 5.5 金币总账：进店到离店的净变化 = 所有付费事件之和（每笔恰好一次） ---
    for step in leaves:
        run_exit = find_entity(step["post"], "Run")
        gold_exit = int_field(run_exit, "Gold")
        paid = sum(int_field(entities_of(item["pre"]).get(candidate_offer_ref(item["candidate"])),
                             "Price") or 0
                   for item in shop_steps
                   if item["action"].startswith("Buy") or item["action"] == "RemoveShopCard")
        report.want(gold_entry - gold_exit == paid, "shop/gold-ledger", step["tag"],
                    f"进店 {gold_entry} -> 离店 {gold_exit} 的净变化 {gold_entry - gold_exit} "
                    f"!= 付费事件之和 {paid}")
        report.facts.setdefault("gold_ledger", {})[where] = {
            "entry": gold_entry, "exit": gold_exit, "paid_sum": paid,
            "removals_used": [removals_entry, int_field(run_exit, SHOP_REMOVALS_USED)]}

    # --- 5.6 隐藏范围：公开快照不得出现非 public 字段 / 随机与调试字段 ---
    for step in steps:
        snapshot = step["post"]
        if not isinstance(snapshot, dict):
            continue
        for entity in snapshot.get("entities") or []:
            for item in entity.get("fields") or []:
                fid = item.get("field_id") or ""
                lowered = fid.lower()
                if item.get("state") == "known":
                    report.want(not any(token in lowered.split(":")[-1] for token in SECRET_PATTERN),
                                "shop/no-hidden-field",
                                f"{where}.obs={snapshot.get('observation_id')}",
                                f"公开快照发布了疑似隐藏/随机字段 {fid}")
    if isinstance(catalog, dict):
        hidden = [item.get("id") for item in
                  ((catalog.get("declarations") or {}).get("fields") or [])
                  if item.get("visibility") != "public"]
        report.facts.setdefault("declared_nonpublic_fields", {})[where] = hidden


# --------------------------------------------------------------------------- #
# 入口
# --------------------------------------------------------------------------- #
def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--run-dir", type=pathlib.Path, action="append", default=None,
                        help="已录轨迹目录（含 frames/steps/summary）；可重复，默认两份负责人轨迹")
    parser.add_argument("--schema", type=pathlib.Path, default=SCHEMA_PATH)
    parser.add_argument("--verbose", action="store_true")
    parser.add_argument("--json-out", type=pathlib.Path, default=None)
    args = parser.parse_args(argv)

    run_dirs = args.run_dir or DEFAULT_RUN_DIRS
    if not args.schema.is_file():
        print(f"缺少 0.2 schema: {args.schema}", file=sys.stderr)
        return 2
    for run_dir in run_dirs:
        if not (run_dir / "frames.ndjson").is_file():
            print(f"缺少轨迹: {run_dir / 'frames.ndjson'}", file=sys.stderr)
            return 2

    schema = json.loads(args.schema.read_text(encoding="utf-8"))
    report = Report()
    report.facts["assets"] = {
        "schema": str(args.schema.relative_to(ROOT)).replace("\\", "/"),
        "schema_sha256": sha256_file(args.schema),
        "host_dll": str(HOST_DLL.relative_to(ROOT)).replace("\\", "/"),
        "host_dll_sha256": sha256_file(HOST_DLL) if HOST_DLL.is_file() else None,
        "wire_layers": str((CONTRACT_CHECK / "wire_layers.py").relative_to(ROOT)).replace("\\", "/"),
        "l4_overrides": list(OVERRIDES),
    }
    if not HOST_DLL.is_file():
        print(f"缺少固定 Host: {HOST_DLL}", file=sys.stderr)
        return 2

    for run_dir in run_dirs:
        frames = read_frames(run_dir / "frames.ndjson")
        summary = json.loads((run_dir / "summary.json").read_text(encoding="utf-8"))
        parts = split_frames(frames)
        check_identity(report, run_dir, summary, report.facts["assets"])
        check_l1(report, run_dir, frames, schema)
        catalog = check_l2_l3(report, run_dir, parts)
        check_l4(report, run_dir, parts, catalog, summary)
        check_shop(report, run_dir, frames, summary, catalog)

    print(f"[verify_shop_contract] schema={report.facts['assets']['schema']} "
          f"sha256={report.facts['assets']['schema_sha256'][:16]}…")
    print(f"[verify_shop_contract] host={report.facts['assets']['host_dll']} "
          f"sha256={report.facts['assets']['host_dll_sha256']}")
    print("[verify_shop_contract] 0.1->0.2 L4 覆盖（不按旧 0.1 判 0.2）：")
    for item in OVERRIDES:
        print("  -", item)
    print("[verify_shop_contract] 实际执行数：" + json.dumps(report.counts, sort_keys=True))

    if args.verbose:
        print("[verify_shop_contract] 事实：")
        print(json.dumps(report.facts, ensure_ascii=False, indent=1))

    if report.findings:
        buckets: dict[str, list] = {}
        for item in report.findings:
            buckets.setdefault(classify(item), []).append(item)
        print(f"[verify_shop_contract] 违规 {len(report.findings)} 条，按类分列：")
        for name in ("0.2 wire 门槛（L1/L2/L3/L4）", "商店公开闭合",
                     "Host 结构声明（非本包写权限，待负责人裁决）"):
            items = buckets.get(name) or []
            print(f"  - {name}: {len(items)}")
        for name, items in buckets.items():
            print(f"[verify_shop_contract] {name} 首个具体定位：")
            print("  -", items[0].render())
    else:
        print("[verify_shop_contract] 全部通过：0 违规")

    if args.json_out:
        args.json_out.write_text(json.dumps(
            {"counts": report.counts, "facts": report.facts,
             "findings": [{"rule": f.rule, "path": f.path, "message": f.message}
                          for f in report.findings]},
            ensure_ascii=False, indent=1), encoding="utf-8")
        print(f"[verify_shop_contract] 结果已写入 {args.json_out}")
    return 1 if report.findings else 0


if __name__ == "__main__":
    raise SystemExit(main())
