# ENV-T05 真实奖励闭环 — 冻结源依据与实现方案（准备期设计）

本文件是**准备期**产出：共享编译门关闭（B 会话 `session-8cf3be04-54db-46da-84c6-c97820fb95db`
`running: true`，`asOfSeq` 105→133→255→382→475，交接 `docs/review/tofix/dsh-env-t04-map-resume-handoff-2026-10-09.md`
不存在），因此**未改任何参与编译的源、未构建**。全部结论来自只读源核对，路径相对仓库根 `F:/Scylier-Project/active/auto-the-spire`。

---

## 1. 源调用链（普通战斗房 → 奖励集）

| 步骤 | 源位置 | 事实 |
| --- | --- | --- |
| 战斗结束 | `sts2/src/Core/Combat/CombatManager.cs:970 EndCombatInternal()` | `:1011 room.MarkPreFinished()` 在 `:988 AfterCombatEnd`、`:999 AfterCombatVictory`、`:995-998 player.AfterCombatEnd()` **之后** ⇒ 末次击杀余效先完再开礼 |
| 失败路径 | `sts2/src/Core/Combat/CombatManager.cs:963 ProcessPendingLoss()` | 也触发 `CombatEnded`，但**不走** `EndCombatInternal`、**不给奖励** |
| 开礼 | `sts2/src/Core/Rooms/CombatRoom.cs:267` | `RewardsCmd.GenerateForRoomEnd(player, this)`；宝箱房同形状在 `sts2/src/Core/Rooms/TreasureRoom.cs:82`（本包不实现） |
| 入口 | `sts2/src/Core/Commands/RewardsCmd.cs:20 OfferForRoomEnd(player, room)` | `room is CombatRoom` 且 `Encounter is not null && !Encounter.ShouldGiveRewards` → `RewardsSet.EmptyForRoom(room)`；否则 `new RewardsSet(player).WithRewardsFromRoom(room)` → `await rewardsSet.Offer()`（`Player.Creature.IsDead` 时直接返回） |
| 生成 | `sts2/src/Core/Rewards/RewardsSet.cs:85 WithRewardsFromRoom(room)` | 末幕 Boss 返回空；`TryGenerateTutorialRewards`（`:258-327`，要求 `UnlockState.NumberOfRuns == 0` 且 Ironclad）——**base 恒 All 解锁，不走教程奖励** |
| Monster 分支 | `sts2/src/Core/Rewards/RewardsSet.cs:224-231` | ①`GoldProportion > 0f` 时加 `GoldReward`；②`RollForPotionAndAddTo`（`:248-256`）仅 `PotionRewardOdds.Roll(...)` 为真才加 `PotionReward`；③加 `CardReward(CardCreationOptions.ForRoom(player, RoomType.Monster), 3, player)` |
| 抽取时机 | `sts2/src/Core/Rewards/RewardsSet.cs:125-147 GenerateWithoutOffering()` | 按 `Rewards` 列表顺序逐个 `reward.Populate()`，再 `Rewards.Sort((x,y) => x.RewardsSetIndex.CompareTo(y.RewardsSetIndex))` ⇒ **抽取顺序 = 加入顺序（金→药水→卡），显示顺序按 index 排序** |

`RewardsSetIndex`（排序用，非抽取顺序）：`GoldReward.cs:32 => 1`、`PotionReward.cs:28 => 2`、
`RelicReward.cs:42 => 3`、`SpecialCardReward.cs:36 => 4`、`CardReward.cs:57 => 5`、`CardRemovalReward.cs:17 => 7`、
`LinkedRewardSet.cs:16 => Rewards.Max(...)`。

奖励实体基类 `sts2/src/Core/Rewards/Reward.cs`：`:39 abstract int RewardsSetIndex`、`:46 abstract bool IsPopulated`、
`:51 SuccessfullySelected { get; private set; }`、`:83 abstract void Populate()`、`:92 protected abstract Task<bool> OnSelect()`、
`:111 virtual void OnSkipped()`、`:122-131 bool success = await OnSelect(); if (success) SuccessfullySelected = true;`。

---

## 2. 随机消费时序（普通战斗房、Ascension=0、第 1 幕、Ironclad）

流：玩家 `PlayerRngType.Rewards`。base 已冻结映射：源 `Rewards` → 引擎流名 `rewards`
（`mod-the-spire/base-spire/BaseSpire/Slice/VanillaRandomLayout.cs:45`
`PlayerStreamTypes = ["Rewards","Shops","Transformations"]`）。

固定 **11 次抽取**，顺序不可换：

| # | 次数 | 位置 | 公式 |
| --- | --- | --- | --- |
| 1 | 1 | `sts2/src/Core/Rewards/GoldReward.cs:69-73 Populate()` | `Amount = rng.NextInt(_min, _max + 1)` |
| 2 | 1 | `sts2/src/Core/Odds/PotionRewardOdds.cs:56-71 Roll(player, ascensionManager, roomType)` | `currentValue = base.CurrentValue`；`num = roomType==Elite ? 0.25f : 0f`；`num3 = currentValue + num*0.5f`；`num4 = _rng.NextFloat()`；`num4 < num3` → `CurrentValue -= 0.1f` true，否则 `CurrentValue += 0.1f` false |
| 3-11 | 9（每张候选 3 次） | `sts2/src/Core/Factories/CardFactory.cs:89-109 CreateForReward(player, cardCount=3, options)` | 见下 |

每张候选 3 次抽取（`CardFactory.cs`）：

1. **稀有度** `RollForRarity`（`:244-261`）：`Source == CardCreationSource.Encounter` 且 `(uint)(rollMethod - 1) <= 2u`
   → `player.PlayerOdds.CardRarity.Roll(rollMethod)`（**会改变未来赔率**）；否则 `RollWithBaseOdds`。
   `sts2/src/Core/Odds/CardRarityOdds.cs:69-81 Roll(type)` → `RollWithoutChangingFutureOdds(type, CurrentValue)`（`:96-110`，1 次 `NextFloat()`）；
   随后 rare → `CurrentValue = -0.05f`；否则 `CurrentValue = Math.Min(CurrentValue + RarityGrowth, 0.4f)`。
   `RarityGrowth = 0.01f`（Ascension=0，`:31 GetValueIfAscension(Scarcity, 0.005f, 0.01f)`），初值 `-0.05f`（`:27 _baseRarityOffset`），上限 `0.4f`（`:29`）。
2. **具体牌** `rng.NextItem(items)`（`:236`），`items = options2.Where(c => c.Rarity == selectedRarity)`；
   `options2 = options.GetPossibleCards(player).Except(blacklist).ToList()`（`:214-241`），
   `blacklist` 累积**本次奖励已产出的 `CanonicalInstance`**（`:96 list.Add(cardModel.CanonicalInstance)`）⇒ 同一奖励集内不重复同一张牌。
3. **升级** `RollForUpgrade(player, cardModel, 0m, rng)`（`:98-102`）→ `:288-305`：
   `num = (decimal)rng.NextFloat()`；`card.IsUpgradable` 时 `originalOdds = baseChance(0m)`，
   `card.Rarity != Rare` 时 `originalOdds += (decimal)CurrentActIndex * UpgradedCardOddScaling`
   （`:23 UpgradedCardOddScaling => GetValueIfAscension(Scarcity, 0.125m, 0.25m)`，Ascension=0 取 `0.25m`）；
   `num <= originalOdds` → `CardCmd.Upgrade(card)`。
   **第 1 幕 `CurrentActIndex == 0` ⇒ `originalOdds == 0m` ⇒ `num <= 0` 恒假（`NextFloat()` ∈ [0,1)）⇒ 不升级，但仍消费 1 次抽数。**

金币数值：`sts2/src/Core/Models/EncounterModel.cs:64-81 MinGoldReward`（Monster→10、Elite→35、Boss→100、其它→0，
Poverty 进阶乘子 Ascension=0 不适用）、`:83-100 MaxGoldReward`（Monster→20、Elite→45、Boss→100）；
`GoldReward.cs:16-18 defaultMinGoldAmount=10 / defaultMaxGoldAmount=20`；`:52` 单值构造 `_min=_max`。
`CombatRoom.GoldProportion` 默认 `1f`（`sts2/src/Core/Rooms/CombatRoom.cs:51`），
`:235 GoldProportion = Encounter.CalculateGoldProportion(CombatState)`（`EncounterModel.cs:373` 默认全 1f；
仅 `sts2/src/Core/Models/Encounters/GremlinMercNormal.cs:58` 覆写）⇒ 本包遭遇的 `GoldProportion` 恒 `1f`。

金币领取：`sts2/src/Core/Commands/PlayerCmd.cs:141 GainGold(decimal amount, Player player, bool wasStolenBack=false)`
→ `amount = Hook.ModifyGoldGained(...)` → `AfterModifyingGoldGained` → `if (!(amount > 0m)) return;`
→ 历史 `wasStolenBack ? GoldStolen -= (int)amount : GoldGained += (int)amount` → `player.Gold += (int)amount` → `AfterGoldGained`。
`GoldReward.cs:75-80 OnSelect()` → `await PlayerCmd.GainGold(Amount, Player, _wasGoldStolenBack)` 返回 `true`。

卡牌领取：`sts2/src/Core/Rewards/CardReward.cs:270-287`，`await CardPileCmd.Add(obtainedCard, PileType.Deck)` 成功则
`obtainedCard = cardPileAddResult.cardAdded`、`chosenCardIds.Add(...)`、从 `_cards` 移除；
跳过（`:258-265`）→ `rewardComplete = false; endSelection = true`；历史写 `CardChoices.Add(new CardChoiceHistoryEntry(card, wasPicked:false))`（`:298-304`）。

---

## 3. 稀有度与牌池依据

赔率基表 `sts2/src/Core/Odds/CardRarityOdds.cs`（Ascension=0）：

| 类型 | Common | Uncommon | Rare |
| --- | --- | --- | --- |
| `RegularEncounter` (Monster) | 0.6f（`:13 regularCommonOdds = GetValueIfAscension(Scarcity, 0.615f, 0.6f)`） | 0.37f（`:15`） | 0.03f（`:33 RegularRareOdds = GetValueIfAscension(Scarcity, 0.0149f, 0.03f)`） |
| `EliteEncounter` | 0.5f（`:35`） | 0.4f（`:17 eliteUncommonOdds`） | 0.1f（`:37`） |
| `BossEncounter` | 0f | 0f | 1f（`:19-23`） |
| `Shop` | 0.54f（`:39`） | 0.37f（`:25`） | 0.09f（`:41`） |
| `Uniform` | 0.33f | 0.33f | 0.33f |

判定（`:96-110`）：`num < GetBaseOdds(type, Rare) + offset` → Rare；
`num < GetBaseOdds(type, Uncommon) + (GetBaseOdds(type, Rare) + offset)` → Uncommon；否则 Common。
`RollWithBaseOdds`（`:119-131`）不读/不写 offset。`GetBaseOdds`（`:133-174`）按 type 取上表。

牌池 `sts2/src/Core/Factories/CardFactory.cs:214-241`：`options.GetPossibleCards(player)`；
`sts2/src/Core/Runs/CardCreationOptions.cs:102-130 ForRoom(player, roomType)`：Monster/Elite/Boss →
`Source = CardCreationSource.Encounter`，pools = `[player.Character.CardPool]`（Ironclad 红池），
`RarityOdds = RegularEncounter / EliteEncounter / BossEncounter`；Shop → `Shop`；默认 `RegularEncounter`。
`Uniform` 分支才过滤 `Basic`/`Ancient`；`RegularEncounter` 分支**不按稀有度过滤**，缺该稀有度时
`GetNextAllowedRarity`（`:263-281`）按 `GetNextHighestRarityWithWrapping()` 上卷，回到起点返回 `None`（源抛 `InvalidOperationException`）。

**顺序保真关键**：`options2` 的枚举顺序 = 该卡池 `GetUnlockedCards` 的声明顺序（减 blacklist、减 `FilterForPlayerCount`）。
引擎 `SamplePick` 保留 query 顺序 ⇒ base 必须按源声明顺序投放候选。

base 侧卡牌源（`mod-the-spire/base-spire/BaseSpire/Slice/SpireCardSource.cs`）：正式源是嵌入资源
`BaseSpire.ContentSource.*-cards.spire`（`ResourcePrefix` / `ResourceSuffix`），`CardResources()` 用
`Order(StringComparer.Ordinal)` 排序；每张牌 `Variant(Type, Rarity, Cost, ...)` **带 `Rarity` 字符串**
（`common` / `uncommon` / `rare` 等）可支撑稀有度过滤；`upgradeable` 决定等价 `IsUpgradable`；
`ToId(name)` = CamelCase → kebab-case。

---

## 4. base 现状与必须的改动点

| 事实 | 位置 | 含义 |
| --- | --- | --- |
| 全仓**无** `UpgradeReward`；占位实现叫 `UpgradeLongTermCard` | `mod-the-spire/base-spire/BaseSpire/Slice/CombatSlicePackage.cs:4684-4737` | 派单中的「旧 `UpgradeReward` 占位」即此 |
| 占位奖励**只在 `hasRun && actMap is null` 注册** | `CombatSlicePackage.cs:4663-4738` | ⇒ DevMap 下没有任何奖励动作，`MapPhase=2` 直接开放 `ChooseMapPoint` |
| `EnterNextRoom`（同块） | `CombatSlicePackage.cs:4665-4678` | 守卫 `Run.SettledRoom == Run.CurrentRoom && CurrentRoom < roomLimit`；`roomLimit` = `Run.RoomCount`（`:4671-4673`）或常量 `SliceManifest.RunRoomCount` |
| `Run.RewardTaken Int(0,999)` | 声明 `CombatSlicePackage.cs:333`，初值 `:3756` | 幂等账本，可承接「每房只发一次奖励」 |
| `CommitPermanent` | `CombatSlicePackage.cs:437-446` | 唯一战斗→整局写回点，只写 `Run.Hp`/`Run.MaxHp`；注释明确 `Run.Gold`「目前没有战斗内来源，因此不在写回集合」 |
| `SettleBattle` | `CombatSlicePackage.cs:455-489` | `Run.SettledRoom != Run.CurrentRoom` → `CommitPermanent` + `SettledRoom = CurrentRoom` + 玩家 `BattleSettled = true`；`actMap != null` 时**重发 `Body`** 追加 `actMap.SettleStep(...)`（写 `MapPhase = 2`）——**奖励插入点** |
| 开局预铺战斗 | `CombatSlicePackage.cs:3884 setupSteps.Add(setup.Call(startNextRoom!.Symbol))` | **不区分 `actMap`**，开局即铺第一间房战斗，与 `MapPhase = 0` 并存 ⇒ 派单所述「开局 MapPhase0 同时暴露 PlayCard/EndTurn/ChooseMapPoint」 |
| `MapPhase` 与选点门控 | `mod-the-spire/base-spire/BaseSpire/Slice/MapRoomWiring.cs` | `Run.MapPhase Int(0,2)`；`ChooseMapPoint.Requires = And(Or(Equal(MapPhase,0), Equal(MapPhase,2)), Less(MapFloor, roomLimit))`；body 对 `Monster` 设 `CurrentNode/Visited/MapFloor=Row+1/MapPhase=1` 后 `Call(StartNextRoom)`；非 Monster 房型逐一 `Fail("base-spire: 房间类型 ... 尚未实现（地图节点保留、不伪装空事件）")` |
| 战斗结束尾 | `CombatSlicePackage.cs:1004-1012 BattleEndTail` | `If(!player.BattleSettled && Count(monsters)==0, VictoryTail(...))`，挂在 `PlayCard:4118`、`UsePotion:4647`、`EndTurn:4657`（ENV-T02 已验收，不重做） |
| 击杀不判胜利 | `CombatSlicePackage.cs:1014-1050 DamageMonster` | 只 `Emit(monsterDied)` + `RemoveFromCollection`，胜利判定在 `BattleEndTail` |
| 遭遇抽取 | `CombatSlicePackage.cs:3470-3500 SpawnEncounter`、`:3268-3279`、`:3600-3725`、`:3855-3873` | 遭遇按入队顺序/`Run.RoomCount` 槽位；开局由 `Run.Encounter` 与队列决定 |

---

## 5. 阶段机修正（本包设计，最小不改玩法）

`Run.MapPhase` 语义扩展为 `Int(0,3)`：

| 值 | 含义 | 允许的动作 |
| --- | --- | --- |
| 0 | 开局待选点（**尚未进入任何房间**） | `ChooseMapPoint` |
| 1 | 战斗进行中 | `PlayCard` / `UsePotion` / `EndTurn`（**无旅行**） |
| 2 | 奖励窗口（战斗已结算、奖励未结清） | 奖励动作（金币领取 / 选牌 / 跳过）（**无旅行、无出牌**） |
| 3 | 奖励已结清 | `ChooseMapPoint` |

改动：

1. `Mod-the-spire/base-spire/BaseSpire/Slice/MapRoomWiring.cs`：`Run.MapPhase` 上界 2 → 3；
   `ChooseMapPoint.Requires` 的相位集合由 `{0,2}` 改为 `{0,3}`（**不再允许 phase 2**）。
2. `mod-the-spire/base-spire/BaseSpire/Slice/CombatSlicePackage.cs:3884`：`actMap is not null` 时**不** `Call(startNextRoom)`；
   `actMap is null` 保持原样（T02/T04 回归路径逐字节不变）。
3. 奖励集结清（金币已领/无金币 + 卡牌已领或已跳过 + 药水已领或已拒）→ 写 `Run.MapPhase = 3` 与 `Run.RewardTaken = Run.CurrentRoom`。
4. 奖励动作守卫 `Requires = And(Equal(MapPhase, 2), NotEqual(Run.RewardTaken, Run.CurrentRoom))` ⇒ 幂等。
5. **不改** net 候选过滤、不改血/牌区/清场；相位门控在 base 的 action `Requires` 内完成。

---

## 6. 幂等与长期写回

- 幂等两处：动作级 `RewardTaken != CurrentRoom` 守卫；领取动作本身写成一次性状态转移
  （金币累加进 `Run.Gold`，卡牌按实例加入长期牌组）。重复提交同一奖励同一房间 → 被 `Requires` 拒绝。
- 金币：`CommitPermanent` 的注释必须同步更新；`Run.Gold` 由奖励路径直接写（整局字段），战斗内不改血。
- 永久牌来源：新牌必须作为 **`Run` 权威的长期牌组实例**加入 `LongTermDeck`，
  `cardLongTermSource` 指向该长期实例（与 `StartNextRoom` 的 `CopyCardFields` 反向一致，`CombatSlicePackage.cs:3080-3577`）。
- 跳过：不写牌、不改金币，仍推进相位到 3。

---

## 7. 药水容量（源依据）

- 容量 = 槽位数：`sts2/src/Core/Entities/Players/Player.cs:34 private readonly List<PotionModel?> _potionSlots`、
  `:42 public int MaxPotionCount => _potionSlots.Count`、`:120 PotionSlots`、`:122 Potions`、
  `:166 HasOpenPotionSlots => _potionSlots.Any(p => p == null)`、`:562 AddToMaxPotionCount(int)`、
  `:571 SubtractFromMaxPotionCount(int)`、`:581-613 SetMaxPotionCountInternal(int)`、`:624 AddPotionInternal(PotionModel potion, int slotIndex = -1, bool silent = false)`。
  容量初值由 `:261` 的 `SetMaxPotionCountInternal` 调用决定；遗物增量走 `PlayerCmd.GainMaxPotionCount`
  （`PotionBelt.cs:17 PotionSlots=2`、`PhialHolster.cs:22 =1`、`AlchemicalCoffer.cs:18 =4`）。
- 获取路径 `sts2/src/Core/Commands/PotionCmd.cs:28 TryToProcure(PotionModel potion, Player player, int slotIndex = -1)`：
  `Hook.ShouldProcurePotion(...)` 为假 → `PotionProcureResult { success = false, failureReason = NotAllowed }`，
  **不写历史**；满槽 → `TooFull`；成功 → `AddPotionInternal` + `PotionChoices.Add(new ModelChoiceHistoryEntry(potion.Id, wasPicked:true))` + `AfterPotionProcured`。
- 药水稀有度 `sts2/src/Core/Factories/PotionFactory.cs`：`_rareChance=0.1f`、`_uncommonChance=0.25f`、
  `_uncommonThreshold=0.35f`；`CreateRandomPotionOutOfCombat(player, rng, blacklist=null)`；
  `CreateRandomPotion` 一抽定 rarity（`rng.NextFloat()`）、一抽定具体（`rng.NextItem`）；
  `GetPotionOptions` = 角色药水池 ∪ `ModelDb.PotionPool<SharedPotionPool>()`，减 blacklist。
- base 侧药水栏实体/集合与 `author.Belt` 建在 `CombatSlicePackage.cs:3825-3845`（`hasPotions`）、
  药水 `Rarity` 字段 `:306`（`FieldTypeSchema.String(16)`）。
- 本包按源只实现「有空格 → 放入；无空格 → 拒绝领取（奖励保持未选，可跳过）」；
  **替换/丢弃路径不实现**，在交接与受限说明中标注。

---

## 8. 开放项与首差（诚实记账）

1. **`NextFloat` 无现成指令**——引擎只有 `SampleInt`（排他上界，vanilla profile 下与源 `NextInt(min,maxExclusive)` 逐位一致）
   与 `SamplePick`（= 源 `NextItem`，保留 query 顺序）；`core-the-spire/Core.TheSpire/Engine/RandomProfile.cs:66`
   `DrawDouble => (next() >> 11) * (1.0 / 9007199254740992.0)`。
   源 `Rng.NextFloat(min,max) => (float)(_random.NextDouble() * (double)(max-min) + (double)min)`
   （`sts2/src/Core/Random/Rng.cs:156-164`，乘法在 double、末尾一次转 float32）。
   ⇒ 需按 `mod-the-spire/base-spire/BaseSpire/Slice/SourceWeightedPick.cs` 先例
   （`Span = 1L << 53`、`Unit = 1.0 / 2^53`、`BackendId = "base-spire-source-float32@1"`）新增纯计算资产。
   **后端 id 进 `RuleSet.Identity` → `RulesetDigest` → `PublicBuildId`**，属公开身份变化，须在交接中声明。
2. **牌池顺序保真未验证**：源 `GetUnlockedCards` 声明顺序 vs base `CardResources()` 的 `Order(StringComparer.Ordinal)` 顺序。
   这是最可能的对拍首差，交给 B 对拍侧确认，不自行假设一致。
3. `EncounterPool/Queue` 投影 size/opaque 与 NotPublished 仍开放（派单要求保持开放，本包不隐藏/不公开未来遭遇）。
4. `rng-initial-shuffle`（源完整初始化）仍独立开放。
5. 精英/Boss/宝箱/商店奖励、`RelicReward`/`SpecialCardReward`/`CardRemovalReward`/`LinkedRewardSet`
   本包不实现（形状一致，`RewardsSet.cs:232-242` 为 Elite 分支）。
6. 药水替换/丢弃未实现；药水奖励成功领取后的历史账本（`ModelChoiceHistoryEntry`）在 base 侧是否落账待定。
7. Ascension 恒 0、Unlocks 恒 All ⇒ Poverty/Scarcity 分支不实现，但保留源依据以备后续。

---

## 9. 门开后实现步骤（串行一次构建）

1. 新增纯计算资产（`SourceFloat32Draw` 或等价）保真 `NextFloat()`，按 `SourceWeightedPick` 模板注册进同一 compute backend。
2. `Run` 增赔率状态：卡牌稀有度 offset（初值 `-0.05f`，上限 `0.4f`，growth `0.01f`）、药水奖励概率（初值 `0.4f`，步长 `±0.1f`）。
3. 阶段机（第 5 节）。
4. 奖励实体与动作：金币（抽数 + 领取）、卡牌（3 候选 × 稀有度/取牌/升级抽数 + 领取/跳过）、
   药水（roll + 容量判定 + 领取/拒绝）、跳过；`RewardTaken` 幂等。
5. 长期写回（第 6 节）。
6. 检查：`mod-the-spire/base-spire/BaseSpire.Slice.Tests` 新增受控判别检查（选牌 / 跳过 / 容量 / 幂等，必须标注为受控机制检查），
   与固定 seed `t05-map-alpha` / `t05-map-beta` 的正常闭环成功**分列**。
7. 串行一次：根 `dotnet build AutoTheSpire.sln` → `dotnet run --project core-the-spire/Core.TheSpire.Engine.Tests`
   → `dotnet run --project mod-the-spire/base-spire/BaseSpire.Slice.Tests`；保留全部 strict 分母。
8. 更新 `mod-the-spire/base-spire/BaseSpire/SinglePlayer/RunConfiguration.cs` 的 `NotImplementedReason(DevMap)` 文本与
   `BaseSpireRuntimeFactory.Describe` 的 limitations（`Replace` 前缀匹配，默认 scope 文本逐字节不变）。
