import json,pathlib
root=pathlib.Path(__file__).resolve().parents[2]
out=root/'.audit/dsh-card-families-2026-10-10'
rows=json.loads((out/'inventory-source.json').read_text(encoding='utf-8'))
families={
 'family01':'StrikeSilent DefendSilent Slice Deflect Backflip Dash DaggerSpray Adrenaline StrikeDefect DefendDefect',
 'family02':'StrikeNecrobinder DefendNecrobinder StrikeRegent DefendRegent Sow Parse Wisp Backstab BootSequence',
 'family03':'DramaticEntrance Finesse FlashOfSteel MasterOfStrategy Production Prophesize Fuel Luminesce',
 'family04':'Neutralize SuckerPunch BeamCell Assassinate Scare Defy Putrefy Shockwave',
 'family05':'Defile SweepingBeam Skim UltimateStrike UltimateDefend Bury SharedFate Soul',
}
implemented={n:f for f,names in families.items() for n in names.split()}
pools=['Ironclad','Silent','Defect','Necrobinder','Regent','Colorless','Status','Curse','Token','Event','Quest']
lines=['# ENV-T12 card family coverage matrix (2026-10-10)','',
'This matrix retains all source pool entries. A declaration does not prove loading or behavior. Prior-owner definitions are marked unverified here; family01–05 have controlled formal registration and normal/created-upgraded/real Armaments checks. Independent reference/client comparison remains unexecuted. Token/Event/Quest are separate derivative scope.','',
'| Pool | Source | Declarations | Undeclared | Multiplayer-only | Non-upgradeable | Combat-generation disabled |',
'|---|---:|---:|---:|---:|---:|---:|']
for pool in pools:
 rs=[r for r in rows if r['pool']==pool]
 declared=sum(bool(r['existing']) for r in rs)
 lines.append(f"| {pool} | {len(rs)} | {declared} | {len(rs)-declared} | {sum(r['multiplayer'] for r in rs)} | {sum(not r['upgradeable'] for r in rs)} | {sum(not r['canGenerate'] for r in rs)} |")
lines += ['', '## Complete source ledger', '',
'| Pool/Card | Declaration | Parse | Lower | Register | Normal | Upgrade | Independent | Family | Upgradeable / MP-only / Combat generation | Source |',
'|---|---|---|---|---|---|---|---|---|---|---|']
for r in rows:
 family=implemented.get(r['name'],'')
 verified=bool(family)
 ev='pass' if verified else 'unverified' if r['existing'] else 'unexecuted'
 declaration=f"[present](../../{r['existing'].replace(chr(92),'/')})" if r['existing'] else 'absent'
 source=r['source'].replace(chr(92),'/')
 lines.append(f"| {r['pool']}/{r['name']} | {declaration} | {ev} | {ev} | {ev} | {ev} | {'created + Armaments pass' if verified else ev} | unexecuted | {family or 'prior owner' if r['existing'] else 'remaining'} | {r['upgradeable']} / {r['multiplayer']} / {r['canGenerate']} | [source](../../{source}) |")
lines += ['', '## Delivered evidence', '',
'- family01: 10 cards / 30 cases. family02: 9 / 27. family03: 8 / 24. family04: 8 / 24. family05: 8 / 24. Total: 43 new cards / 129 cases.',
'- Each case uses normal, created-upgraded or real Armaments upgrade. Formal definitions and production engine execute a controlled deck; expected values are independently transcribed from frozen source. This is not two-sided executable comparison.',
'- family04 checks attack before Vulnerable (BeamCell/Assassinate), owner block with enemy selection (Defy), single/all enemy Weak/Vulnerable, and Scare upgrade removing Exhaust.',
'- Retain and Innate declarations are retained; dedicated turn-end/entry sequencing evidence is still pending. Parse Ethereal flag is observed; Defy and end-turn exhaust sequencing are pending.',
'- Fuel/Luminesce behavior is controlled only; their generation paths remain unverified. GiantRock is prior-owner content and is not counted as new delivery.', '',
'## Known dependencies and open review', '',
'- Dexterity is declared in enemy resources but absent from card-link PowerResources (*-powers.spire). Footwork/Prowess draft was removed after formal refusal. Shared loader/ownership needs review; do not declare a duplicate Power.',
'- Silent poison/Sly/history, Defect orbs/focus, Necrobinder Osty/souls, Regent Stars/Forge and remaining lifecycle cases require source-specific review. A broad category is not a proof that every card is blocked.',
'- Detailed minimum cases, ordering and interfaces belong in the fixed [handoff](../../docs/review/tofix/dsh-card-families-handoff-2026-10-10.md).',
'- All remaining rows are retained for continued ready-family review. No character full-run or independent consistency acceptance is claimed.']
(out/'coverage-matrix.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
print(f'wrote {len(rows)} source rows; {len(implemented)} checked new definitions')
