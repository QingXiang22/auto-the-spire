import re,json,pathlib
root=pathlib.Path(__file__).resolve().parents[2]
out=pathlib.Path(__file__).parent
pools=['Ironclad','Silent','Defect','Necrobinder','Regent','Colorless','Status','Curse','Token','Event','Quest']
existing={}
for p in (root/'mod-the-spire/base-spire/BaseSpire/ContentSource').glob('*.spire'):
 for m in re.finditer(r'\bcard\s+(\w+)\s*\{',p.read_text(encoding='utf-8')): existing[m[1]]=str(p.relative_to(root))
rows=[]; digest=[]
for pool in pools:
 p=root/f'sts2/src/Core/Models/CardPools/{pool}CardPool.cs'
 names=re.findall(r'ModelDb.Card<(\w+)>',p.read_text(encoding='utf-8'))
 for name in names:
  src=root/f'sts2/src/Core/Models/Cards/{name}.cs'; text=src.read_text(encoding='utf-8')
  rows.append(dict(pool=pool,name=name,source=str(src.relative_to(root)),existing=existing.get(name),multiplayer=bool(re.search(r'CardMultiplayerConstraint\.MultiplayerOnly',text)),upgradeable=not bool(re.search(r'public override int MaxUpgradeLevel => 0',text)),canGenerate=not bool(re.search(r'public override bool CanBeGeneratedInCombat => false',text)),code=text))
  digest.append(f'=== {pool}/{name} [{"existing" if name in existing else "remaining"}] ===\n'+ '\n'.join(f'{i}: {line}' for i,line in enumerate(text.splitlines(),1) if not any(x in line for x in ['using ','WithHitFx','WithAttackerAnim','Vfx','Sfx','Anim','NCombatRoom','Godot','await Task.Delay','Cmd.Wait']) and line.strip()))
(out/'inventory-source.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
(out/'source-digest.txt').write_text('\n\n'.join(digest),encoding='utf-8')
print(json.dumps({p:{'source':sum(r['pool']==p for r in rows),'existing':sum(r['pool']==p and bool(r['existing']) for r in rows)} for p in pools},indent=2))
