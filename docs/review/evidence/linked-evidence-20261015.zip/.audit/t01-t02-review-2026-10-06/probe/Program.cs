using BaseSpire.Slice;
using BaseSpire.Slice.Tests;
using BaseSpire.SinglePlayer;
using CoreTheSpire.Engine;

static int C(Session s, string name) => FormalSliceFixture.Collection(s, "base-spire:" + name);
static long RunHp(Session s) => FormalSliceFixture.Number(s, s.State.CollectionMembers(C(s, "RunStates")).Single(), "base-spire:Run", "Hp");
static void Kill(Session s, string enemy, string cardId)
{
    var target = FormalSliceFixture.Cultist(s, enemy);
    FormalSliceFixture.SetNumber(s, target, FormalSliceFixture.MonsterTypeId, "Hp", 1);
    FormalSliceFixture.PlayAt(s, FormalSliceFixture.MoveToHand(s, cardId), target);
}
static void ClearFirst(Session s)
{
    Kill(s, SliceManifest.CalcifiedCultistId, SliceManifest.StrikeId);
    Kill(s, SliceManifest.DampCultistId, "base-spire:feed");
    var next = s.LegalActions(SliceManifest.Player).Single(a => a.Definition.QualifiedId == "base-spire:EnterNextRoom");
    s.Submit(next.Definition, SliceManifest.Player, []);
}

// Unmodified formal card: final-room Feed must finish its result-area lifecycle.
{
    var s = FormalSliceFixture.NewFormal();
    ClearFirst(s);
    Kill(s, SliceManifest.CalcifiedCultistId, SliceManifest.StrikeId);
    var feed = FormalSliceFixture.MoveToHand(s, "base-spire:feed");
    var target = FormalSliceFixture.Cultist(s, SliceManifest.DampCultistId);
    FormalSliceFixture.SetNumber(s, target, FormalSliceFixture.MonsterTypeId, "Hp", 1);
    FormalSliceFixture.PlayAt(s, feed, target);
    Console.WriteLine($"formal-final-feed: status={s.Status} inPlay={s.State.CollectionMembers(C(s,"InPlay")).Contains(feed)} exhausted={s.State.CollectionMembers(C(s,"ExhaustPile")).Contains(feed)} runHp={RunHp(s)}");
}

// Controlled model probe, production IR: a declared after-card-played HP residual.
foreach (var lastRoom in new[] { false, true })
{
    var model = FormalSpirePackage.Load().Model;
    model = model with { Cards = model.Cards.Select(c => c.Id == "base-spire:feed"
        ? c with { NormalHooks = c.NormalHooks with { AfterCardPlayed = [new AuthorStep("heal:7", 1)] } }
        : c).ToArray() };
    var builder = new RuleSetBuilder();
    builder.Add(CombatSlicePackage.Build(authorModel: model).Build());
    var s = new Session(builder.Build(), 20261001UL, [SliceManifest.PlayerRole], computeBackend: SourceWeightedPickBackend.Instance);
    s.Start();
    if (lastRoom) ClearFirst(s);
    FormalSliceFixture.SetNumber(s, FormalSliceFixture.Player(s), FormalSliceFixture.PlayerTypeId, "Hp", 50);
    Kill(s, SliceManifest.CalcifiedCultistId, SliceManifest.StrikeId);
    Kill(s, SliceManifest.DampCultistId, "base-spire:feed");
    Console.WriteLine($"after-hook lastRoom={lastRoom}: status={s.Status} playerHp={FormalSliceFixture.Number(s,FormalSliceFixture.Player(s),FormalSliceFixture.PlayerTypeId,"Hp")} runHp={RunHp(s)} expected=60");
}

// Enumerate actual provenance vocabulary and unsupported fractional source content.
{
    var s = FormalSliceFixture.NewFormal();
    Console.WriteLine("cardFields=" + string.Join(",", s.RuleSet.TypeByQualifiedId(FormalSliceFixture.CardTypeId).Fields.Select(f => f.Name)));
    Console.WriteLine("relations=" + string.Join(",", s.RuleSet.Relations.Select(r => r.QualifiedId)));
}

{
    var factory = new BaseSpireRuntimeFactory(new RunConfiguration { Character = "Ironclad" });
    Console.WriteLine("dev=" + factory.Describe().Summary);
    foreach (var missing in SinglePlayerContentSource.Shared.Unsupported.Where(x => x.Item.Contains("two-tailed", StringComparison.OrdinalIgnoreCase) || x.Item.Contains("TwoTailed", StringComparison.OrdinalIgnoreCase)))
        Console.WriteLine("fractional-source-unsupported=" + missing.Item + ": " + missing.Reason);
}
