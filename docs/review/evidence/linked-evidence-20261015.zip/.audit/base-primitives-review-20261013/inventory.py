from pathlib import Path
import collections, hashlib, json, re

root = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent
uses = collections.defaultdict(list)
files = {}
for folder in ('Cards', 'Powers', 'Relics', 'Potions', 'Events', 'Monsters', 'Ancients', 'Enchantments', 'Afflictions'):
    for path in sorted((root / 'sts2/src/Core/Models' / folder).glob('*.cs')):
        raw = path.read_bytes()
        rel = path.relative_to(root).as_posix()
        files[rel] = hashlib.sha256(raw).hexdigest()
        for n, line in enumerate(raw.decode('utf-8-sig').splitlines(), 1):
            for match in re.finditer(r'\b((?:Card|CardPile|CardSelect|Creature|Damage|Player|Power|Relic|Potion|Orb|Osty|Forge|Rewards|Map)Cmd)\.([A-Za-z0-9_]+)', line):
                uses['.'.join(match.groups())].append({'path': rel, 'line': n, 'text': line.strip()})
base = {}
for path in sorted((root / 'mod-the-spire/base-spire/BaseSpire').rglob('*.cs')):
    if not any(x in path.parts for x in ('obj', 'bin')):
        base[path.relative_to(root).as_posix()] = hashlib.sha256(path.read_bytes()).hexdigest()
data = {'method': 'Lexical command-call navigation only; not reachability, behavior proof or complete primitive coverage.',
        'source_files': files, 'base_files': base, 'calls': dict(sorted(uses.items()))}
(out / 'inventory.json').write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
print(f'Source files: {len(files)}; base files: {len(base)}; command names: {len(uses)}')
for key, rows in sorted(uses.items()):
    examples = list(dict.fromkeys(Path(x['path']).stem for x in rows))
    print(f'{key}: {len(rows)} calls; {", ".join(examples[:5])}')
