# ENV-T03 公开整局运行器 — 本包证据索引（2026-10-11）

task_id `ENV-T03-public-run-driver-parallel-20261011`；session `session-7bab7f9a-2ad2-4389-a743-510f7bb77ca4`；
request `163fc1be-3b7c-4832-8f73-82b3914da8d2`（[task-record.json](task-record.json)）。

## 生产改动

| 文件 | 状态 |
| --- | --- |
| [net-the-spire/client/run_game.py](../../net-the-spire/client/run_game.py) | **新增**（唯一新增生产文件） |
| [net-the-spire/client/run_game.md](../../net-the-spire/client/run_game.md) | **新增**（用法与边界） |
| `net-the-spire/client/net_client.py` | 未改 |
| `net-the-spire/client/test_potion_host.py` / `README.md` | 未改 |
| Host / C# / 协议 / schema / base / core / tools / 参考 / AI / 主清单 | 未改 |

## Host 与身份

只读不可变 Host：[.artifacts/parallel/dsh-core-author-04/bin/Net.TheSpire.Host/debug/Net.TheSpire.Host.dll](../../.artifacts/parallel/dsh-core-author-04/bin/Net.TheSpire.Host/debug/Net.TheSpire.Host.dll)，
SHA256 `805C123D9941454E0B15E704CD48EB107A2E2A26DCC4555DDE8617513D0C1F6D`（每份 summary 的 `host.dll_sha256` 逐次一致）。
宿主自报（`summary.host_stderr` 首行）：`scenario=formal-dev protocol=0.2 scope=base-spire-singleplayer-dev-map-v1 scope_name=dev-map build=5f51e38e0e530897 ruleset=net:ruleset:bf54a1e5d279a86b projection=base-spire:PlayerView rng_profile=vanilla-uniform@1 default_game_seed=ENV-IRONCLAD-00 frame_limit=1048576`。

dev-map 身份（每份 summary 的 `identity`）：`backend_profile_id=net:backend:simulation-0.2-350911d86bad900d`、
`catalog_id=net:catalog:b400d7f332f590cc`、`ruleset_id=net:ruleset:bf54a1e5d279a86b`、`protocol_version=0.2`；
scenario profile `base-spire-singleplayer-dev-map-v1`。（与 [act1_smoke fixture](../../tools/base-spire-dev/fixtures/act1-basic-10.json) 的 expected_identity 一致；驱动器不固化该身份，每局按 `describe` 实测。）

统一命令（`--max-actions` 见各行）：

```powershell
python -X utf8 -u net-the-spire/client/run_game.py `
  --host-dll .artifacts/parallel/dsh-core-author-04/bin/Net.TheSpire.Host/debug/Net.TheSpire.Host.dll `
  --scope dev-map --seed <SEED> --output .audit/dsh-public-run-driver-2026-10-11/runs/<RUN> `
  --max-actions 700 --use-potions
```

## 运行清单（全部实跑，非入口检查）

| 运行目录 | seed | status | 退出码 | 步数 | 终局现场 | `frames.ndjson` | `steps.ndjson` |
| --- | --- | --- | ---: | ---: | --- | ---: | ---: |
| `runs/seed-K` | `ENV-T03-SEED-K` | `death` | 0 | **315** | Hp 0/80，floor 17，**`base-spire:vantom-boss`**（Boss 房） | 29423804 B | 1388642 B |
| `runs/seed-K-repeat` | `ENV-T03-SEED-K` | `death` | 0 | 315 | 同上（末观测 `12972`、gold 302、`Defeat.Turn=6`） | 29423804 B | 1388642 B |
| `runs/seed-E` | `ENV-T03-SEED-E` | `unsupported_map_room` | 4 | 240 | Hp 70/80，floor 13（只提供 `Unknown`） | 21320399 B | 1030864 B |
| `runs/seed-G` | `ENV-T03-SEED-G` | `death` | 0 | 182 | Hp 0/80，floor 8 | 15720388 B | 770826 B |
| `runs/act1-potions-A3` | `ACT1-BASIC-10` | `death` | 0 | 180 | Hp 0/80，floor 7 | 15527101 B | 753555 B |
| `runs/act1-full-A2` | `ACT1-BASIC-10` | `death` | 0 | 179 | Hp 0/80，floor 7 | 15548730 B | 773967 B |
| `runs/seed-J` | `ENV-T03-SEED-J` | `unsupported_map_room` | 4 | 175 | Hp 41/80，floor 10（只提供 `Elite`） | 15163433 B | 733744 B |
| `runs/act1-final-A4` | `ACT1-BASIC-10` | `death` | 0 | 167 | Hp 0/80，floor 7 | 14733115 B | 716795 B |
| `runs/act1-block-A5` | `ACT1-BASIC-10` | `death` | 0 | 163 | Hp 0/80，floor 7 | 14324983 B | 702298 B |
| `runs/seed-B` | `ENV-T03-SEED-B` | `death` | 0 | 138 | Hp 0/80，floor 6 | 10005725 B | 583072 B |
| `runs/seed-F` | `ENV-T03-SEED-F` | `unsupported_map_room` | 4 | 78 | Hp 68/80，floor 5（只提供 `Unknown`） | 6209430 B | 324697 B |
| `runs/seed-D` | `ENV-T03-SEED-D` | `unsupported_map_room` | 4 | 74 | Hp 75/80，floor 4（只提供 `Unknown`） | 6083858 B | 304717 B |
| `runs/act1-full-A` | `ACT1-BASIC-10` | `fault_host_rejected` | 4 | 51 | Hp 67/80，floor 3（商店房具名失败） | 4086914 B | 211241 B |
| `runs/seed-M` | `ENV-T03-SEED-M` | `unsupported_map_room` | 4 | 46 | Hp 69/80，floor 3（只提供 `Shop`） | 3620603 B | 195646 B |
| `runs/seed-L` | `ENV-T03-SEED-L` | `unsupported_map_room` | 4 | 17 | Hp 79/80，floor 2（只提供 `Shop`） | 1329658 B | 68874 B |
| `runs/seed-I` | `ENV-T03-SEED-I` | `unsupported_map_room` | 4 | 14 | Hp 80/80，floor 2（只提供 `Unknown`） | 1015688 B | 55284 B |
| `runs/smoke-6` | `ACT1-BASIC-10` | `step_limit` | 3 | 6 | Hp 80/80，floor 2（`--max-actions 6`） | 509918 B | 27103 B |

`runs/*.console.txt` 是 J/K/L/M 四次扫种的逐行控制台记录。每份 `summary.json` 的
`policy.combat` 记录了该次运行实际使用的战斗排序（开发期换过三次：
"最便宜牌优先"→"公开 Amount 大者优先"→短暂试过"低血先格挡"并已回退，实测不改变存活，
最终保留最简单的一条）。`rooms[]` 记录各房间长期状态（seed-K 44 条、seed-E 33 条）。

**可复现性**：同一 DLL、同一 seed、同一策略下 `runs/seed-K` 与 `runs/seed-K-repeat` 两次独立运行的
`steps.ndjson` **逐行相同**——315 个 `action`、315 个 `candidate_id`、315 个 `observation_id` 全部相等，
末态都是 `obs 12972` / floor 17 / gold 302 / `Defeat.Turn=6` / Hp 0（`frames.ndjson` 与 `steps.ndjson`
字节数也完全一致）。

## 四类验证要求 → 证据

| 要求 | 证据 |
| --- | --- |
| 给定原 seed 正常公开驱动 | `runs/act1-full-A2`（179 步死亡，exit 0）、`runs/act1-potions-A3`、`runs/smoke-6`（同一 seed 的 `step_limit` 分类） |
| 另一固定 seed 实际开局与步骤 | `runs/seed-K`（315 步到 Boss 房死亡）、`runs/seed-B`、`runs/seed-G`、`runs/seed-E` 等 11 个不同 seed |
| 更换合法 candidate 必须用当前观察 | 每一步都要求候选出现在**当前** `legal_actions`，并用当前 `observation_id` 作 `expected_observation_id`（[run_game.py:705-724](../../net-the-spire/client/run_game.py)）；负对照 `runs/smoke-6/stale-observation-probe.json`：过期 obs 1426 + 旧候选 → 宿主 `stale_observation` / `execution_state=not_started` / `retry_mode=query_request` |
| ActCompleted / 步数截止 / 故障不得写成整局通过 | `step_limit` = `runs/smoke-6`（exit 3，`run_complete=false`）；故障 = `runs/act1-full-A`（`backend_fault`，exit 4）；开发边界 = 11 个 `unsupported_map_room`（exit 4）；只有真的 `win/loss/other` 才 `run_complete=true`（`runs/seed-K`/`seed-B`/`seed-G`/`act1-full-A2` 均 `terminal_result.outcome=loss`） |

## 未覆盖

* **`ActCompleted`（`MapPhase==6`）在实跑中未到达**：固定策略要么在幕 1 末段战斗死亡，要么先撞上
  "只提供未接线房型"的地图节点。驱动器对该分支的分类（`act_completed_dev_boundary`，exit 3，
  `run_complete=false`）只有代码与协议层依据 + `--step-frontier` 通路，**如实记为未覆盖**。
  因此本包**没有**把第一幕过关当整局胜利的实跑对照。
* 未做多 seed 搜索通关、未训练、未估算隐藏状态；`Unknown`/`Shop`/`Elite` 房型、幕转换、部分宝箱
  遗物与药水效果属宿主未接线范围（见 [run_game.md](../../net-the-spire/client/run_game.md)）。
* 新初始化 DLL 上的整局复放由 Codex 在 A 最终构建后协调；本包证据只对上述不可变 Host 与身份成立。

## 开发过程记录

* 首版 `finally` 里先调 `client.stderr_text()`：`stderr.read()` 会阻塞到宿主退出，导致首次 3 步冒烟挂死
  且 `summary.json` 未落盘 → 改为 `close_session` → `shutdown` → 最后读 stderr。修复后的最小轨迹是
  `runs/smoke-6`。
* 早期 `runs/act1-full-A` 证明"把未接线房型真的推给宿主"会拿到宿主的具名失败（`backend_fault`）；
  现在默认改为**推之前**就停成 `unsupported_map_room`，`--step-unsupported-room` 才复现旧行为。
* `probe_describe.py` / `probe_start.json` / `probe_dump.py` 是最初的公开面侦察脚本与输出；
  `inspect_tail.py` 是只读的 steps 尾部打印脚本（均非生产代码）。
* `context-review-start.json` / `context-review-window.json` 是派单方提供的上下文快照，未修改。
