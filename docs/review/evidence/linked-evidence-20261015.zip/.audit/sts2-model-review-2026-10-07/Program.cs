using BaseSpire.SinglePlayer;
using BaseSpire.Slice;
using CoreTheSpire.Engine;

var factory = new BaseSpireRuntimeFactory(RunConfiguration.Ironclad());
Console.WriteLine($"Scope={factory.Configuration.ScopeId}; numericScale={factory.Rules.NumericProfile.FixedScale}");
Console.WriteLine("Model powers=" + string.Join(",", SinglePlayerContentSource.Shared.Model.Powers
    .Where(p => p.Id is "base-spire:shrink" or "base-spire:cruelty-power" or "base-spire:vulnerable")
    .Select(p => p.Id)));
var handle = factory.CreateSession("STS2-MODEL-AUDIT");
handle.Start();
var session = handle.Session;
var playerType = session.RuleSet.TypeByQualifiedId("base-spire:Player");
var monsterType = session.RuleSet.TypeByQualifiedId("base-spire:Monster");
var cardType = session.RuleSet.TypeByQualifiedId("base-spire:Card");
var powerType = session.RuleSet.TypeByQualifiedId("base-spire:Power");
int Collection(string name) => session.RuleSet.Collections.Single(c => c.QualifiedId == "base-spire:" + name).Id;
Value Read(InstanceId item, EntityTypeDefinition type, string field) => session.State.GetField(item, type.FieldIndex(field));
void Write(InstanceId item, EntityTypeDefinition type, string field, Value value) => session.State.SetField(item, type.FieldIndex(field), value);
var player = session.State.AllInstances(playerType.Id).Single();
var target = session.State.CollectionMembers(Collection("Monsters")).First();
var strike = session.State.CollectionMembers(Collection("LongTermDeck"))
    .First(c => Read(c, cardType, "DefinitionId").AsString() == SliceManifest.StrikeId);
// Diagnostic setup: use a combat copy, preserve its original base damage 6.
var copy = session.State.AllInstances(cardType.Id).First(c =>
    Read(c, cardType, "LongTermSource").Kind == ValueKind.Ref &&
    Read(c, cardType, "LongTermSource").AsRef() == strike);
foreach (var pile in new[] { "DrawPile", "DiscardPile", "ExhaustPile", "InPlay" })
    if (session.State.IsMember(Collection(pile), copy)) session.State.RemoveFromCollection(Collection(pile), copy);
if (!session.State.IsMember(Collection("Hand"), copy)) session.State.AddToCollection(Collection("Hand"), copy);
Write(player, playerType, "Energy", Value.Of(9L));
Write(target, monsterType, "Hp", Value.Of(50L));
Write(target, monsterType, "Block", Value.Of(0L));
var powerRelation = session.RuleSet.Relations.Single(r => r.QualifiedId == "base-spire:Powers").Id;
// Remove incidental powers so this isolates the three source-defined modifiers and Strength.
foreach (var owner in new[] { player, target })
    foreach (var power in session.State.RelationTargets(powerRelation, owner).ToArray()) session.State.DestroyInstance(power);
void AddPower(InstanceId owner, string id, long stacks)
{
    var power = session.State.CreateInstance(powerType.Id, session.State.ScopeOf(owner));
    Write(power, powerType, "DefinitionId", Value.Of(id));
    Write(power, powerType, "Stacks", Value.Of(stacks));
    session.State.AddRelation(powerRelation, owner, power);
}
AddPower(player, "base-spire:strength", -4);
AddPower(player, "base-spire:shrink", 1);
AddPower(player, "base-spire:cruelty-power", 64);
AddPower(target, "base-spire:vulnerable", 1);
var before = Read(target, monsterType, "Hp").AsInt();
var play = session.RuleSet.Actions.Single(a => a.QualifiedId == "base-spire:PlayCard");
session.Submit(play, handle.Participant, [Value.OfRef(copy)]);
var pending = session.PendingDecision ?? throw new Exception("Expected target decision.");
session.Answer(new DecisionAnswer(pending.RequestId, Instances: [target]));
var damage = before - Read(target, monsterType, "Hp").AsInt();
var sourceAmount = (6m - 4m) * 0.7m * (1.5m + 64m / 100m);
var expected = (long)sourceAmount;
Console.WriteLine($"Source decimal={sourceAmount}; expectedDamage={expected}; actualDamage={damage}; status={session.Status}");
if (damage != 3 || expected != 2) throw new Exception("Expected rounding counterexample did not reproduce.");
Console.WriteLine("Confirmed: the default per-operation quantization changes this supported damage combination.");
