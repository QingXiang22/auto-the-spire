# 原始证据：同一卡实例在同一回合二次打出被判 MembershipConflict

本文件记录 ENV-T06-native-attack-sequences-20261009 在构建"两次打出 Thunderclap 以证明先伤害后易伤"时
**真实撞到的引擎侧契约缺口**（原计划的判别手段因此改为"Thunderclap + 一张 8 点攻击打后排"）。

## 最小复现（受控会话，正式包）

```csharp
var session = FormalSliceFixture.NewFormal();
var front   = FormalSliceFixture.Cultist(session, SliceManifest.CalcifiedCultistId);
var card    = FormalSliceFixture.MoveToHand(session, "base-spire:thunderclap");
FormalSliceFixture.PlayAtCountingDecisions(session, card, front);   // 第一次：正常打出
card = FormalSliceFixture.MoveToHand(session, "base-spire:thunderclap"); // 从弃牌堆拿回手牌（受控前置）
FormalSliceFixture.PlayAtCountingDecisions(session, card, front);   // 第二次：本回合再把同一实例打出
```

第三次调用抛出的**原始异常文本**（`dotnet run --no-build --project mod-the-spire/base-spire/BaseSpire.Slice.Tests -- --combat-only`）：

```
Unhandled exception. BaseSpire.Slice.Tests.CheckFailedException: ENV-T06 攻击序列族：Thunderclap 两次打出证明「先伤害后易伤」且易伤对后续生效 [真实·受控初态]: unexpected EngineFaultException: MembershipConflict: #120 is already a member of 'base-spire:PlayedThisTurn'
```

（`#120` 是那次会话里 `base-spire:thunderclap` 实例的运行时 id，逐次会话会变。）

## 定位

- `mod-the-spire/base-spire/BaseSpire/Slice/CombatSlicePackage.cs:239` — `var playedThisTurn = package.Collection("PlayedThisTurn", card);`
  注释明说这是"本回合打出的牌"的**集合**，且故意不设 membership group（`CombatSlicePackage.cs:238`）。
- `mod-the-spire/base-spire/BaseSpire/Slice/CombatSlicePackage.cs:4441-4448` — 读侧 `played-count:<Kind>` 用
  `scope.Count(scope.Where(scope.Collection(playedThisTurn), ...))` 按 `playBody.Field(playedRef, cardUpgraded)` 之外的
  "本回合**已完成**的该类牌数量"计数。
- 打出路径会把当前实例加进这个集合（`playBody` 里；`CombatSlicePackage.cs:4442` 的注释也承认"正在打出的这一张此刻已在
  `PlayedThisTurn` 里"）。同一实例第二次加入同一集合 ⇒ 引擎报 `MembershipConflict`。

## 为什么是缺口（原版语义）

原版把"本回合打了几张"记在**历史事件**上，而不是"实例属于某个集合"：

- `sts2/src/Core/Models/Cards/Normality.cs:33` — `CardsPlayedThisTurn => CombatManager.Instance.History.CardPlaysStarted.Count((CardPlayStartedEntry e) => e.HappenedThisTurn(base.CombatState) && e.CardPlay.Card.Owner == base.Owner);`
- `sts2/src/Core/Models/Cards/Fetch.cs:30` — `HasBeenPlayedThisTurn => CombatManager.Instance.History.CardPlaysFinished.Any((CardPlayFinishedEntry e) => e.CardPlay.Card == this && e.HappenedThisTurn(base.CombatState));`

原版没有任何"同一实例一回合只能打出一次"的守卫。而原版**允许**同一张实体牌一回合打两次（例如 Headbutt 把弃牌堆的牌
放到抽牌堆顶，再用抽 1 张的牌抽回来继续打）。所以这是 base 侧 packing 用"集合成员资格"承载"本回合已出牌计数"造成的
表达力缺口，不是原版行为。

## 需要的能力（交 Codex，不在本包修复）

`PlayedThisTurn` 不能被当成"实例集合"来承载"本回合已完成的出牌计数"。可行方向（择一，需 Codex 定）：

1. 计数改为**事件/计数器**口径：每次 `PlayCard` 完成时给玩家/该实例累加一个计数字段，读侧按事件数而非集合基数；
2. 或把该集合改成**允许重复成员**的计数集合（proto 侧 `Combination`/`Count` 语义），读侧按出现次数计。

## 影响面与边界（本包结论）

- 本包**未**修改任何生产文件（`CombatSlicePackage.cs` 属禁止写入范围）。
- TwinStrike / Bash / Thunderclap 三张牌本身不需要这个能力；缺口是构建"同实例二次打出"判别手段时暴露的，
  属于 retrieval/replay 类卡（Headbutt/Hologram 等）的前置能力。
- **未验证边界**：没有用原版双侧对拍验证"同实例二次打出"的完整期望（原版对应的取回类卡在当前 base 里未必已支持），
  因此这里只登记"声明/集合口径 + 最小复现 + 需要的语义"，不下"原版会怎样结算"的结论。
