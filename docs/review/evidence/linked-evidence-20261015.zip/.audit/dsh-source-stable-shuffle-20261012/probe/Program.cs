using System.Text;

namespace StableShuffleProbe;

/// <summary>
/// ENV-T06-source-stable-shuffle-20261012 只读探针：
/// 1) 源 `List&lt;T&gt;.Sort()`（T 实现 IComparable&lt;T&gt;）在同级（同 key）大牌堆上是否等于稳定排序；
/// 2) 「对下标数组用同一个比较器排序」是否逐位复刻源的元素置换；
/// 3) 「按目标顺序逐个移到末尾」的 IR 可行实现能否复刻该置换（current index 公式）。
/// </summary>
internal static class Program
{
    private static int Main()
    {
        var log = new StringBuilder();
        void Line(string text)
        {
            Console.WriteLine(text);
            log.AppendLine(text);
        }

        // ---- 1) 起始牌组 10 张：strike×5, defend×4, bash×1 --------------------------------
        var starter = new List<Key>();
        for (var i = 0; i < 5; i++) starter.Add(new Key("STRIKE_IRONCLAD", 0, starter.Count));
        for (var i = 0; i < 4; i++) starter.Add(new Key("DEFEND_IRONCLAD", 0, starter.Count));
        starter.Add(new Key("BASH", 0, starter.Count));

        var starterSource = SourceOrder(starter);
        var starterIndex = IndexOrder(starter);
        var starterStable = StableOrder(starter);
        Line($"starter(10) source = [{string.Join(",", starterSource)}]");
        Line($"starter(10) index  = [{string.Join(",", starterIndex)}]");
        Line($"starter(10) stable = [{string.Join(",", starterStable)}]");
        Line($"starter index==source: {Same(starterIndex, starterSource)}; stable==source: {Same(starterStable, starterSource)}");
        Line("");

        // ---- 2) 随机化重复实例输入：稳定排序 vs 源 List.Sort --------------------------------
        var rng = new Random(20261012);
        string[] pool = ["STRIKE_IRONCLAD", "DEFEND_IRONCLAD", "BASH", "ANGER", "BLOODLETTING"];
        var stableMismatch = 0;
        var indexMismatch = 0;
        var mismatchSamples = new List<string>();
        for (var trial = 0; trial < 4000; trial++)
        {
            var count = 10 + rng.Next(0, 30);
            var input = new List<Key>(count);
            for (var i = 0; i < count; i++)
                input.Add(new Key(pool[rng.Next(pool.Length)], rng.Next(0, 2), i));

            var source = SourceOrder(input);
            var index = IndexOrder(input);
            if (!Same(source, index)) indexMismatch++;
            var stable = StableOrder(input);
            if (!Same(source, stable))
            {
                stableMismatch++;
                if (mismatchSamples.Count < 3)
                {
                    mismatchSamples.Add($"n={count} input=[{string.Join(",", input.Select(k => $"{Short(k.Entry)}/{k.Level}"))}] "
                        + $"source=[{string.Join(",", source)}] stable=[{string.Join(",", stable)}]");
                }
            }
        }

        Line($"4000 random duplicate-heavy inputs: index!=source {indexMismatch}; stable!=source {stableMismatch}");
        foreach (var sample in mismatchSamples) Line($"  sample: {sample}");
        Line("");

        // ---- 3) 最小可判别输入（>16 且含同 key 重复实例） ----------------------------------
        var minimal = FindMinimal();
        if (minimal is not null)
        {
            var (input, source, stable) = minimal.Value;
            Line($"minimal discriminating input (n={input.Count}):");
            Line($"  input  = [{string.Join(",", input.Select(k => $"{Short(k.Entry)}/{k.Level}"))}]");
            Line($"  source = [{string.Join(",", source)}]");
            Line($"  stable = [{string.Join(",", stable)}]");
        }

        // ---- 4) IR 可行实现：按目标顺序逐个移到末尾 ----------------------------------------
        var moveMismatch = 0;
        var rankMismatch = 0;
        for (var trial = 0; trial < 4000; trial++)
        {
            var count = 1 + rng.Next(0, 40);
            var input = new List<Key>(count);
            for (var i = 0; i < count; i++)
                input.Add(new Key(pool[rng.Next(pool.Length)], rng.Next(0, 2), i));
            var target = SourceOrder(input);
            if (!Same(RealizeByAppend(count, target), target)) moveMismatch++;
            if (!Same(RealizeByRank(count, target), target)) rankMismatch++;
        }

        Line($"append-to-end (IndexOf) realization mismatches over 4000 inputs: {moveMismatch}");
        Line($"rank-formula realization mismatches over 4000 inputs: {rankMismatch}");
        Line("");
        Line("PROBE RESULT: " + (indexMismatch == 0 && moveMismatch == 0 && rankMismatch == 0
            ? $"index-permutation faithful; stable differs in {stableMismatch}/4000 inputs"
            : "FAILED"));
        return 0;
    }

    private static string Short(string entry) => entry switch
    {
        "STRIKE_IRONCLAD" => "STRIKE",
        "DEFEND_IRONCLAD" => "DEFEND",
        _ => entry,
    };

    private static bool Same(int[] left, int[] right) => left.AsSpan().SequenceEqual(right);

    /// <summary>源 `list2.Sort()`：`List&lt;T&gt;.Sort()` + `Comparer&lt;T&gt;.Default`。</summary>
    private static int[] SourceOrder(List<Key> input)
    {
        var copy = input.ToList();
        copy.Sort();
        return [.. copy.Select(key => key.Seq)];
    }

    /// <summary>「拿同一个比较器排下标」：置换必须与源逐位一致。</summary>
    private static int[] IndexOrder(List<Key> input)
    {
        var order = Enumerable.Range(0, input.Count).ToList();
        order.Sort((left, right) => input[left].CompareTo(input[right]));
        return [.. order];
    }

    /// <summary>core `SortQuery` 的运行时语义：`OrderBy` 稳定排序。</summary>
    private static int[] StableOrder(List<Key> input) =>
        [.. Enumerable.Range(0, input.Count)
            .OrderBy(index => input[index], Comparer<Key>.Create((a, b) => a.CompareTo(b)))];

    /// <summary>IR 可行实现：按目标顺序，每一步把当前下标 r 的元素移到末尾。</summary>
    private static int[] RealizeByAppend(int count, int[] target)
    {
        var current = Enumerable.Range(0, count).ToList();
        var placed = new List<int>(count);
        for (var step = 0; step < count; step++)
        {
            var wanted = target[step];
            var index = current.IndexOf(wanted);
            current.RemoveAt(index);
            placed.Add(wanted);
        }

        return [.. placed];
    }

    /// <summary>IR 实际形态：helper 只给下标 r_k（不改集合），IR 用 First(Skip(collection, r_k)) 取元素再移到末尾。</summary>
    private static int[] RealizeByRank(int count, int[] target)
    {
        var current = Enumerable.Range(0, count).ToList();
        var placed = new List<int>(count);
        for (var step = 0; step < count; step++)
        {
            var wanted = target[step];
            var rank = 0;
            for (var remaining = step; remaining < count; remaining++)
            {
                if (target[remaining] < wanted) rank++;
            }

            if (current[rank] != wanted) return [];
            current.RemoveAt(rank);
            placed.Add(wanted);
        }

        return [.. placed];
    }

    /// <summary>穷举小输入，找第一个「源 != 稳定」且长度 &gt; 16 的判别输入。</summary>
    private static (List<Key> Input, int[] Source, int[] Stable)? FindMinimal()
    {
        // 三类 key、n=17 起步；用固定模式搜索。
        string[] entries = ["STRIKE_IRONCLAD", "DEFEND_IRONCLAD", "BASH"];
        for (var n = 17; n <= 22; n++)
        {
            var total = 1;
            for (var i = 0; i < n; i++) total *= entries.Length;
            for (var code = 0; code < total; code++)
            {
                var value = code;
                var input = new List<Key>(n);
                for (var i = 0; i < n; i++)
                {
                    input.Add(new Key(entries[value % entries.Length], 0, i));
                    value /= entries.Length;
                }

                var source = SourceOrder(input);
                var stable = StableOrder(input);
                if (!Same(source, stable)) return (input, source, stable);
            }
        }

        return null;
    }
}

internal sealed class Key(string entry, int level, int seq) : IComparable<Key>
{
    public string Entry { get; } = entry;
    public int Level { get; } = level;
    public int Seq { get; } = seq;

    public int CompareTo(Key? other)
    {
        if (ReferenceEquals(this, other)) return 0;
        if (other is null) return 1;
        var byEntry = string.CompareOrdinal(Entry, other.Entry);
        return byEntry != 0 ? byEntry : Level.CompareTo(other.Level);
    }
}
