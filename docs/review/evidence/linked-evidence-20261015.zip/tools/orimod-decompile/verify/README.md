# 还原保真度核对记录

这里保存 `reference/orimod/src` 的类型清单，用来核对“反编译源码重新编译后是否还包含原程序集的全部类型”。

**核对必须用 Release 配置。** 原始 mod 程序集是 Release 产物（优化消除了一部分闭包类和异步状态机），用 Debug 重编译会多出约 300 个编译器生成的类型，比对会出现大量假差异：

| 构建 | 类型数 |
| --- | --- |
| `reference/orimod/OriMod.dll`（原程序集，创意工坊 1.0.0） | **813** |
| 还原源码 `dotnet build -c Release` | **813** |
| 还原源码 `dotnet build -c Debug`（默认） | 1116 |

## 清单来源

先取工具（脚本会自动下载，路径见 `decompile.ps1`）：

```
$tool = tools/orimod-decompile/nuget/pkg/tools/net10.0/any/ilspycmd.dll
```

`orig-types.txt`——目标程序集本身：

```
dotnet $tool --disable-updatecheck -l c reference/orimod/OriMod.dll |
    Where-Object { $_ -like "Class*" } | Sort-Object |
    Set-Content tools/orimod-decompile/verify/orig-types.txt
```

`rebuilt-types-release.txt`——还原源码重编译产物：

```
dotnet build reference/orimod/src/OriMod.csproj -c Release
dotnet $tool --disable-updatecheck -l c reference/orimod/src/bin/Release/net9.0/OriMod.dll |
    Where-Object { $_ -like "Class*" } | Sort-Object |
    Set-Content tools/orimod-decompile/verify/rebuilt-types-release.txt
```

`bin/obj` 在核对后已清理；重新生成本清单需要先跑上面的 `dotnet build -c Release`。

## 结果

- 两份清单均为 **813** 个 `Class`。
- 对称差集 **52** 项，全部是编译器生成的内部名字：
  - `<>c__DisplayClassN_M` / `d__N` / `b__N` 的编号偏移（方法序号不同导致）；
  - `<>z__ReadOnlyArray` 等类型在 `.cs` 里写成 `_003C_003Ez__ReadOnlyArray`，是同一个名字的两种转义写法。
- 过滤掉编译器生成名字后，**没有**只在原程序集出现或只在重编译产物出现的类型。
