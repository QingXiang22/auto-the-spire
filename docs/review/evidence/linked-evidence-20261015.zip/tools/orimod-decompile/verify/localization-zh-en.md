﻿# OriMod 本地化对照表（zhs / eng）

> 由 tools/orimod-decompile/loc_report.py 从 OriMod.pck 的 localization 表生成。


## cards

| key | 中文 | english |
| --- | --- | --- |
| ORI-ABLUTION | 涤荡 | Ablution |
| ORI-ABSORBED | 瞄准 | Aim |
| ORI-ADJUDICATION | 裁决 | Adjudication |
| ORI-AETHERIS | 天宗 | Aetheris |
| ORI-AFTERIMAGE | 掠影 | Afterimage |
| ORI-ANCIENT_FORCE | 先古之力 | Ancient Force |
| ORI-ANTIGRAVITY | 反重力 | Antigravity |
| ORI-ASTERISM | 星芒 | Asterism |
| ORI-BINDING | 折跃者 | Binding |
| ORI-BIZARRE_ADVENTURE | 奇妙冒险 | Bizarre Adventure |
| ORI-BRILLIANCE | 光辉 | Brilliance |
| ORI-BURST | 迸发 | Burst |
| ORI-CARD_WHEEL | 轮盘 | Wheel |
| ORI-CHARGE_JUMP | 充能跳跃 | Charge Jump |
| ORI-CLAMBER | 攀爬 | Clamber |
| ORI-COLLECTION_ENERGY | 能量矿石 | Energy Ore |
| ORI-CONGEALING_SOUL | 凝魂 | Gather Souls |
| ORI-DEFEND_ORI | 防御 | Defend |
| ORI-DEFLECTION | 偏折 | Deflection |
| ORI-DEPARTURE | 远行 | Departure |
| ORI-DIGNIFIED | 厚重 | Dignified |
| ORI-DIVE | 俯冲 | Dive |
| ORI-ELF_FORM | 精灵形态 | Spirit Form |
| ORI-EMBRACE_THE_LIGHT | 拥抱光明 | Embrace the Light |
| ORI-ENERGY_CELL | 能量核心 | Energy Cell |
| ORI-ESCAPE | 逃脱 | Escape |
| ORI-EUREKA_MOMENT | 灵光一现 | Eureka Moment |
| ORI-EYE_OF_THE_STORM | 风暴之眼 | Eye of the Storm |
| ORI-FAREWELL | 离别 | Farewell |
| ORI-FEATHERS | 天羽 | Feathers |
| ORI-FELL_THE_STARS | 斩落群星 | Fell the Stars |
| ORI-FIELD_CAMPFIRE | 场地：火焰 | Field: Campfire |
| ORI-FIELD_DARKNESS | 场地：黑暗 | Field: Darkness |
| ORI-FIELD_DESERT | 场地：沙漠 | Field: Desert |
| ORI-FIELD_FOREST | 场地：森林 | Field: Forest |
| ORI-FIELD_OCEAN | 场地：海洋 | Field: Ocean |
| ORI-FIELD_SNOWSLIDE | 场地：雪山之巅 | Field: Snowslide |
| ORI-FIELD_VOID | 场地：虚空 | Field: Vacuo |
| ORI-FIELD_WELLSPRING | 场地：泉源 | Field: Wellspring |
| ORI-FLICKER_FLICKER | 闪烁 | Flicker |
| ORI-FLUORESCENCE | 荧光 | Fluorescence |
| ORI-FOREST_EYES | 森林之眼 | Forest Eyes |
| ORI-FOREST_HEART | 森林之心 | Forest Heart |
| ORI-FOREST_MEMORY | 森林记忆 | Forest Memory |
| ORI-FOREST_STRENGTH | 森林之力 | Forest Strength |
| ORI-FOREST_VOICE | 森林之声 | Forest Voice |
| ORI-FROZEN | 冰封 | Frozen |
| ORI-GLIMMERING | 流光 | Glimmering |
| ORI-GRAPPLE | 抓钩 | Grapple |
| ORI-HAND_TO_HAND | 手手相传 | Hand to Hand |
| ORI-HOPPING_IS_CUTE | 蹦蹦跳跳显得可爱 | Hopping Is Cute |
| ORI-IMMERSE | 浸染 | Immerse |
| ORI-INTANGIBLE | 空灵 | Hyaline |
| ORI-INTERTWINE | 交织 | Intertwine |
| ORI-IRRESISTIBLE | 势如破竹 | Irresistible |
| ORI-KING_FROM_ABOVE | 王从天降 | King from Above |
| ORI-LAST_LIGHT | 于光明中行 | Last Light |
| ORI-LIFEPACT | 生命契约 | Life Pact |
| ORI-LIFE_CELL | 生命核心 | Life Cell |
| ORI-LIGHTNESS | 轻盈 | Lightness |
| ORI-LIGHT_CATCHER | 捕光草 | Light Catcher |
| ORI-LIGHT_HAMMER_ABILITY_CARD | 光锤 | Light Hammer |
| ORI-LIGHT_SPEAR_ABILITY_CARD | 光矛 | Light Spear |
| ORI-LOOKOUTS_BLESSING | 瞭望员的祝福 | Lookout's Blessing |
| ORI-MAGIC_BOW | 魔法弓 | Magic Bow |
| ORI-MARK_POINT | {TargetTitle} | {TargetTitle} |
| ORI-MASSING | 聚能 | Massing |
| ORI-MASTER_OF_ARMS | 诸武精通 | Master of Arms |
| ORI-METEORITE | 天坠 | Meteorite |
| ORI-METEORITE_POINT | {PlacementName} | {PlacementName} |
| ORI-MIDAIR | 凌空 | Midair |
| ORI-MIGHTY_ORI_DESCENDS | 猛奥下山 | Mighty Ori Descends |
| ORI-MIRAGE | 海市蜃楼 | Mirage |
| ORI-MOON_CUT | 断月 | Moon Cut |
| ORI-MYRIABLADE | 万剑 | Myria Blade |
| ORI-NIGHT_PROWL | 夜行 | Night Prowl |
| ORI-PLATFORM | 平台 | Platform |
| ORI-PURE_HEART | 纯净之心 | Pure Heart |
| ORI-PURSUE | 穷追猛打 | Pursue |
| ORI-QUICK_FILLING | 快速填充 | Quick Loading |
| ORI-REBIRTH | 重生 | Rebirth |
| ORI-REFLECTION | 空明 | Reflection |
| ORI-REFLUX | 逆流 | Recall |
| ORI-REGENERATE | 恢复 | Regenerate |
| ORI-RENZOKUKEN | 连斩 | Renzokuken |
| ORI-ROAMING | 漫游 | Roaming |
| ORI-ROUNDHOUSE_KICK | 回旋踢 | Roundhouse Kick |
| ORI-SENTRY_MARK | 哨位 | Sentry |
| ORI-SERAPH | 天倾 | Seraph |
| ORI-SEVEN_SWORDS_UNITE | 七剑合璧 | Seven Swords Unite |
| ORI-SHADOW_CLOAK | 暗影斗篷 | Shadow Cloak |
| ORI-SHADOW_CRAFT | 迅影 | Shadow |
| ORI-SHARD_OVERCHARGE | 超载 | Overcharge |
| ORI-SHARD_RESILIENCE | 坚韧 | Resilience |
| ORI-SINKING | 沉沦 | Sinking |
| ORI-SKYROCKET | 流星 | Skyrocket |
| ORI-SMALL_HOUSE | 小房子 | Small House |
| ORI-SPARK | 火种 | Spark |
| ORI-SPIRIT_ARC_ABILITY_CARD | 精灵弧击 | Spirit Arc |
| ORI-SPIRIT_DREAM | 精灵之梦 | Spirit Dream |
| ORI-SPIRIT_EDGE_ABILITY_CARD | 精灵之刃 | Spirit Edge |
| ORI-SPIRIT_LINK | 灵魂链接 | Spirit Link |
| ORI-SPIRIT_WELL | 精灵之井 | Spirit Well |
| ORI-SPRING_PLANTS | 弹簧草 | Spring Plants |
| ORI-STASIS | 凝滞 | Stasis |
| ORI-STORM | 风暴 | Storm |
| ORI-STOVE | 火炉 | Stove |
| ORI-STRIKE_ORI | 打击 | Strike |
| ORI-SUNSET_DANCE | 落日祭 | Sunset Dance |
| ORI-SUN_CROSS | 贯日 | Sun Cross |
| ORI-SUN_MOON_ISLE | 场地：日月岛 | Field: Sun-Moon Isle |
| ORI-SUN_MOON_RADIANCE | 日月同辉 | Sun-Moon Radiance |
| ORI-SUPER_BASH | 超级猛击 | Super Bash |
| ORI-SWITCH_PLACES | 移形 | Switch Places |
| ORI-SWORD_DANCE | 剑舞 | Sword Dance |
| ORI-SWORD_WAVE | 剑浪 | Sword Wave |
| ORI-TEMPERAMENT | 调律 | Temperament |
| ORI-TEMPERING | 淬炼 | Tempering |
| ORI-TORRENT | 洪流 | Torrent |
| ORI-TOWARD_THE_NIGHT | 向夜 | Facing the Night |
| ORI-TREAD | 践踏 | Tread |
| ORI-VIGIL | 守望 | Vigil |
| ORI-WIND_SPIRIT | 风灵 | Wind Spirit |
| ORI-WISPS_WILL | 萤火的意志 | Will of the Wisps |
| ORI-WISP_EVERLASTING | 萤火长明 | Everlasting Wisp |
| ORI-WISP_FLIGHT | 化萤 | Wisp Flight |
| ORI-WORLD_UNFURLED | 山河为卷 | The World Unfurled |

## powers

| key | 中文 | english |
| --- | --- | --- |
| ORI-AFTERIMAGE_POWER | 掠影 | Afterimage |
| ORI-AIM_POWER | 瞄准 | Aim |
| ORI-AIM_RETAIN_POWER | 瞄准保留 | Aim Retain |
| ORI-ALOFT_MOMENTUM_POWER | 惯性 | Momentum |
| ORI-ALOFT_POWER | 高度 | Height |
| ORI-ANTIGRAVITY_POWER | 反重力 | Antigravity |
| ORI-ASTERISM_POWER | 星芒 | Asterism |
| ORI-BINDING_POWER | 绑定 | Binding |
| ORI-CARD_WHEEL_POWER | 轮盘 | Wheel |
| ORI-CLAMBER_POWER | 攀爬 | Clamber |
| ORI-DIGNIFIED_POWER | 厚重 | Dignified |
| ORI-ELF_FORM_POWER | 精灵形态 | Spirit Form |
| ORI-ENEMY_ALOFT_HOVER | 敌人高度 | Enemy Height |
| ORI-FLUORESCENCE_POWER | 荧光 | Fluorescence |
| ORI-FOREST_STRENGTH_POWER | 森林之力 | Forest Strength |
| ORI-FOREST_VOICE_POWER | 森林之声 | Forest Voice |
| ORI-GLIMMERING_POWER | 流光 | Glimmering |
| ORI-MIDAIR_POWER | 凌空 | Midair |
| ORI-MYRIABLADE_POWER | 万剑 | Myria Blade |
| ORI-OVERCHARGE_POWER | 超载 | Overcharge |
| ORI-PANEL_ENEMY_RANGES | 敌方攻击范围 | Enemy Attack Ranges |
| ORI-PROBE_PANEL | 放置物 显示{Bottom}-{Top} | Placements. Display {Bottom}-{Top} |
| ORI-PURSUE_POWER | 穷追猛打 | Pursue |
| ORI-QUICK_FILLING_POWER | 快速填充 | Quick Loading |
| ORI-REFLECTION_POWER | 空明 | Reflection |
| ORI-RENZOKUKEN_POWER | 连斩 | Renzokuken |
| ORI-RESILIENCE_POWER | 坚韧 | Resilience |
| ORI-SERAPH_POWER | 天倾 | Seraph |
| ORI-SHADOW_CRAFT_POWER | 迅影 | Shadow |
| ORI-SINKING_POWER | 沉沦 | Sinking |
| ORI-SWORD_DANCE_POWER | 剑舞 | Sword Dance |
| ORI-TEMP_LIFE_POWER | 临时生命 | Temporary HP |
| ORI-TEMP_STRENGTH_POWER | 临时力量 | Temp Strength |
| ORI-WISPS_WILL_POWER | 萤火的意志 | Will of the Wisps |

## relics

| key | 中文 | english |
| --- | --- | --- |
| ORI-ANCIENT_TABLET | 古老的石板 | Ancient Tablet |
| ORI-BASH_ABILITY_DISPLAY_RELIC | 猛击 | Bash |
| ORI-BURNING_FEATHER | 燃烧之羽 | Burning Feather |
| ORI-COMPASS | 指南针 | Compass |
| ORI-DASH_ABILITY_DISPLAY_RELIC | 冲刺 | Dash |
| ORI-GORLEK_ORE | 格勒克矿石 | Gorlek Ore |
| ORI-HOWL_FANG | 豪尔的尖牙 | Howl's Fang |
| ORI-JUMP_ABILITY_DISPLAY_RELIC | 跳跃 | Jump |
| ORI-KEY_STONE | 楔石 | Key Stone |
| ORI-KUROS_FEATHER | 黑子之羽 | Kuro's Feather |
| ORI-KWOLOKS_AMULET | 夸洛克的护身符 | Kwolok's Amulet |
| ORI-LAGOON_AQUA | 光之池池水 | Lagoon Aqua |
| ORI-LAUNCH_ABILITY_DISPLAY_RELIC | 炮弹跳 | Launch |
| ORI-LIGHT_HAMMER_ABILITY_DISPLAY_RELIC | 光锤 [近战武器] | Light Hammer [Melee Weapon] |
| ORI-LIGHT_SPEAR_ABILITY_DISPLAY_RELIC | 光矛 [远程武器] | Light Spear [Ranged Weapon] |
| ORI-PETRIFIED_BRANCH | 石化树枝 | Petrified Branch |
| ORI-PETRIFIED_DOLL | 石化玩偶 | Petrified Doll |
| ORI-SEIN | 赛安 | Sein |
| ORI-SHARD_ANTIAIR | 精灵碎片-剪羽 | Spirit Shard - Antiair |
| ORI-SHARD_CATALYST | 精灵碎片-催化 | Spirit Shard - Catalyst |
| ORI-SHARD_QUICK_SHOT | 精灵碎片-高速射击 | Spirit Shard - Quick Shot |
| ORI-SHARD_SCATTERING | 精灵碎片-散射 | Spirit Shard - Scattering |
| ORI-SPIRIT_ARC_ABILITY_DISPLAY_RELIC | 精灵弧击 [远程武器] | Spirit Arc [Ranged Weapon] |
| ORI-SPIRIT_EDGE_ABILITY_DISPLAY_RELIC | 精灵之刃 [近战武器] | Spirit Edge [Melee Weapon] |
| ORI-SPIRIT_LIGHT | 精灵之光 | Spirit Light |
| ORI-TORCH | 火把 | Torch |
| ORI-WILLOWS_END | 灵树之梢 | Willow's End |

## card_keywords

| key | 中文 | english |
| --- | --- | --- |
| ORI-ALOFT | 高度 | Height |
| ORI-BASH | 猛击 | Bash |
| ORI-CONCEPT_CARD | 概念卡 | Concept Card |
| ORI-DOWN_ATTACK | 向下攻击 | Downward Attack |
| ORI-FIELD_CAMPFIRE | 火焰 | Campfire |
| ORI-FIELD_DARKNESS | 黑暗 | Darkness |
| ORI-FIELD_DESERT | 沙漠 | Desert |
| ORI-FIELD_FOREST | 森林 | Forest |
| ORI-FIELD_OCEAN | 海洋 | Ocean |
| ORI-FIELD_SNOWSLIDE | 雪崩 | Snowslide |
| ORI-FIELD_VOID | 虚空 | Vacuo |
| ORI-FIELD_WELLSPRING | 泉源 | Wellspring |
| ORI-JUDGMENT | 审判 | Judgment |
| ORI-LAST_LIGHT | 于光明中行 | Last Light |
| ORI-MELEE_ATTACK | 近战攻击 | Melee Attack |
| ORI-MELEE_WEAPON_ONLY | 近战武器限定 | Melee Weapon Only |
| ORI-MOMENTUM | 惯性 | Momentum |
| ORI-RANGED_ATTACK | 远程攻击 | Ranged Attack |
| ORI-RANGED_WEAPON_ONLY | 远程武器限定 | Ranged Weapon Only |
| ORI-RESET | 重置 | Reset |
| ORI-RETURN | 返还 | Refund |
| ORI-SPIRIT_ARC_ONLY | 精灵弧击限定 | Spirit Arc Only |
| ORI-SPIRIT_EDGE_ONLY | 精灵之刃限定 | Spirit Edge Only |
| ORI-SUBSTANTIAL_FIELD | 实体场地 | Substantial Field |
| ORI-TEMPERAMENT | 调律 | TEMPERAMENT |
| ORI-UP_ATTACK | 向上攻击 | Upward Attack |
| ORI-WEAPON_SWITCH | 切换武器 | Switch Weapon |

## characters

| key | 中文 | english |
| --- | --- | --- |
| ORI-ORI_CHARACTER | 奥里 | Ori |

## events

| key | 中文 | english |
| --- | --- | --- |
| TEMPERAMENT_EVENT | 武器大师 | Weapon Master |
| TEMPERAMENT_EVENT.pages.ALL.options.CONTINUE | 继续 | Continue |
| TEMPERAMENT_EVENT.pages.ALL.options.LEAVE | 离开 | Leave |
| TEMPERAMENT_EVENT.pages.SELECT.options.LIGHT_HAMMER | 光锤 [近战武器] | Light Hammer [Melee Weapon] |
| TEMPERAMENT_EVENT.pages.SELECT.options.LIGHT_HAMMER_LEARNED | 光锤 [近战武器] | Light Hammer [Melee Weapon] |
| TEMPERAMENT_EVENT.pages.SELECT.options.LIGHT_HAMMER_NON_ORI | 光锤 [近战武器] | Light Hammer [Melee Weapon] |
| TEMPERAMENT_EVENT.pages.SELECT.options.LIGHT_SPEAR | 光矛 [远程武器] | Light Spear [Ranged Weapon] |
| TEMPERAMENT_EVENT.pages.SELECT.options.LIGHT_SPEAR_LEARNED | 光矛 [远程武器] | Light Spear [Ranged Weapon] |
| TEMPERAMENT_EVENT.pages.SELECT.options.LIGHT_SPEAR_NON_ORI | 光矛 [远程武器] | Light Spear [Ranged Weapon] |
| TEMPERAMENT_EVENT.pages.SELECT.options.TEMPERAMENT | 学习调律 | Learn Temperament |
| TEMPERAMENT_EVENT.pages.SELECT.options.TEMPERAMENT_LOCKED | 学习调律 | Learn Temperament |
| TEMPERAMENT_EVENT.pages.SELECT.options.TREAD | 学习技巧 | Learn a Skill |

## placements

| key | 中文 | english |
| --- | --- | --- |
| ORI-ANCIENT_LIGHT_PLACEMENT | 远古圣光 | Ancient Light |
| ORI-CAMPFIRE_PLACEMENT | 火焰[{Height}] | Campfire[{Height}] |
| ORI-COLLECTION_ENERGY_PLACEMENT | 能量矿石[{Height}] | Energy Ore[{Height}] |
| ORI-COLLECTION_LIFE_PLACEMENT | 生命果实[{Height}] | Life Fruit[{Height}] |
| ORI-DARKNESS_PLACEMENT | 黑暗 | Darkness |
| ORI-DESERT_PLACEMENT | 沙漠 | Desert |
| ORI-DREAM_PLACEMENT | 梦境 | Dream |
| ORI-EYE_OF_THE_STORM_PLACEMENT | 风暴之眼[{Height}] | Eye of the Storm[{Height}] |
| ORI-FOREST_HEART_PLACEMENT | 森林之心 | Forest Heart |
| ORI-FOREST_PLACEMENT | 森林 | Forest |
| ORI-LIGHT_CATCHER_PLACEMENT | 捕光草[{Height}] | Light Catcher[{Height}] |
| ORI-OCEAN_PLACEMENT | 海洋 | Ocean |
| ORI-PLATFORM_PLACEMENT | 平台[{Height}] | Platform[{Height}] |
| ORI-SENTRY_PLACEMENT | 哨位[{Height}] | Sentry[{Height}] |
| ORI-SHWD_PLACEMENT | 捕光草[{Height}] | Light Catcher[{Height}] |
| ORI-SMALL_HOUSE_PLACEMENT | 小房子[{Height}] | Small House[{Height}] |
| ORI-SNOWSLIDE_PLACEMENT | 雪崩 | Snowslide |
| ORI-SPIRIT_LINK_PLACEMENT | 灵魂链接[{Height}] | Spirit Link[{Height}] |
| ORI-SPIRIT_WELL_PLACEMENT | 精灵之井[{Height}] | Spirit Well[{Height}] |
| ORI-SPRING_PLANTS_PLACEMENT | 弹簧草[{Height}] | Spring Plants[{Height}] |
| ORI-STOVE_PLACEMENT | 火炉[{Height}] | Stove[{Height}] |
| ORI-VOID_PLACEMENT | 虚空 | Vacuo |
| ORI-WELLSPRING_PLACEMENT | 泉源 | Wellspring |

## enchantments

| key | 中文 | english |
| --- | --- | --- |
| ORI-REINCARNATOR | 轮回者 | Reincarnator |

## ancients

| key | 中文 | english |
| --- | --- | --- |

## ori_tutorials

| key | 中文 | english |
| --- | --- | --- |
| COMBAT_BASICS.ABILITIES | 主动技能 | Active Abilities |
| COMBAT_BASICS.HEIGHT | 高度 | Height |
| COMBAT_BASICS.PLACEMENTS | 放置物 | Placements |
| WEAPON_SWITCH | 切换武器 | Switching Weapons |
