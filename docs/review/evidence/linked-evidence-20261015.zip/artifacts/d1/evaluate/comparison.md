# D1 三策略对照（同一保留 seed）

- run：`F:\Scylier-Project\active\auto-the-spire\artifacts\d1\train`　split：**final**　种子：30000..30007（8 个）
- Gym：`net:gym:base-spire-combat-slice-v1`　场景：`base-spire-combat-slice-v1`　执行器：`net:executor:canonical-cdf-uniform-rng@1`
- 奖励 Profile：`net:reward:d1-three-component-v1`（`sha256:b2c41ee25ac8c4bbb67857fcd1e54d9f83d7cf556619db4b011336341aa0a2c3`）
- 计划摘要：`sha256:72c758d3e797bc8b99f09d36243cf321fe3f8d650047fa2da91ce0a614cd3e44`　报告摘要：`sha256:f966b22b2bb66659a9b059d705d909df8597ac02bde88eb875edd4c12dc1e8f9`
- 初始模型：`small-embedding-scorer@1:c0107fae682e:50eb6abea1a1`（权重 `sha256:50eb6abea1a1af7fb97a8265a54eaf1adb4e6de203ba63b71ab360bc54793541`）
- 训练候选：`small-embedding-scorer@1:c0107fae682e:210728c580e9`（权重 `sha256:210728c580e9f49a383e824f996eef802bffe3ad8cae6256784032f6240a86a7`）
- 总墙钟：14.382s

## 逐策略汇总

| 策略 | 状态 | 局数 | 可用 | 完成/截断/故障 | 平均未折扣回报 | 样本标准差 | 95% 自助区间 | 平均确认决策 | 总耗时(s) |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| baseline:uniform-legal-candidates@1 | baseline | 8 | 8 | 8/0/0 | -1.8000 | 0.0000 | [-1.8000, -1.8000] | 25.0 | 2.33 |
| initial-model | untrained | 8 | 8 | 8/0/0 | -1.8000 | 0.0000 | [-1.8000, -1.8000] | 23.9 | 6.41 |
| candidate-model | trained | 8 | 8 | 8/0/0 | -1.8000 | 0.0000 | [-1.8000, -1.8000] | 23.9 | 5.45 |

## 同种子配对（差值 = 策略 − 均匀基线；负的差值在回报上表示更差）

| 候选策略 | 指标 | 方向 | 配对数 | 平均差值 | 区间 | 判定 |
| --- | --- | --- | --- | --- | --- | --- |
| initial-model | net:metric:reward_scalar | higher_is_better | 8 | 0.0000 | [0.0000, 0.0000] | **undecided**（自助区间跨 0：不声称改善） |
| initial-model | net:metric:steps | higher_is_better | 8 | -1.1250 | [-3.3750, 0.0000] | **undecided**（自助区间跨 0：不声称改善） |
| initial-model | net:metric:wall_ms | lower_is_better | 8 | 509.6205 | [428.7498, 595.3467] | **worse**（自助区间不跨 0） |
| initial-model | net:metric:terminal_win | higher_is_better | 8 | 0.0000 | [0.0000, 0.0000] | **undecided**（自助区间跨 0：不声称改善） |
| candidate-model | net:metric:reward_scalar | higher_is_better | 8 | 0.0000 | [0.0000, 0.0000] | **undecided**（自助区间跨 0：不声称改善） |
| candidate-model | net:metric:steps | higher_is_better | 8 | -1.1250 | [-3.3750, 0.0000] | **undecided**（自助区间跨 0：不声称改善） |
| candidate-model | net:metric:wall_ms | lower_is_better | 8 | 389.0631 | [342.1236, 440.5007] | **worse**（自助区间不跨 0） |
| candidate-model | net:metric:terminal_win | higher_is_better | 8 | 0.0000 | [0.0000, 0.0000] | **undecided**（自助区间跨 0：不声称改善） |

## 执行器可判别性（动作序列是否与均匀基线相同）

| 候选策略 | 与基线动作序列相同的种子数 | 种子数 |
| --- | --- | --- |
| candidate-model | 2 | 8 |
| initial-model | 3 | 8 |

> 相同序列意味着该种子下两个策略**执行了同一串动作**：回报相同是这件事的结果，不构成策略等价的证据，也不构成改善证据。

## 逐局记录

| 策略 | 种子 | 结束 | 终局 | 确认决策 | 回报 | 墙钟(ms) |
| --- | --- | --- | --- | --- | --- | --- |
| baseline:uniform-legal-candidates@1 | 30000 | terminal | loss | 19 | -1.8000 | 305.9 |
| baseline:uniform-legal-candidates@1 | 30001 | terminal | loss | 21 | -1.8000 | 225.0 |
| baseline:uniform-legal-candidates@1 | 30002 | terminal | loss | 32 | -1.8000 | 367.9 |
| baseline:uniform-legal-candidates@1 | 30003 | terminal | loss | 25 | -1.8000 | 280.5 |
| baseline:uniform-legal-candidates@1 | 30004 | terminal | loss | 24 | -1.8000 | 281.8 |
| baseline:uniform-legal-candidates@1 | 30005 | terminal | loss | 23 | -1.8000 | 257.6 |
| baseline:uniform-legal-candidates@1 | 30006 | terminal | loss | 30 | -1.8000 | 312.1 |
| baseline:uniform-legal-candidates@1 | 30007 | terminal | loss | 26 | -1.8000 | 303.7 |
| initial-model | 30000 | terminal | loss | 19 | -1.8000 | 884.2 |
| initial-model | 30001 | terminal | loss | 21 | -1.8000 | 981.7 |
| initial-model | 30002 | terminal | loss | 32 | -1.8000 | 935.4 |
| initial-model | 30003 | terminal | loss | 25 | -1.8000 | 725.2 |
| initial-model | 30004 | terminal | loss | 24 | -1.8000 | 706.6 |
| initial-model | 30005 | terminal | loss | 23 | -1.8000 | 741.6 |
| initial-model | 30006 | terminal | loss | 21 | -1.8000 | 643.3 |
| initial-model | 30007 | terminal | loss | 26 | -1.8000 | 793.5 |
| candidate-model | 30000 | terminal | loss | 19 | -1.8000 | 620.5 |
| candidate-model | 30001 | terminal | loss | 21 | -1.8000 | 632.3 |
| candidate-model | 30002 | terminal | loss | 32 | -1.8000 | 887.1 |
| candidate-model | 30003 | terminal | loss | 25 | -1.8000 | 636.1 |
| candidate-model | 30004 | terminal | loss | 24 | -1.8000 | 662.5 |
| candidate-model | 30005 | terminal | loss | 23 | -1.8000 | 654.3 |
| candidate-model | 30006 | terminal | loss | 21 | -1.8000 | 588.7 |
| candidate-model | 30007 | terminal | loss | 26 | -1.8000 | 765.5 |

## 说明

- 保留种子 30000..30007（8 个）：这是**一个固定场景内的有限种子对照**，不声称已有多场景泛化。
- 每个 (策略, 种子) 各自新开独立会话；三个策略共用同一 Gym、限额与执行器规则（执行器种子 = 环境种子 + 1000000）。
- 自助区间重抽 1000 次、seed=20261003；配对数 < 2 或区间跨 0 时**不声称改善**。
- 本报告不替调用方下'晋升'结论；无改善也如实交付。
- 训练命令从未读取 final 种子，final 结果也不驱动追加训练；本次使用的划分见上方 split。
- 执行器分辨率提示：initial-model 在 3/8 个保留种子上与均匀基线走出**完全相同的动作序列**——回报相同是'同一串动作'的结果，不等于策略等价；要区分策略需要更大的概率差异或更多种子。
- 执行器分辨率提示：candidate-model 在 2/8 个保留种子上与均匀基线走出**完全相同的动作序列**——回报相同是'同一串动作'的结果，不等于策略等价；要区分策略需要更大的概率差异或更多种子。
