# ENV-T04 严格 regression（自动生成）

- 产物版本：`env-t04-test@1`
- suite：`regression`（`env-t04-regression@1`），目标范围 `base-spire-singleplayer-dev-v1`，期望 case 17 个
- run_id：`regression@env-t04-regression@1+20261008T170824Z`
- 复现命令：`dotnet run --project tools/differential -- test --suite regression --output artifacts/environment/tests/regression`
- 完整 suite：True（全量运行）；参考适配器：已接入；退出码：**1**

## 逐 case 判定（只有 passed / self_checked 计成功，且都过了必需维度与预期终点门槛）

| case | 判定 | 内容/机制 | 必需维度 | 终点 | base status | 边界 | 首差/原因 |
| --- | --- | --- | --- | --- | --- | ---: | --- |
| strike-normal | passed | base-spire:strike-ironclad | actions, decisions, facts, pile-order | running (ok) | ok | 2/2 |  |
| strike-upgraded | passed | base-spire:strike-ironclad | actions, decisions, facts, pile-order | running (ok) | ok | 2/2 |  |
| defend-normal | passed | base-spire:defend-ironclad | actions, facts, pile-order | running (ok) | ok | 2/2 |  |
| defend-upgraded | passed | base-spire:defend-ironclad | actions, facts, pile-order | running (ok) | ok | 2/2 |  |
| bash-then-strike-vulnerable | passed | base-spire:bash, base-spire:strike-ironclad, base-spire:vulnerable | actions, decisions, facts, power, pile-order | running (ok) | ok | 3/3 |  |
| bash-upgraded | passed | base-spire:bash, base-spire:vulnerable | actions, decisions, facts, power, pile-order | running (ok) | ok | 2/2 |  |
| candidate-scope-partly-playable | passed | base-spire:strike-ironclad, base-spire:bash | actions, decisions, facts | running (ok) | ok | 2/2 |  |
| headbutt-mid-choice | **unsupported_decision_model** | base-spire:headbutt, base-spire:defend-ironclad | actions, decisions, facts | running (ok) | ok | 2/0 | 参考的**选牌**决策源挂在 run 层（RunState.CardSelectionSource，默认 RunEngineCardSelectionDecisionSource），它的设置入口 ConfigureCardSelectionSource 是 internal；combat 层的 CardSelectionSource 不参与这条路径。实测：参考侧只记录了 1 个决策点（目标）而不是 2 个（目标+选牌），且没有抛错——说明它用的是 run 层默认源，静默自选了牌。工具无法在不修改参考的前提下把受控选牌注进去，因此本 case 只跑 base 侧并按决策模型未对接处理，不计通过。 |
| enemy-death-aftermath | **unsupported_rng_profile** | base-spire:strike-ironclad, base-spire:calcified-cultist, base-spire:damp-cultist | actions, decisions, facts, pile-order | running (ok) | ok | 3/3 | `boundary[2].pile.draw.sorted`：base-spire:strike-ironclad,base-spire:strike-ironclad,base-spire:strike-ironclad,base-spire:strike-ironclad ≠ base-spire:defend-ironclad,base-spire:defend-ironclad,base-spire:strike-ironclad,base-spire:strike-ironclad（最后一致边界 1:step:0:play_card（打出 base-spire:strike-ironclad → enemy:0）） |
| power-turn-end-decay | **unsupported_rng_profile** | base-spire:strike-ironclad, base-spire:vulnerable | actions, decisions, facts, power | running (ok) | ok | 3/3 | `boundary[2].pile.draw.sorted`：base-spire:strike-ironclad,base-spire:strike-ironclad,base-spire:strike-ironclad,base-spire:strike-ironclad ≠ base-spire:defend-ironclad,base-spire:defend-ironclad,base-spire:strike-ironclad,base-spire:strike-ironclad（最后一致边界 1:step:0:play_card（打出 base-spire:strike-ironclad → enemy:0）） |
| vulnerable-decay-via-bash | **unsupported_rng_profile** | base-spire:bash, base-spire:vulnerable | actions, decisions, facts, power | running (ok) | ok | 3/3 | `boundary[2].pile.draw.sorted`：base-spire:strike-ironclad,base-spire:strike-ironclad,base-spire:strike-ironclad,base-spire:strike-ironclad ≠ base-spire:defend-ironclad,base-spire:defend-ironclad,base-spire:strike-ironclad,base-spire:strike-ironclad（最后一致边界 1:step:0:play_card（打出 base-spire:bash → enemy:0）） |
| random-reshuffle-unsupported | **unsupported_rng_profile** | base-spire:strike-ironclad, base-spire:defend-ironclad, base-spire:bash | actions, facts, pile-order, streams（缺 streams(reference)） | running (ok) | ok | 4/4 | `boundary[1].pile.draw.sorted`：base-spire:strike-ironclad,base-spire:strike-ironclad,base-spire:strike-ironclad,base-spire:strike-ironclad,base-spire:strike-ironclad ≠ base-spire:defend-ironclad,base-spire:defend-ironclad,base-spire:strike-ironclad,base-spire:strike-ironclad,base-spire:strike-ironclad（最后一致边界 0:start（受控初始状态）） |
| last-kill-before-terminal | passed | base-spire:strike-ironclad, base-spire:bash, base-spire:vulnerable | actions, decisions, facts, pile-order | victory (ok) | terminal | 3/3 |  |
| rng-initial-shuffle | **diverged** | base-spire:strike-ironclad, base-spire:defend-ironclad, base-spire:bash | actions, facts, pile-order, streams | running (ok) | ok | 1/1 | `boundary[0].enemy.base-spire:fuzzy-wurm-crawler.alive`：缺失 ≠ 存在（最后一致边界 （无：第 0 个边界之前就不同，或两侧边界数不同）） |
| factory-wiring-dev-scope | self_checked | base-spire-singleplayer-dev-v1 | actions, facts | running (ok) | ok | 1/0 |  |
| map-generated-alpha | passed | act-1-map | facts, streams | running (ok) | ok | 1/1 |  |
| map-generated-beta | passed | act-1-map | facts, streams | running (ok) | ok | 1/1 |  |

## 比较器自检（受控错误记录必须被抓到）

| 自检 | 期望差种类 | 是否抓到 | 说明 |
| --- | --- | --- | --- |
| identical/random-reshuffle-unsupported | no_divergence | 是 | verdict=unsupported_rng_profile |
| mutant/field/random-reshuffle-unsupported | field | 是 | boundary[3].player.hp: 54 ≠ 53 |
| mutant/action/random-reshuffle-unsupported | action | 是 | boundary[3].actions[base-spire:PlayCard]: [card:hand:0,card:hand:1,card:hand:2,card:hand:3] ≠ [card:hand:0,card:hand:1,card:hand:2,card:hand:3,card:hand:4] |
| mutant/collection/random-reshuffle-unsupported | collection | 是 | boundary[3].pile.hand.order: base-spire:strike-ironclad,base-spire:defend-ironclad,base-spire:defend-ironclad,base-spire:bash ≠ base-spire:strike-ironclad,base-spire:defend-ironclad,base-spire:defend-ironclad,base-spire:bash,base-spire:strike-ironclad |
| mutant/decision/bash-then-strike-vulnerable | decision | 是 | boundary[2].decisions[0].candidates: [enemy:0] ≠ [enemy:0,enemy:1] |
| mutant/stream/random-reshuffle-unsupported | stream | 是 | boundary[3].streams[base-spire:combat-draw].draws: 10 ≠ 9 |
